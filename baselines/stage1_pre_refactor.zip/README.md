# Stage 1: pre-refactor baseline

Stage: Capture current behavior. Packaging, file moves, and algorithm refactoring have not started.
The only new on-disk artifact produced for this stage is this archive.

## Review
- 9 existing tests passed, including discovery launched from /tmp.
- 17 cases were each run twice: 7 full-simulation cases, 7 production-filter cases,
  and 3 distinct controlled-bootstrap, tutorial-CFM, and standalone-DiffPF fixtures.
- Paired numerical arrays match exactly. Full-simulation CSV metrics match after
  excluding measured runtime. Timestamps and runtime are not deterministic assertions.
- Velocity simulation uses seeds 123 and 1000 for 64 steps each.
  CFM, adaptive CFM, NF, diffusion, and DiffPF simulations use seed 123 for 16 steps.
- Filter fixtures use 16 particles, 12 updates, and a fixed measurement/blackout/
  reappearance sequence. Production, controlled, tutorial, and standalone algorithms
  retain their own semantics and separate fixtures.
- Capture uses CPU and one Torch thread; full environment versions are recorded.
- Direct CLI simulation launched from /tmp fails to locate config.yaml.
  This is an existing limitation, recorded rather than fixed during this stage.
  The test that runs a simulation explicitly changes to the project directory.
- These are regression smoke baselines, not full benchmarks, training, or hardware tests.

## Contents
- source/: current first-party source/config/docs/assets, all dirty tracked and
  untracked work (including experiment outputs), observation history, and the
  sibling visualization example. Each path is relative to ~/MML.
- provenance/inventory.json: source inventory, configuration, checkpoint SHA-256
  identities, and 26 schemas observed in existing result files.
- provenance/source_sha256.json: exact SHA-256 of every included snapshot file.
- provenance/environment_and_cases.json: package versions, arguments, fixture hashes,
  and schemas/dtypes of newly captured in-memory CSV outputs.
- provenance/git/: HEAD, status, staged/unstaged patches, and tracked index metadata.
- provenance/capture_procedure.txt: exact Python procedure used for the captures.
- provenance/inventory_procedure.txt: exact Python procedure used for the inventory.
- results/seeded_outputs.npz: numerical arrays; load with numpy.load(..., allow_pickle=False).
- results/csv/: full-simulation CSV output captured in memory with unchanged serialization.
- logs/: test output, capture output, and the expected arbitrary-working-directory failure.
- archive_entries_sha256.json: hashes for every member except this hash index itself.

## Preservation scope
The snapshot includes uncommitted files and does not reset or commit the repository.
Unchanged checkpoint binaries are identified by path, size, and SHA-256 rather than
duplicated. External checkouts and generated build/install/log trees are excluded.
Retain original checkpoint binaries at the recorded locations for replay.
Configuration and existing observation history are included.

## Replay
Run in the recorded environment with the snapshotted project tree and checkpoints.
The saved capture procedure is the exact inline Python used, including read-only frame
callbacks and interception of CSV writes into memory. It emits a JSON payload containing
the numerical NPZ, CSV text, logs, and metadata. Its project path is
/home/user/MML/mml_python_sim; adjust only that root if restoring elsewhere.
Compare arrays and deterministic metrics against the stored fixtures, not execution time.
The numeric fixture hashes were verified again before this archive was written.

## Restore/review safely
Extract to a separate directory first. Do not blindly overwrite the working tree.
source/ preserves paths relative to ~/MML. Patches and Git metadata supplement the
full snapshot; patches alone do not contain untracked files.
