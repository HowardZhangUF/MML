import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# Set the font sizes for the plot labels
font = {"family": "serif", "weight": "normal", "size": 18}
sns.set_theme()
sns.set_style("white")
sns.set_context("paper", font_scale=2)


def plot_error_bars(
    error_df, outdir_all, title, ylabel, xlabel, figwidth, islegend=False
):
    ## PLOTS
    rms_estimator = lambda x: np.sqrt(np.mean(np.square(x)))
    dpi = 300
    # BAR
    fig, ax = plt.subplots(figsize=(figwidth, 6.5))
    sns.barplot(
        y="Guidance Method",
        x="Error",
        data=error_df,
        ax=ax,
        hue="hue",
        estimator=rms_estimator,
        capsize=0.1,
        errorbar="sd",
        width=1.0,
        legend=islegend,  # Suppress the legend
        err_kws={"linewidth": 1.5},
    )
    if islegend:
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(
            handles, labels, fontsize=16,
            title_fontsize=18, loc="upper right"
        )
    # ax.set_xticklabels(ax.get_xticklabels(), fontdict=font)
    ax.set_ylabel(ylabel=ylabel, fontdict=font)
    ax.set_xlabel(xlabel=xlabel, fontdict=font)
    # ax.set_ylim([0, 5])
    sns.despine(right=True)
    plt.tight_layout()  # Automatically adjust subplot parameters to give specified padding
    # plt.show()
    plt.savefig(outdir_all + title + ".png", dpi=dpi)

def plot_combined_grid(all_values_dict, guidance_method, outdir_all, num_runs):
    """
    Create a combined 2x3 grid plot showing all metrics with annotations.
    """
    # Define metrics to plot
    metrics_config = [
        ("wasserstein_2d", "WASSERSTEIN 2D", "Wasserstein Distance [m]"),
        ("ospa", "OSPA", "OSPA Distance [m]"),
        ("determinant_of_covariance", "DETERMINANT OF COVARIANCE", r"$\det({\Sigma_k})$ $[m^2]$"),
        ("cardinality_error", "CARDINALITY ERROR", "Cardinality Error"),
        ("rmse", "RMSE", "RMSE [m]")
    ]
    
    # Build long-form dataframe
    data_records = []
    for method_key, method_data in all_values_dict.items():
        display_name = guidance_method.get(method_key, method_key)
        for metric_key, _, _ in metrics_config:
            if metric_key in method_data:
                for val in method_data[metric_key].dropna():
                    data_records.append({
                        "Method": display_name,
                        "Metric": metric_key,
                        "Value": val
                    })
    
    long_df = pd.DataFrame(data_records)
    
    # Create 2x3 grid
    fig, axes = plt.subplots(2, 3, figsize=(20, 12))
    axes = axes.flatten()
    
    # Custom colors
    custom_palette = ["#e6858f", "#72cfcf", "#63b8db"]
    
    # RMS estimator
    rms_est = lambda x: np.sqrt(np.mean(np.square(x)))
    
    # Plot each metric
    for i, (metric_key, title, ylabel) in enumerate(metrics_config):
        ax = axes[i]
        subset = long_df[long_df["Metric"] == metric_key]
        
        if subset.empty:
            ax.text(0.5, 0.5, "No Data", ha='center', va='center', transform=ax.transAxes)
            ax.set_title(f"{title} Comparison", fontweight='bold', fontsize=14)
            continue
        
        # Create bar plot
        sns.barplot(
            data=subset,
            x="Method",
            y="Value",
            hue="Method",
            ax=ax,
            palette=custom_palette,
            estimator=rms_est,
            errorbar="sd",
            capsize=0.1,
            dodge=False,
            legend=False
        )
        
        # Calculate stats for annotations
        stats = subset.groupby("Method")["Value"].agg(rms=rms_est, std='std')
        x_labels = [t.get_text() for t in ax.get_xticklabels()]
        
        # Add annotations on bars
        for j, patch in enumerate(ax.patches):
            if j < len(x_labels):
                method_name = x_labels[j]
                if method_name in stats.index:
                    mean_val = stats.loc[method_name, "rms"]
                    std_val = stats.loc[method_name, "std"]
                    
                    label_text = f"{mean_val:.4f}\n±{std_val:.4f}"
                    y_pos = mean_val + std_val + (mean_val * 0.05)
                    
                    ax.text(
                        patch.get_x() + patch.get_width() / 2,
                        y_pos,
                        label_text,
                        ha='center',
                        va='bottom',
                        fontsize=11,
                        fontweight='bold'
                    )
        
        # Formatting
        ax.set_title(f"{title} Comparison", fontweight='bold', fontsize=14)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.set_xlabel("")
        ax.tick_params(axis='x', rotation=15)
        
        # Add run count label
        ax.text(0.02, 0.95, f"n={num_runs} runs/mode", transform=ax.transAxes,
                fontsize=10, bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))
    
    # Hide 6th empty subplot
    axes[5].axis('off')
    
    # Global title
    fig.suptitle(f"Tracking Performance Comparison\nDate: {datetime.now().strftime('%Y-%m-%d')}",
                 fontsize=16, fontweight='bold')
    
    plt.tight_layout()
    
    # Save
    save_path = os.path.join(outdir_all, "Combined_Performance_Report.png")
    plt.savefig(save_path, dpi=300)
    print(f"\nCombined grid plot saved to: {save_path}")
    plt.close()

def main():
    # Set the name of the input CSV directory
    folder_path = "./tracking_results/"

    include_data = {
        "err estimation norm": "$ee$ $[m]$",
        "err tracking norm": "$te$ $[m]$",
        "entropy data": "Entropy",
        "n eff particles data": "Effective Number of Particles",
        "xyTh estimate cov det": r"$\det({\Sigma_k})$  $[m^2]$",
        "is update data": r"\% FOV",
        "wasserstein_2d": "Wasserstein Distance [m]",
        "ospa": "OSPA Distance [m]", 
        "cardinality_error": "Cardinality Error",
        "rmse": "RMSE [m]",
        "determinant_of_covariance": r"$\det({\Sigma_k})$  $[m^2]$",
    }

    guidance_method = {
        "Velocity": "VEL",
        "KF": "KF",
        "DMMN": "DMMN",
        "VelTimNN": "DNN",
        "PosTRA": "PFWM",
        "MeanKF": "KF",
        "PosTRA": "PosTRA",
        "PosNN": "PosNN",
        "VelTRA": "VelTRA",
        "VelNN": "VelNN",
        "PosTimTRA": "PosTimTRA",
        "PosTimNN": "PosTimNN",
        "VelTimTRA": "VelTimTRA",
        "VelTimNN": "VelTimNN",
        "PFVelocity": "PFVelocity",
        "MultiKF": "Multi-KF",
        "MultiPF": "Multi-PF",
        "KF_Lawnmower": "KF Lawnmower",
        "MultiKF_MultiKFInfo": "Multi-KF Info",
        "MultiPFVel_MultiPFInfo_LSTM": "Multi-PF Vel Info LSTM",
        "MultiPFPPO_LSTM": "Multi-PF Info PPO LSTM",
        "MultiPFTra_MultiPFInfo": "MultiPF Tra Info",
        "MultiPFTra_MultiPFInfo_LSTM": "MultiPF Tra Info LSTM",
        "MultiPFTra_MultiPFInfoPPO_LSTM": "RLTrack-DMMN",
        "MultiPFVel_MultiPFInfoPPO_LSTM": "RLTrack-CV",
         # Add the _tracking variants with consistent naming
        "MultiPFTra_MultiPFInfo_tracking": "ActiveTrack-DMMN",        # ← Fixed
        "MultiPFVel_MultiPFInfo_tracking": "ActiveTrack-CV",       # ← Fixed
        "MultiKF_MultiKFInfo_tracking": "ActiveTrack-KF", 
    }

    filenames = os.listdir(folder_path)
    print("Number of individual runs found:", len(filenames))
    csv_dict = dict()
    all_values_dict = dict()
    for filename in filenames:
        if filename.endswith(".csv"):
            first_word = "_".join(filename.split("_")[:3])
            if first_word not in csv_dict:
                csv_dict[first_word] = dict()
                all_values_dict[first_word] = dict()
            datetime_file = "_".join(filename[:-4].split("_")[-2:])  # ignore ".csv"
            csv_dict[first_word][datetime_file] = dict()

            file_df = pd.read_csv(folder_path + filename, low_memory=False)

            # Collect data for RMS values csv
            for col_name in file_df.columns:
                if (any(col_name == word for word in include_data)):
                    rms = round(np.sqrt(np.mean(file_df[col_name] ** 2)), 3)
                    sd = round(np.std(file_df[col_name]), 3)  # standard deviation
                    csv_dict[first_word][datetime_file][col_name] = (float(rms), float(sd))
                    if col_name not in all_values_dict[first_word]:
                        all_values_dict[first_word][col_name] = file_df[col_name]
                    else:
                        all_values_dict[first_word][col_name] = pd.concat([all_values_dict[first_word][col_name], file_df[col_name]], ignore_index=True)
            csv_dict[first_word][datetime_file]["num_elements"] = len(file_df)
            csv_dict[first_word][datetime_file]["total_time"] = file_df["time"].iloc[-1] if "time" in file_df.columns else None
    print("List of columns found:", file_df.columns.tolist())

    print("List of methods found: ", list(csv_dict.keys()))
    joined_dir = os.path.join(folder_path, "joined")
    error_df = pd.DataFrame()
    rms_std_dict = dict()
    for method in all_values_dict.keys():
        csv_df = pd.DataFrame.from_dict(csv_dict[method], orient="index")
        method_dir = os.path.join(joined_dir, method)
        if not os.path.exists(method_dir):
            os.makedirs(method_dir)
        datetime_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_df.to_csv(os.path.join(method_dir, f"{datetime_str}_overall.csv"), index=True)
 
        all_csv_df = pd.DataFrame.from_dict(all_values_dict[method], orient="index").T

        # Process each metric separately
        rms_std_dict[method] = dict()
        for col_name in all_csv_df.columns:
            if col_name in include_data:
                pmean = all_csv_df[col_name].dropna().mean()
                pstd = all_csv_df[col_name].dropna().std()
                row = pd.DataFrame({
                    "Error": include_data[col_name],
                    "hue": guidance_method[method],
                    "Guidance Method": (pmean + pstd, pmean - pstd)
                })
                error_df = pd.concat([error_df, row], ignore_index=True)
                rms_std_dict[method][col_name] = (float(pmean), float(pstd))

                # histogram
                plt.figure(figsize=(6,4))
                sns.histplot(all_csv_df[col_name].dropna(), bins=30)
                plt.xlabel(include_data[col_name], fontdict={"weight": "normal", "size": 18})
                plt.ylabel("Frequency", fontdict={"weight": "normal", "size": 18})
                plt.title(f"Histogram of {include_data[col_name]} for {method}", fontdict={"weight": "normal", "size": 18})
                plt.tight_layout()
                plt.savefig(os.path.join(method_dir, f"{method}_{col_name}_histogram.png"), dpi=300)
                plt.close()

    outdir_all = os.path.join(folder_path, "all/")
    if not os.path.exists(outdir_all):
        os.makedirs(outdir_all)

    csv_df = pd.DataFrame.from_dict(rms_std_dict, orient="index")
    csv_df.to_csv(outdir_all + "all_runs_rms.csv")

    for error_type in error_df["Error"].unique():
        plot_error_bars(
            error_df[error_df["Error"] == error_type], outdir_all, error_type+"errors", "Values", "", figwidth=6, islegend=True
        )
    
    # Generate combined grid plot
    # Count number of runs per method
    num_runs_per_method = {method: len(runs) for method, runs in csv_dict.items()}
    avg_num_runs = int(np.mean(list(num_runs_per_method.values()))) if num_runs_per_method else 10
    
    plot_combined_grid(all_values_dict, guidance_method, outdir_all, avg_num_runs)
    
    print("\n" + "="*70)
    print("All plots generated successfully!")
    print(f"Individual bar plots: {outdir_all}")
    print(f"Histograms: {joined_dir}")
    print(f"Combined report: {outdir_all}Combined_Performance_Report.png")
    print("="*70)

if __name__ == "__main__":
    main()
