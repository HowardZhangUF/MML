# MML Guidance ROS 2 Hardware Setup Guide

## System Overview

The MML (Mutual Information Maximization) guidance system connects:
- **OptiTrack Motion Capture** (via mocap_transform or ros_vrpn_client)
- **Drone** (quadcopter with autopilot)
- **Turtlebot** (ground robot target)
- **Guidance algorithms** (particle filter + information-driven control)

## Network Configuration

### OptiTrack Mocap System
- **IP Address**: `192.168.1.104` (default)
- **Protocol**: VRPN (Virtual Reality Peripheral Network)
- **Rigid Bodies**: Define in Motive software
  - Drone: `takahe` (or `pop` in APRILab)
  - Turtlebot: `rail` (or `leo` in APRILab)

### Required Packages

#### ROS 2 Packages (Hardware)
```bash
# Mocap connection
mocap_transform  # ROS 2 package for OptiTrack/VRPN

# Drone packages
mavros           # For ArduPilot/PX4 communication
reef_estimator   # State estimation fusion
reef_control     # PID controller
position_to_velocity  # Odometry conversion

# Turtlebot packages
turtlebot_bringup    # Turtlebot3 hardware interface
andres_turtlebot_pid # Custom PID controller

# Camera (optional)
realsense2_camera    # Intel RealSense D435/D455
```

#### Python Dependencies
```bash
pip install shapely  # Required for lawnmower path generation
pip install -r requirements.txt  # All other dependencies
```

## Hardware Setup Procedures

### 1. OptiTrack Motion Capture Setup

1. **Start Motive Software** (on OptiTrack PC)
   - Calibrate cameras if needed
   - Create rigid bodies for drone and turtlebot
   - Name them: `takahe` (drone), `rail` (turtlebot)
   - Enable VRPN streaming: View → Data Streaming → VRPN Streaming

2. **Verify Network Connection**
   ```bash
   # On base station
   ping 192.168.1.104
   ```

3. **Test VRPN Stream** (if using ros_vrpn_client)
   ```bash
   ros2 run vrpn_client vrpn_client_node --ros-args -p server:=192.168.1.104
   ```

### 2. Drone Hardware Setup

#### Option A: Using RosFlight (legacy)
```bash
# Connect flight controller via USB (/dev/ttyACM0)
# Launch RosFlight IO node
ros2 run rosflight rosflight_io --ros-args -p port:=/dev/ttyACM0
```

#### Option B: Using MAVROS (APRILab new setup)
```bash
# On the drone companion computer
ros2 launch mavros apm.launch fcu_url:=/dev/ttyUSB0:921600

# On base station
ros2 launch base_launch base.launch.yaml
ros2 run drone_launch gp_origin

# Flight modes (run on drone):
drone_alt_hold   # Altitude hold mode
drone_pos_hold   # Position hold mode
drone_guided     # Accept waypoints from guidance
```

### 3. Turtlebot Setup

```bash
# On Turtlebot onboard PC
roslaunch turtlebot_bringup minimal.launch

# Verify connection
ros2 topic list | grep /mobile_base
```

## Launch Procedures

### Full System (Drone + Turtlebot + Mocap)

```bash
# Terminal 1: Build and source workspace
cd ~/mml_python_sim
colcon build --packages-select mml_guidance
source install/setup.bash

# Terminal 2: Launch hardware system
ros2 launch mml_guidance track_hardware.launch.py \
    vehicle:=takahe \
    rigid_body_name:=rail \
    mocap_server_ip:=192.168.1.104 \
    use_camera:=true

# Optional: Record data
ros2 bag record -a -o mml_experiment_$(date +%Y%m%d_%H%M%S)
```

### Launch Options

#### Drone Only
```bash
ros2 launch mml_guidance track_hardware.launch.py \
    vehicle:=takahe \
    run_estimator:=true \
    use_camera:=true
```

#### Turtlebot Only  
```bash
ros2 launch mml_guidance turtlebot_hardware.launch.py \
    rigid_body_name:=rail \
    mocap_server_ip:=192.168.1.104
```

#### APRILab Configuration
```bash
# Uses leo (turtlebot) and pop (drone) as rigid body names
ros2 launch mml_guidance april_hardware.launch.py \
    is_sim:=false \
    prediction_method:=Transformer \
    guidance_mode:=Information \
    N:=500
```

## System Architecture

### Data Flow

```
OptiTrack Motive → VRPN → mocap_transform → /takahe/nwu/pose_stamped
                                          → /rail/nwu/pose_stamped
                                          
/takahe/nwu/pose_stamped → reef_estimator → /pose_stamped → drone_guidance
/rail/nwu/pose_stamped → markov_goal_pose → /rail/goal_pose → turtlebot_pid

drone_guidance → /quad_cmd_vel → reef_control_pid → /attitude_command
turtlebot_pid → /mobile_base/commands/velocity → Turtlebot motors
```

### Key Topics

| Topic | Type | Description |
|-------|------|-------------|
| `/takahe/nwu/pose_stamped` | PoseStamped | Drone pose from mocap (NWU frame) |
| `/rail/nwu/pose_stamped` | PoseStamped | Turtlebot pose from mocap |
| `/pose_stamped` | PoseStamped | Fused drone pose estimate |
| `/quad_cmd_vel` | TwistStamped | Velocity commands to drone |
| `/rail/goal_pose` | PoseStamped | Target waypoint for turtlebot |
| `/mobile_base/commands/velocity` | Twist | Velocity commands to turtlebot |
| `/xyTh_estimate` | ParticleMean | Particle filter estimate |
| `/noisy_measurement` | PointStamped | Simulated noisy detections |

## Troubleshooting

### Mocap Not Publishing
```bash
# Check if mocap_transform is running
ros2 node list | grep mocap

# Check VRPN server connectivity
telnet 192.168.1.104 3883

# Verify Motive is streaming
# In Motive: View → Data Streaming → check VRPN Streaming enabled
```

### Drone Not Responding
```bash
# Check autopilot connection
ros2 topic hz /mavros/state  # Should be ~1 Hz

# Verify mode
ros2 topic echo /mavros/state | grep mode

# Check for errors
ros2 topic echo /diagnostics
```

### Missing Package Errors
```bash
# Install missing ROS 2 packages
sudo apt update
sudo apt install ros-humble-<package-name>

# Or build from source in workspace
cd ~/colcon_ws/src
git clone <package-repo>
cd ~/colcon_ws
colcon build
```

### Guidance Node Crashes
```bash
# Install missing Python dependencies
pip install shapely numpy scipy matplotlib

# Check if models exist
ls ~/mml_python_sim/mml_guidance/mml_guidance/mml_network/models/

# Run with debug output
ros2 launch mml_guidance track_hardware.launch.py --log-level debug
```

### Type Errors in markov_goal_pose
```bash
# This is a known issue with goal_pose["y"] not being float
# Check the markov_goal_pose node for type conversions
# Ensure polygon vertices are float type
```

## Configuration Files

### Adjust Guidance Parameters
Edit `~/mml_python_sim/config.yaml`:
```yaml
number_agents: 1
number_targets: 2
max_lin_velx: 0.6  # m/s
max_lin_vely: 0.6
max_ang_vel: 5.0   # rad/s
```

### Adjust Particle Filter
In guidance node parameters:
```python
N = 500  # Number of particles
prediction_method = "Transformer"  # "NN", "Transformer", "Velocity", "KF"
guidance_mode = "Information"  # "Lawnmower", "WeightedMean", "Estimator"
```

## Safety Notes

1. **Always test in simulation first** using `mml_sim_estimator.launch.py`
2. **Verify mocap tracking** before arming drone
3. **Keep manual RC override ready** for drone
4. **Monitor battery levels** on both drone and turtlebot
5. **Establish geofence** in autopilot parameters
6. **Test emergency stop procedures** before flight

## Quick Start Checklist

- [ ] OptiTrack Motive running and streaming VRPN
- [ ] Rigid bodies `takahe` and `rail` created and tracked
- [ ] Drone autopilot connected and armed
- [ ] Turtlebot powered on and connected
- [ ] Network connectivity verified (ping 192.168.1.104)
- [ ] All ROS 2 packages built (`colcon build`)
- [ ] Workspace sourced (`source install/setup.bash`)
- [ ] Python dependencies installed (`pip install shapely`)
- [ ] Launch file runs without errors
- [ ] Verify topics publishing: `ros2 topic list`
- [ ] Check tf tree: `ros2 run tf2_tools view_frames`

## Additional Resources

- **Original ROS 1 setup**: See `track_hardware.launch` (XML format)
- **Simulation testing**: Use `mml_sim_estimator.launch.py`
- **Motion model training**: See `mml_guidance/mml_guidance/mml_network/train.py`
- **Paper**: "Uncertainty-Aware Guidance for Target Tracking subject to Intermittent Measurements"
