# Quick Start: Deploying RL Policy to Real Drone

## Prerequisites

✅ Trained PPO model from PyGame training (`.zip` file)  
✅ ROS 2 Humble installed  
✅ MAVROS configured and connected to drone  
✅ OptiTrack mocap tracking target (`leo` or similar)  
✅ Workspace built: `colcon build --packages-select mml_guidance`

## Step 1: Verify Your Model Path

```bash
# Find your trained model
ls ~/mml_python_sim/models_recurrent/

# Example model:
# recurrent_ppo_ospa_info_final_20251217_032545.zip
```

## Step 2: Test in Simulation First (IMPORTANT!)

Before flying, verify the policy works:

```bash
cd ~/mml_python_sim
python info_mml_main.py
```

Watch for:
- Policy loads without errors
- Tracking behavior looks reasonable
- No crashes or NaN values

## Step 3: Prepare Hardware

### A. Start OptiTrack Mocap
- Launch Motive software
- Verify target rigid body `leo` is tracked
- Enable VRPN streaming

### B. Connect Drone
```bash
# On drone companion computer
ros2 launch mavros apm.launch fcu_url:=/dev/ttyUSB0:921600

# On base station
ros2 launch base_launch base.launch.yaml
```

### C. Check Topics
```bash
# Verify drone pose
ros2 topic hz /mavros/local_position/pose

# Verify target mocap
ros2 topic hz /mocap/leo/pose

# Verify velocity command path
ros2 topic info /mavros/setpoint_velocity/cmd_vel_unstamped
```

## Step 4: Launch RL Tracker (Conservative Mode)

```bash
cd ~/mml_python_sim
source install/setup.bash

ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/your_model.zip \
    target_topic:=/mocap/leo/pose \
    drone_height:=1.0 \
    max_vel:=0.3
```

**Note**: `max_vel:=0.3` is VERY conservative for initial tests!

## Step 5: Arm and Switch to Offboard Mode

### Safety Checklist Before Arming:
- [ ] Propellers attached and secure
- [ ] Battery charged (>50%)
- [ ] Clear flight area (no obstacles)
- [ ] Emergency stop ready (RC override)
- [ ] RL tracker node running without errors

### Arming Procedure:
```bash
# Set to GUIDED mode
ros2 service call /mavros/set_mode mavros_msgs/srv/SetMode "{custom_mode: 'GUIDED'}"

# Arm
ros2 service call /mavros/cmd/arming mavros_msgs/srv/CommandBool "{value: true}"

# Takeoff to 1m
ros2 service call /mavros/cmd/takeoff mavros_msgs/srv/CommandTOL "{altitude: 1.0}"
```

### Enable Offboard Control:
Once hovering at 1m, the RL tracker will automatically send velocity commands.

## Step 6: Monitor Performance

Open multiple terminals:

### Terminal 1: Node Output
```bash
ros2 topic echo /mavros/setpoint_velocity/cmd_vel_unstamped
```

### Terminal 2: Position Tracking
```bash
# Monitor drone position
ros2 topic echo /mavros/local_position/pose

# Monitor target position
ros2 topic echo /mocap/leo/pose
```

### Terminal 3: ROS Logs
```bash
ros2 node info /rl_offboard_tracker
```

## Step 7: Gradually Increase Velocity Limits

After successful conservative flight:

```bash
# Stop current node (Ctrl+C)

# Relaunch with higher limit
ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/your_model.zip \
    target_topic:=/mocap/leo/pose \
    max_vel:=0.5  # Increased from 0.3
```

Progression:
- `max_vel:=0.3` → Initial test
- `max_vel:=0.5` → After 1-2 successful flights
- `max_vel:=0.8` → After 5+ successful flights
- `max_vel:=1.0` → Full speed (match training)

## Emergency Procedures

### Immediate Stop (Kill Switch)
```bash
# Emergency land
ros2 service call /mavros/cmd/land mavros_msgs/srv/CommandTOL

# Or disarm (drops immediately!)
ros2 service call /mavros/cmd/arming mavros_msgs/srv/CommandBool "{value: false}"
```

### RC Override
Keep RC transmitter ready - switch to MANUAL mode immediately if needed.

### Node Issues
If RL tracker crashes:
- Drone will hover (no new velocity commands)
- Manually land via RC or service call

## Troubleshooting

### "No target data received"
```bash
# Check mocap topic
ros2 topic list | grep mocap
ros2 topic hz /mocap/leo/pose

# Fix: Verify OptiTrack is streaming and rigid body exists
```

### "No valid action (track lost?)"
```bash
# Particle filter lost track
# Solution: 
# 1. Check if target is visible to drone
# 2. Reduce occlusions
# 3. Increase num_particles (default 200)
```

### Drone oscillates/unstable
```bash
# Velocity limits too high for current tuning
# Solution: Reduce max_vel
ros2 launch mml_guidance rl_tracker.launch.py max_vel:=0.2
```

### Policy produces NaN actions
```bash
# Check model loaded correctly
# Check observation values are in expected range
# Verify particle filter is producing valid estimates

# Debug:
ros2 topic echo /xyTh_estimate  # If publishing
```

## Data Recording

```bash
# Record all topics for analysis
ros2 bag record -a -o rl_flight_$(date +%Y%m%d_%H%M%S)

# Record specific topics
ros2 bag record \
    /mavros/local_position/pose \
    /mavros/setpoint_velocity/cmd_vel_unstamped \
    /mocap/leo/pose \
    -o rl_flight
```

## Parameter Tuning

### Particle Filter
```bash
# More particles = better tracking, more compute
ros2 launch mml_guidance rl_tracker.launch.py num_particles:=500

# Different prediction model
ros2 launch mml_guidance rl_tracker.launch.py prediction_method:=Transformer
```

### Flight Parameters
```bash
# Higher altitude
ros2 launch mml_guidance rl_tracker.launch.py drone_height:=2.0

# Different target
ros2 launch mml_guidance rl_tracker.launch.py target_topic:=/mocap/robot1/pose
```

## Success Metrics

After deployment, evaluate:

✅ **Stability**: Drone maintains smooth flight without oscillations  
✅ **Tracking**: Stays within 1-2m of target  
✅ **Recovery**: Handles occlusions and recovers track  
✅ **Safety**: No crashes, maintains altitude  

## Next Steps

### Fine-Tuning (Optional)
If performance isn't perfect:

1. **Collect real-world data** (10-20 flights)
2. **Fine-tune policy**:
   ```python
   model = PPO.load("your_model.zip")
   model.learn(real_world_data, total_timesteps=10000)
   ```
3. **Re-deploy** with updated model

### Advanced Features
- Multi-target tracking (if trained)
- Information-driven guidance mode
- Adaptive velocity limits based on tracking confidence

## Common Questions

**Q: Do I need PyGame installed on the drone/base station?**  
A: No! PyGame was only for training. At inference, the policy doesn't use it.

**Q: What if my coordinate frames don't match PyGame?**  
A: Add a coordinate transformation in `drone_pose_cb()` and `target_cb()`.

**Q: Can I use a different mocap system?**  
A: Yes, just change `target_topic` to match your mocap output topic.

**Q: My drone has different dynamics than the sim - will it work?**  
A: Start with low velocities. The LSTM policy has some robustness to dynamics differences. If needed, collect real data and fine-tune.

## Safety Reminders

🚨 **Always have RC override ready**  
🚨 **Start with low velocity limits**  
🚨 **Test in open area first**  
🚨 **Monitor battery levels**  
🚨 **Keep away from people/obstacles**  

---

For detailed explanation of sim-to-real transfer, see `SIM_TO_REAL_RL_DEPLOYMENT.md`
