# Quick Start: MML ROS 2 Hardware System

## What Was Created

1. **`track_hardware.launch.py`** - ROS 2 hardware launch file for drone + mocap + turtlebot
2. **`ROS2_HARDWARE_SETUP.md`** - Comprehensive setup documentation
3. **Fixed `mml_sim_estimator.launch.py`** - Resilient to missing optional packages

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  OptiTrack Motion Capture System (192.168.1.104)            │
│  • Tracks "takahe" (drone) and "rail" (turtlebot)           │
└───────────────┬─────────────────────────────────────────────┘
                │ VRPN Stream
                ▼
┌─────────────────────────────────────────────────────────────┐
│  Base Station (ROS 2 Humble)                                 │
│  ┌─────────────────┐    ┌──────────────────┐                │
│  │ mocap_transform │───▶│ drone_guidance   │                │
│  └─────────────────┘    │ (mml_guidance)   │                │
│          │              └──────────────────┘                │
│          │                      │                            │
│          ▼                      ▼                            │
│  ┌─────────────────┐    ┌──────────────────┐                │
│  │ reef_estimator  │    │ Particle Filter  │                │
│  └─────────────────┘    └──────────────────┘                │
│          │                      │                            │
│          ▼                      ▼                            │
│  ┌─────────────────┐    ┌──────────────────┐                │
│  │ reef_control    │    │ turtlebot_pid    │                │
│  │ (PID)           │    └──────────────────┘                │
│  └─────────────────┘            │                            │
└──────────┬────────────────────────┬─────────────────────────┘
           │                        │
           ▼                        ▼
┌─────────────────┐      ┌─────────────────┐
│  Drone          │      │  Turtlebot      │
│  (Quadcopter)   │      │  (Target)       │
└─────────────────┘      └─────────────────┘
```

## Key Commands

### Build & Source
```bash
cd ~/mml_python_sim
colcon build --packages-select mml_guidance
source install/setup.bash
```

### Launch Full System
```bash
ros2 launch mml_guidance track_hardware.launch.py \
    vehicle:=takahe \
    rigid_body_name:=rail \
    mocap_server_ip:=192.168.1.104
```

### Launch Options

#### Simulation (testing before hardware)
```bash
ros2 launch mml_guidance mml_sim_estimator.launch.py \
    is_simulation:=true \
    is_visualization:=true
```

#### APRILab Setup
```bash
# On drone
ros2 launch mavros apm.launch

# On base station
ros2 launch base_launch base.launch.yaml
ros2 run drone_launch gp_origin
ros2 launch mml_guidance april_hardware.launch.py
```

## Critical Dependencies

✅ **Installed:**
- shapely (Python package for geometry)

⚠️ **May be Missing (checked at runtime):**
- `mocap_transform` - OptiTrack/VRPN connection
- `reef_estimator` - State estimation
- `reef_control` - PID controller
- `position_to_velocity` - Odometry conversion
- `realsense2_camera` - Camera driver (optional)

## Monitoring Commands

```bash
# Check all nodes running
ros2 node list

# Monitor key topics
ros2 topic hz /takahe/nwu/pose_stamped  # Drone pose from mocap
ros2 topic hz /rail/nwu/pose_stamped    # Turtlebot pose
ros2 topic hz /xyTh_estimate            # Particle filter output

# Visualize transforms
ros2 run tf2_tools view_frames

# Record experiment data
ros2 bag record -a -o experiment_$(date +%Y%m%d_%H%M%S)
```

## Network Setup

| Device | IP Address | Purpose |
|--------|------------|---------|
| OptiTrack PC | 192.168.1.104 | Mocap server (VRPN) |
| Base Station | 192.168.1.X | ROS 2 nodes |
| Drone | WiFi/MAVLink | Autopilot connection |
| Turtlebot | WiFi | Onboard computer |

## Troubleshooting Quick Fixes

### "No module named 'shapely'"
```bash
pip install shapely
```

### "Package 'mocap_transform' not found"
```bash
# Option 1: Install from apt
sudo apt install ros-humble-mocap-transform

# Option 2: Build from source
cd ~/colcon_ws/src
git clone https://github.com/your-repo/mocap_transform
cd ~/colcon_ws && colcon build
```

### "AssertionError: The 'y' field must be of type 'float'"
This is in `markov_goal_pose` - the goal pose coordinates need to be explicitly cast to float.

### Mocap not publishing
1. Check Motive is running and streaming VRPN
2. Verify network: `ping 192.168.1.104`
3. Check rigid bodies are tracked in Motive
4. Restart mocap_transform nodes

## Flight Safety

🚨 **Before flying:**
1. Test in simulation first
2. Verify mocap tracking quality
3. Check battery levels
4. Keep RC override ready
5. Establish safe flight area
6. Test emergency stop

## File Locations

| File | Purpose |
|------|---------|
| `mml_guidance/launch/track_hardware.launch.py` | Main hardware launch |
| `mml_guidance/launch/april_hardware.launch.py` | APRILab variant |
| `mml_guidance/launch/mml_sim_estimator.launch.py` | Simulation |
| `ROS2_HARDWARE_SETUP.md` | Full documentation |
| `config.yaml` | Simulation parameters |
| `mml_guidance/mml_guidance/guidance.py` | Main guidance node |
| `mml_guidance/mml_guidance/ParticleFilter.py` | Particle filter |

## Next Steps

1. **Test in simulation** to verify algorithms work
2. **Setup OptiTrack** and verify rigid body tracking
3. **Connect hardware** one device at a time (mocap → turtlebot → drone)
4. **Test each subsystem** independently before full integration
5. **Tune parameters** in `config.yaml` for your environment
6. **Record data** for analysis and debugging

For detailed instructions, see `ROS2_HARDWARE_SETUP.md`.
