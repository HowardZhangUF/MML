# RL Tracker - Working Configuration

## ✅ FIXED: Python Environment Issue

**Problem Solved**: ROS 2 Humble requires Python 3.10, not Python 3.11

### Correct Setup Commands

```bash
# 1. Deactivate any conda/micromamba environments
micromamba deactivate  # or: conda deactivate

# 2. Verify you're using system Python 3.10
python3 --version  # Should show Python 3.10.x

# 3. Source ROS 2 and workspace
source /opt/ros/humble/setup.bash
source ~/mml_python_sim/install/setup.bash

# 4. Verify NumPy version (MUST be >= 2.0 to match training environment)
python3 -c "import numpy; print(numpy.__version__)"  # Should show 2.2.6 or similar
```

## Available Models

Located in `~/mml_python_sim/models_recurrent/`:

**Latest/Recommended**:
- `recurrent_ppo_tracking_final_20251216_151239.zip` (14MB)
- `recurrent_ppo_tracking_final_20251209_150411_h4.zip` (14MB)

**Training Checkpoints**:
- `recurrent_ppo_tracking_50000_steps.zip`
- `recurrent_ppo_tracking_100000_steps.zip`
- ... up to 450000 steps

## Launch Commands

### Test with Mock Hardware (No Drone Required)

```bash
# Terminal 1: Publish fake target position
ros2 topic pub /mocap/leo/pose geometry_msgs/msg/PoseStamped \
    "{header: {frame_id: 'world'}, pose: {position: {x: 1.0, y: 0.5, z: 0.0}}}" \
    -r 30

# Terminal 2: Launch RL tracker
ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_tracking_final_20251216_151239.zip \
    target_topic:=/mocap/leo/pose \
    max_vel:=0.3
```

**Expected Behavior**: Node should start and wait for drone pose. Will show warnings about no drone data (normal without MAVROS).

### Real Hardware Flight

```bash
# Prerequisites:
# - MAVROS running and publishing /mavros/local_position/pose
# - OptiTrack publishing /mocap/leo/pose
# - Drone armed and in GUIDED mode

ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_tracking_final_20251216_151239.zip \
    target_topic:=/mocap/leo/pose \
    drone_height:=1.0 \
    max_vel:=0.3 \
    num_particles:=200 \
    prediction_method:=Velocity
```

## Quick Test Script

Save this as `test_rl_tracker.sh`:

```bash
#!/bin/bash
set -e

echo "=== RL Tracker Test Script ==="

# 1. Check environment
echo "1. Checking Python version..."
python3 --version | grep "3.10" || { echo "ERROR: Need Python 3.10"; exit 1; }

# 2. Check NumPy
echo "2. Checking NumPy..."
python3 -c "import numpy; assert numpy.__version__ >= '1.23.5'; print(f'NumPy {numpy.__version__} OK')"

# 3. Check model exists
MODEL="/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_tracking_final_20251216_151239.zip"
echo "3. Checking model..."
[ -f "$MODEL" ] && echo "Model found: $MODEL" || { echo "ERROR: Model not found"; exit 1; }

# 4. Source workspace
echo "4. Sourcing workspace..."
source /opt/ros/humble/setup.bash
source ~/mml_python_sim/install/setup.bash

# 5. Check rl_tracker executable
echo "5. Checking executable..."
which rl_tracker || { echo "ERROR: rl_tracker not found"; exit 1; }

echo ""
echo "✅ All checks passed!"
echo ""
echo "To launch:"
echo "  ros2 launch mml_guidance rl_tracker.launch.py model_path:=$MODEL target_topic:=/mocap/leo/pose max_vel:=0.3"
```

Make executable: `chmod +x test_rl_tracker.sh`

Run: `./test_rl_tracker.sh`

## Troubleshooting Reference

### Issue: "ModuleNotFoundError: No module named 'rclpy._rclpy_pybind11'"
**Cause**: Using Python 3.11 from micromamba instead of system Python 3.10  
**Fix**: `micromamba deactivate` then source ROS 2

### Issue: "Segmentation fault" or exit code -11
**Cause**: NumPy version mismatch with training environment  
**Root Cause**: Model was trained with NumPy 2.2.6, but system had NumPy 1.26.4  
**Fix**: `python3 -m pip install --upgrade "numpy>=2.0,<3.0"`  
**Verify**: `python3 -c "import numpy; print(numpy.__version__)"` should show 2.x

### Issue: "ModuleNotFoundError: No module named 'numpy._core.numeric'"
**Cause**: NumPy 1.x trying to load model trained with NumPy 2.x  
**Fix**: Upgrade to NumPy 2.x (see above)

### Issue: Node starts but stops immediately
**Cause**: Model file not found or path incorrect  
**Fix**: Check model path with `ls ~/mml_python_sim/models_recurrent/YOUR_MODEL.zip`

### Issue: "Waiting for sensor data..."
**Normal**: Node is waiting for drone pose and target position  
**Check**: 
- `ros2 topic hz /mavros/local_position/pose` (should be ~30Hz)
- `ros2 topic hz /mocap/leo/pose` (should be ~100Hz)

## Environment Setup Script

Save as `setup_rl_tracker_env.sh`:

```bash
#!/bin/bash
# Source this before running RL tracker

# Deactivate any conda/micromamba
if command -v micromamba &> /dev/null; then
    micromamba deactivate 2>/dev/null || true
fi

if command -v conda &> /dev/null; then
    conda deactivate 2>/dev/null || true
fi

# Source ROS 2
source /opt/ros/humble/setup.bash

# Source workspace
source ~/mml_python_sim/install/setup.bash

# Verify setup
echo "Python: $(python3 --version)"
echo "NumPy: $(python3 -c 'import numpy; print(numpy.__version__)')"
echo "ROS 2: $ROS_DISTRO"
echo ""
echo "Ready to launch RL tracker!"
```

Usage: `source setup_rl_tracker_env.sh`

## Parameter Quick Reference

| Parameter | Default | Recommended | Description |
|-----------|---------|-------------|-------------|
| `model_path` | (required) | Latest final model | Full path to .zip |
| `target_topic` | `/mocap/leo/pose` | Keep default | Target mocap topic |
| `drone_height` | `1.0` | `1.0` - `2.0` | Flight altitude (m) |
| `max_vel` | `0.5` | Start: `0.3` | Max velocity (m/s) |
| `num_particles` | `200` | `200` - `500` | Particle filter |
| `prediction_method` | `Velocity` | `Velocity` or `Transformer` | Target motion model |

## Success Indicators

When working correctly:
```
[INFO] [rl_offboard_tracker]: === RL Offboard Tracker ===
[INFO] [rl_offboard_tracker]: Model: .../recurrent_ppo_tracking_final_20251216_151239.zip
[INFO] [rl_offboard_tracker]: Coordinate System: Meters, origin at center (-3 to +3m)
[INFO] [rl_offboard_tracker]: Waiting for sensor data...
[INFO] [rl_offboard_tracker]: Target at: [1.23, -0.45]m
[INFO] [rl_offboard_tracker]: Action: vx=0.15, vy=-0.08, omega=0.02
```

## Ready to Fly Checklist

- [ ] `micromamba deactivate` executed
- [ ] `python3 --version` shows 3.10.x
- [ ] `python3 -c "import numpy; print(numpy.__version__)"` shows >= 1.23.5
- [ ] `source /opt/ros/humble/setup.bash` executed
- [ ] `source ~/mml_python_sim/install/setup.bash` executed
- [ ] Model file exists and path is correct
- [ ] MAVROS running (for real flight)
- [ ] OptiTrack publishing target position
- [ ] RC transmitter ready for manual override

---

**Your RL tracker is now properly configured and ready to use!** 🚀
