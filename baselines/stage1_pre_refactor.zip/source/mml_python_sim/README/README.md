# Target Tracking Simulation Framework

A simulation framework for multi-agent target tracking research. This framework supports various control and guidance strategies, with particular emphasis on Adaptive Dynamic Programming (ADP) policies and information-driven guidance approaches from the `mml_guidance` package.


### Setup
```bash
# Install required packages
pip install -r requirements.txt
```

## Usage

Change the problem structure, including number of targets in `config.yaml`. 

### Basic Target Tracking Simulation
```bash
python pd_tracker.py
```
Runs the tracking problem using a PD controller.

### Multi-Agent Coordination
```bash
python multi_adp.py
```
Demonstrates multiple agents coordinating to track multiple targets using an ADP policy.

### Information-Driven Guidance
```bash
python info_mml_main.py
```
Shows information-theoretic guidance using particle filtering and entropy optimization from the `mml_guidance` package.

### Custom Simulations
You can create custom simulations by:
1. Modifying `config.yaml` for different scenarios
2. Adjusting environment parameters in `pygame_large_env.py`
3. Implementing new control strategies in the `adp/` directory OR 
4. Using guidance functions from `mml_guidance/` for information-driven approaches OR
5. Create your own policy. 

## License

This project is licensed under the MIT License - see the LICENSE file for details.
