﻿# Project Structure for Search PPO Training

## Overview

This project implements a dual-policy system for multi-target tracking:
- **Tracking Policy**: Uses particle filter estimates (trained with RecurrentPPO)
- **Search Policy**: Blind search when tracks are lost (trained with RecurrentPPO)

## Folder Structure

\`\`\`
mml_python_sim/
│
├── environments/               # Environment wrappers
│   ├── __init__.py
│   ├── pygame_large_env.py     # Core physics/simulation
│   ├── gym_pursuit_env.py      # Wrapper for TRACKING task
│   └── gym_search_env.py       # Wrapper for SEARCH task
│
├── training/                   # Training scripts
│   ├── __init__.py
│   ├── train_tracking_ppo.py   # Train tracking policy
│   └── train_search_ppo.py     # Train search policy
│
├── models/                     # Trained model checkpoints
│   ├── tracking/               # Tracking policy checkpoints
│   └── search/                 # Search policy checkpoints
│
├── info_mml_main.py            # Main evaluation script (uses both policies)
├── train_lstm_ppo.py           # Original training script (kept for compatibility)
└── ...
\`\`\`

## Usage

### 1. Train Tracking Policy
\`\`\`bash
python training/train_tracking_ppo.py --timesteps 1000000
\`\`\`

### 2. Train Search Policy
\`\`\`bash
python training/train_search_ppo.py --timesteps 500000
\`\`\`

### 3. Run Evaluation
\`\`\`bash
python info_mml_main.py
\`\`\`

The evaluation script will automatically:
- Use tracking policy when particle filter has valid tracks
- Switch to search policy when all tracks are lost
- Track metrics for both modes

## Key Differences

| Aspect | Tracking Policy | Search Policy |
|--------|----------------|---------------|
| **Observation** | Particle filter estimates | Agent state + history |
| **Environment** | gym_pursuit_env.py | gym_search_env.py |
| **Reward** | Distance to estimates | Finding actual targets |
| **Training Script** | train_tracking_ppo.py | train_search_ppo.py |
| **Model Location** | models/tracking/ | models/search/ |

## Next Steps

1. Complete implementation of \`environments/gym_search_env.py\`
2. Complete implementation of \`training/train_search_ppo.py\`
3. Update \`info_mml_main.py\` to load both policies and switch between them
4. Train both policies
5. Evaluate combined performance

## Notes

- Original files are kept in root directory for backward compatibility
- Import statements may need updating to use \`from environments.xxx import ...\`
- Both policies use RecurrentPPO (LSTM) for temporal reasoning
