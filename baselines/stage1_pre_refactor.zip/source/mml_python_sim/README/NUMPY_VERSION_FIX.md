# NumPy Version Fix - Critical for Model Loading

## Problem Summary

The trained RL models were created with **NumPy 2.2.6**, but the system initially had **NumPy 1.26.4** installed. This caused:

1. **Exit code -11 (Segmentation Fault)** when launching the RL tracker
2. **ModuleNotFoundError: No module named 'numpy._core.numeric'** when trying to load models

## Root Cause

Models are serialized (pickled) with references to internal NumPy structures. NumPy 2.x reorganized its internal structure (`numpy._core` vs `numpy.core`), making models trained with NumPy 2.x incompatible with NumPy 1.x.

From the model's `system_info.txt`:
```
- OS: Linux-5.14.0-503.40.1.el9_5.x86_64-x86_64-with-glibc2.34
- Python: 3.10.19
- Stable-Baselines3: 2.3.2
- PyTorch: 2.5.1.post303
- GPU Enabled: True
- Numpy: 2.2.6  ← REQUIRED VERSION
- Cloudpickle: 3.1.2
- Gymnasium: 0.28.1
```

## Solution

### 1. Check Current NumPy Version
```bash
python3 -c "import numpy; print(f'NumPy: {numpy.__version__}')"
```

**Expected**: `NumPy: 2.2.6` or any 2.x version  
**Problem**: If shows `1.26.4` or any 1.x version

### 2. Upgrade to NumPy 2.x
```bash
python3 -m pip install --upgrade "numpy>=2.0,<3.0"
```

**Output**:
```
Successfully installed numpy-2.2.6
```

### 3. Verify Installation
```bash
python3 -c "import numpy; print(numpy.__version__)"
```

Should show: `2.2.6`

### 4. Test Model Loading
```bash
python3 -c "
from stable_baselines3 import PPO
model = PPO.load('/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_tracking_final_20251216_151239.zip')
print('✅ Model loaded successfully!')
"
```

## Why This Matters

### Training Environment (HPC Cluster)
- NumPy 2.2.6
- Models pickled with NumPy 2.x internal structures

### Deployment Environment (Drone Computer)
- Initially had NumPy 1.26.4 (from SciPy dependency)
- Tried to load models → **Segmentation Fault**
- Upgraded to NumPy 2.2.6 → **Works!**

## Dependency Conflicts

Upgrading to NumPy 2.x may cause warnings about incompatible packages:

```
WARNING: isaacsim-core 4.5.0.0 requires numpy<2.0.0, but you have numpy 2.2.6
WARNING: cflib 0.1.26 requires numpy~=1.20, but you have numpy 2.2.6
WARNING: cfclient 2024.7.1 requires numpy~=1.20, but you have numpy 2.2.6
```

**Impact**: 
- These packages (isaacsim, cflib, cfclient) won't work with NumPy 2.x
- **However**, the RL tracker requires NumPy 2.x to load trained models
- **Trade-off**: RL tracking functionality vs Isaac Sim/Crazyflie compatibility

**Recommendation**: 
- Use separate Python environments if you need both:
  - **RL tracking environment**: NumPy 2.x (current setup)
  - **Isaac Sim environment**: NumPy 1.x (separate conda/venv)

## Quick Reference

| Component | NumPy Version | Reason |
|-----------|---------------|--------|
| **Training (HPC)** | 2.2.6 | Environment where models were trained |
| **Deployment (Drone)** | 2.2.6+ | Must match training environment |
| **SciPy** | >=1.23.5 | Minimum NumPy for SciPy 1.14.1 |
| **Isaac Sim** | <2.0.0 | Not compatible with NumPy 2.x |
| **Crazyflie** | ~1.20 | Not compatible with NumPy 2.x |

## Test Commands

### Full System Check
```bash
#!/bin/bash
echo "=== Python Environment Check ==="
python3 --version
echo ""

echo "=== NumPy Version (MUST be 2.x) ==="
python3 -c "import numpy; print(f'NumPy: {numpy.__version__}'); assert numpy.__version__.startswith('2.'), 'ERROR: Need NumPy 2.x!'"
echo ""

echo "=== Model Loading Test ==="
python3 -c "
from stable_baselines3 import PPO
import warnings
warnings.filterwarnings('ignore')
model = PPO.load('/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_tracking_final_20251216_151239.zip')
print('✅ Model loads successfully')
print(f'Policy: {type(model.policy).__name__}')
"
echo ""

echo "=== ROS 2 Check ==="
source /opt/ros/humble/setup.bash
python3 -c "import rclpy; print('✅ ROS 2 imports work')"
```

Save as `check_rl_environment.sh`, then:
```bash
chmod +x check_rl_environment.sh
./check_rl_environment.sh
```

## Success Indicators

When the RL tracker launches successfully with NumPy 2.x:

```
[INFO] [rl_offboard_tracker]: === RL Offboard Tracker ===
[INFO] [rl_offboard_tracker]: Model: .../recurrent_ppo_tracking_final_20251216_151239.zip
✓ Loaded RecurrentPPO (LSTM) model
PPO model loaded successfully!
[INFO] [rl_offboard_tracker]: Waiting for sensor data...
[INFO] [rl_offboard_tracker]: Target at: [3.38, 0.51]m
```

**No more segmentation faults!** 🎉

## Troubleshooting

### Still Getting Segmentation Fault?

1. **Verify NumPy version in ROS 2 Python**:
   ```bash
   source /opt/ros/humble/setup.bash
   python3 -c "import numpy; print(numpy.__version__)"
   ```
   Must show `2.x.x`

2. **Check you're not in conda/micromamba environment**:
   ```bash
   which python3  # Should be /usr/bin/python3, NOT ~/micromamba/...
   ```

3. **Reinstall NumPy if needed**:
   ```bash
   python3 -m pip uninstall numpy -y
   python3 -m pip install --upgrade "numpy>=2.0,<3.0"
   ```

### Getting Import Errors from Other Packages?

If you see errors about Isaac Sim or Crazyflie packages:
- These errors are **warnings only** if you're not using those packages
- They don't affect the RL tracker functionality
- Consider using separate virtual environments if you need both

---

**Bottom Line**: Model trained with NumPy 2.2.6 → Deployment needs NumPy 2.x
