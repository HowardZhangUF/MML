# RL Tracker Deployment - Fixed and Ready to Use

## Installation Verified ✅

The `rl_tracker` executable is now correctly installed at:
```
install/mml_guidance/lib/mml_guidance/rl_tracker
```

## Known Issue: NumPy Version

You may see this warning:
```
A NumPy version >=1.23.5 and <2.3.0 is required for this version of SciPy
```

**Solution**: Update NumPy in your ROS environment
```bash
pip install --upgrade numpy>=1.23.5
```

## How to Launch

### Method 1: Using Launch File (Recommended)

```bash
cd ~/mml_python_sim
source install/setup.bash

ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/YOUR_MODEL.zip \
    target_topic:=/mocap/leo/pose \
    drone_height:=1.0 \
    max_vel:=0.3
```

### Method 2: Direct Node Execution

```bash
source install/setup.bash

ros2 run mml_guidance rl_tracker \
    --ros-args \
    -p model_path:=/home/basestation/mml_python_sim/models_recurrent/YOUR_MODEL.zip \
    -p target_topic:=/mocap/leo/pose \
    -p drone_height:=1.0 \
    -p max_vel:=0.3 \
    -p num_particles:=200 \
    -p prediction_method:=Velocity
```

## Before First Flight

### 1. Fix NumPy (if needed)
```bash
pip install --upgrade numpy>=1.23.5
# Verify
python3 -c "import numpy; print(numpy.__version__)"
```

### 2. Verify Your Model Exists
```bash
ls ~/mml_python_sim/models_recurrent/
# Example output: recurrent_ppo_ospa_info_final_20251217_032545.zip
```

### 3. Test Node Startup (Dry Run)
```bash
# This will fail to load model but verifies imports work
ros2 run mml_guidance rl_tracker --ros-args -p model_path:=/tmp/test.zip
# Should see "Loading Model from: /tmp/test.zip" before error
```

### 4. Check Required Topics
```bash
# Verify MAVROS is running
ros2 topic list | grep mavros

# Should see:
# /mavros/local_position/pose
# /mavros/local_position/velocity_local
# /mavros/setpoint_velocity/cmd_vel_unstamped

# Verify mocap target
ros2 topic hz /mocap/leo/pose
```

## Full Example Command

Replace `YOUR_MODEL.zip` with your actual model filename:

```bash
cd ~/mml_python_sim
source install/setup.bash

# Conservative initial flight
ros2 launch mml_guidance rl_tracker.launch.py \
    model_path:=/home/basestation/mml_python_sim/models_recurrent/recurrent_ppo_ospa_info_final_20251217_032545.zip \
    target_topic:=/mocap/leo/pose \
    drone_height:=1.0 \
    max_vel:=0.3 \
    num_particles:=200 \
    prediction_method:=Velocity
```

## Troubleshooting

### "executable 'rl_tracker' not found"
**Cause**: Package not built or sourced  
**Fix**:
```bash
colcon build --packages-select mml_guidance
source install/setup.bash
```

### "ModuleNotFoundError: No module named 'mml_guidance'"
**Cause**: Wrong environment or not sourced  
**Fix**:
```bash
source install/setup.bash
# Verify
python3 -c "import mml_guidance; print('OK')"
```

### "Segmentation fault"
**Cause**: NumPy/SciPy version mismatch  
**Fix**:
```bash
pip install --upgrade numpy scipy
```

### Node starts but no output
**Cause**: Waiting for sensor data  
**Expected**: Node waits for both drone pose and target pose before acting  
**Check**:
```bash
# In another terminal
ros2 topic echo /mavros/local_position/pose
ros2 topic echo /mocap/leo/pose
```

## Quick Verification Checklist

Before arming drone:

- [ ] `colcon build` completed successfully
- [ ] `source install/setup.bash` executed
- [ ] NumPy version >= 1.23.5
- [ ] Model file exists at specified path
- [ ] MAVROS topics publishing (drone pose/velocity)
- [ ] Mocap topic publishing (target position)
- [ ] RL tracker node running without errors
- [ ] RC transmitter ready for manual override
- [ ] Clear flight area

## Parameter Reference

| Parameter | Default | Description |
|-----------|---------|-------------|
| `model_path` | (required) | Path to trained .zip model |
| `target_topic` | `/mocap/leo/pose` | Target position topic |
| `drone_height` | `1.0` | Target altitude (meters) |
| `max_vel` | `0.5` | Max velocity limit (m/s) |
| `num_particles` | `200` | Particle filter particles |
| `prediction_method` | `Velocity` | PF prediction: Velocity/KF/Transformer/NN |

## What Happens When You Launch

1. **Node starts** and declares parameters
2. **Loads PPO model** from specified path
3. **Initializes particle filter** for target tracking
4. **Subscribes** to drone pose, velocity, and target position
5. **Waits** for sensor data (drone + target)
6. **Control loop** at 20Hz:
   - Gets drone state from MAVROS
   - Gets target estimate from particle filter
   - Runs policy inference
   - Publishes velocity commands to MAVROS

## Success Indicators

When working correctly, you'll see:
```
[INFO] [rl_offboard_tracker]: === RL Offboard Tracker ===
[INFO] [rl_offboard_tracker]: Model: /path/to/model.zip
[INFO] [rl_offboard_tracker]: Target Topic: /mocap/leo/pose
[INFO] [rl_offboard_tracker]: Drone Height: 1.0m
[INFO] [rl_offboard_tracker]: Max Velocity: 0.3m/s
[INFO] [rl_offboard_tracker]: Waiting for sensor data...
[INFO] [rl_offboard_tracker]: Target at: [1.23, -0.45]m
[INFO] [rl_offboard_tracker]: Action: vx=0.15, vy=-0.08, omega=0.02
```

---

**Your RL policy is ready to fly!** 🚁

See `RL_DEPLOYMENT_QUICKSTART.md` for detailed flight procedures.
