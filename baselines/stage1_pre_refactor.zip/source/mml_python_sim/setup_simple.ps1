﻿#!/usr/bin/env pwsh
<#
.SYNOPSIS
    Setup project structure for Search PPO training.

.DESCRIPTION
    Creates folders and files for organizing the Search PPO training pipeline:
    - environments/ folder with wrappers
    - training/ folder with training scripts
    - models/ folder structure for checkpoints

.NOTES
    Run this from the mml_python_sim root directory:
    .\setup_project_structure.ps1
#>

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setting up Search PPO Project Structure" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Get the script directory (should be mml_python_sim root)
$rootDir = $PSScriptRoot
Write-Host "Root directory: $rootDir" -ForegroundColor Yellow
Write-Host ""

# ============================================================
# 1. CREATE FOLDER STRUCTURE
# ============================================================
Write-Host "Step 1: Creating folder structure..." -ForegroundColor Green

$foldersToCreate = @(
    "environments",
    "training",
    "models\tracking",
    "models\search"
)

foreach ($folder in $foldersToCreate) {
    $folderPath = Join-Path $rootDir $folder
    if (-not (Test-Path $folderPath)) {
        New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
        Write-Host "  ✓ Created: $folder" -ForegroundColor Green
    } else {
        Write-Host "  ○ Already exists: $folder" -ForegroundColor Gray
    }
}

Write-Host ""

# ============================================================
# 2. CREATE __init__.py FILES
# ============================================================
Write-Host "Step 2: Creating __init__.py files..." -ForegroundColor Green

$initFiles = @(
    "environments\__init__.py",
    "training\__init__.py"
)

foreach ($initFile in $initFiles) {
    $initPath = Join-Path $rootDir $initFile
    if (-not (Test-Path $initPath)) {
        $content = "# $($initFile -replace '\\', '/')`n"
        Set-Content -Path $initPath -Value $content -Encoding UTF8
        Write-Host "  ✓ Created: $initFile" -ForegroundColor Green
    } else {
        Write-Host "  ○ Already exists: $initFile" -ForegroundColor Gray
    }
}

Write-Host ""

# ============================================================
# 3. MOVE EXISTING FILES TO environments/
# ============================================================
Write-Host "Step 3: Moving existing environment files..." -ForegroundColor Green

$filesToMove = @(
    @{Source = "pygame_large_env.py"; Dest = "environments\pygame_large_env.py"},
    @{Source = "gym_pursuit_env.py"; Dest = "environments\gym_pursuit_env.py"}
)

foreach ($fileInfo in $filesToMove) {
    $sourcePath = Join-Path $rootDir $fileInfo.Source
    $destPath = Join-Path $rootDir $fileInfo.Dest
    
    if (Test-Path $sourcePath) {
        if (-not (Test-Path $destPath)) {
            Move-Item -Path $sourcePath -Destination $destPath -Force
            Write-Host "  ✓ Moved: $($fileInfo.Source) → $($fileInfo.Dest)" -ForegroundColor Green
        } else {
            Write-Host "  ⚠ Destination already exists, skipping: $($fileInfo.Dest)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  ⚠ Source not found: $($fileInfo.Source)" -ForegroundColor Yellow
    }
}

Write-Host ""

# ============================================================
# 4. MOVE EXISTING TRAINING SCRIPT TO training/
# ============================================================
Write-Host "Step 4: Moving training script..." -ForegroundColor Green

$trainSource = Join-Path $rootDir "train_lstm_ppo.py"
$trainDest = Join-Path $rootDir "training\train_tracking_ppo.py"

if (Test-Path $trainSource) {
    if (-not (Test-Path $trainDest)) {
        Copy-Item -Path $trainSource -Destination $trainDest -Force
        Write-Host "  ✓ Copied: train_lstm_ppo.py → training\train_tracking_ppo.py" -ForegroundColor Green
        Write-Host "    (Original kept for backward compatibility)" -ForegroundColor Gray
    } else {
        Write-Host "  ○ Already exists: training\train_tracking_ppo.py" -ForegroundColor Gray
    }
} else {
    Write-Host "  ⚠ Source not found: train_lstm_ppo.py" -ForegroundColor Yellow
}

Write-Host ""

# ============================================================
# 5. CREATE PLACEHOLDER FILES
# ============================================================
Write-Host "Step 5: Creating placeholder files..." -ForegroundColor Green

# gym_search_env.py placeholder
$searchEnvPath = Join-Path $rootDir "environments\gym_search_env.py"
if (-not (Test-Path $searchEnvPath)) {
    $searchEnvContent = @'
"""
Gym wrapper for SEARCH task (when particle filter loses all tracks).

Observation: Agent state + last known position + search coverage history
Reward: High reward for finding targets, penalty for time
NO current target positions in observation!
"""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from environments.pygame_large_env import PygameEnvironment


class GymSearchEnv(gym.Env):
    """
    Environment for training search policy.
    Agent learns to find targets WITHOUT seeing their current positions.
    """
    
    def __init__(self, render_mode=None, max_steps=500):
        super().__init__()
        
        # TODO: Implement search environment
        # Observation space: [agent_pos(2), agent_vel(2), last_known_pos(2), 
        #                     time_lost(1), coverage_features(3)] = 10 dims
        # Action space: [vx, vy, omega]
        # Reward: +100 when target found, -0.1 per step
        
        pass
    
    def reset(self, seed=None, options=None):
        # TODO: Implement reset
        pass
    
    def step(self, action):
        # TODO: Implement step with blind observation and search rewards
        pass
    
    def _get_obs(self):
        # TODO: Build observation WITHOUT current target positions
        pass
    
    def render(self):
        pass
    
    def close(self):
        pass
'@
    Set-Content -Path $searchEnvPath -Value $searchEnvContent -Encoding UTF8
    Write-Host "  ✓ Created: environments\gym_search_env.py (placeholder)" -ForegroundColor Green
} else {
    Write-Host "  ○ Already exists: environments\gym_search_env.py" -ForegroundColor Gray
}

# train_search_ppo.py placeholder
$trainSearchPath = Join-Path $rootDir "training\train_search_ppo.py"
if (-not (Test-Path $trainSearchPath)) {
    $trainSearchContent = @'
"""
Train Recurrent PPO for SEARCH task.

This script trains a separate policy for searching when particle filter loses tracks.
Uses the same PygameEnvironment core but with different observation and reward.
"""
import os
import sys
import argparse
import torch
import numpy as np

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sb3_contrib import RecurrentPPO
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import EvalCallback, CheckpointCallback, CallbackList
from stable_baselines3.common.logger import configure
from environments.gym_search_env import GymSearchEnv
from datetime import datetime


def make_env(rank, seed=0, render_mode=None):
    """Create environment factory function."""
    def _init():
        env = GymSearchEnv(
            render_mode=render_mode,
            max_steps=500
        )
        env.reset(seed=seed + rank)
        return env
    return _init


def train_search_ppo(
    total_timesteps=500_000,
    n_envs=4,
    learning_rate=3e-4,
    n_steps=2048,
    batch_size=64,
    n_epochs=10,
    gamma=0.99,
    gae_lambda=0.95,
    clip_range=0.2,
    ent_coef=0.01,
    vf_coef=0.5,
    max_grad_norm=0.5,
    save_freq=50000,
    eval_freq=10000,
    log_dir="./logs/search",
    model_dir="./models/search",
    seed=42,
    lstm_hidden_size=256,
    n_lstm_layers=1,
    enable_critic_lstm=True,
):
    """
    Train Recurrent PPO for search task.
    """
    # Create directories
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(model_dir, exist_ok=True)
    
    print("=" * 60)
    print("Recurrent PPO Search Training")
    print("=" * 60)
    print(f"Total timesteps: {total_timesteps:,}")
    print(f"Number of environments: {n_envs}")
    print(f"Learning rate: {learning_rate}")
    print(f"LSTM hidden size: {lstm_hidden_size}")
    print("=" * 60)
    
    # TODO: Implement training logic
    # 1. Create vectorized environments
    # 2. Configure RecurrentPPO with LSTM
    # 3. Set up callbacks
    # 4. Train the model
    # 5. Save the model
    
    print("\nTODO: Complete implementation of training loop")
    print("See train_tracking_ppo.py for reference")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train Recurrent PPO for Search")
    parser.add_argument("--timesteps", type=int, default=500_000)
    parser.add_argument("--n_envs", type=int, default=4)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=42)
    
    args = parser.parse_args()
    
    train_search_ppo(
        total_timesteps=args.timesteps,
        n_envs=args.n_envs,
        learning_rate=args.lr,
        seed=args.seed
    )
'@
    Set-Content -Path $trainSearchPath -Value $trainSearchContent -Encoding UTF8
    Write-Host "  ✓ Created: training\train_search_ppo.py (placeholder)" -ForegroundColor Green
} else {
    Write-Host "  ○ Already exists: training\train_search_ppo.py" -ForegroundColor Gray
}

Write-Host ""

# ============================================================
# 6. CREATE README
# ============================================================
Write-Host "Step 6: Creating documentation..." -ForegroundColor Green

$readmePath = Join-Path $rootDir "PROJECT_STRUCTURE.md"
if (-not (Test-Path $readmePath)) {
    $readmeContent = @'
# Project Structure for Search PPO Training

## Overview

This project implements a dual-policy system for multi-target tracking:
- **Tracking Policy**: Uses particle filter estimates (trained with RecurrentPPO)
- **Search Policy**: Blind search when tracks are lost (trained with RecurrentPPO)

## Folder Structure

\`\`\`
mml_python_sim/
│
├── environments/               # Environment wrappers
│   ├── __init__.py
│   ├── pygame_large_env.py     # Core physics/simulation
│   ├── gym_pursuit_env.py      # Wrapper for TRACKING task
│   └── gym_search_env.py       # Wrapper for SEARCH task
│
├── training/                   # Training scripts
│   ├── __init__.py
│   ├── train_tracking_ppo.py   # Train tracking policy
│   └── train_search_ppo.py     # Train search policy
│
├── models/                     # Trained model checkpoints
│   ├── tracking/               # Tracking policy checkpoints
│   └── search/                 # Search policy checkpoints
│
├── info_mml_main.py            # Main evaluation script (uses both policies)
├── train_lstm_ppo.py           # Original training script (kept for compatibility)
└── ...
\`\`\`

## Usage

### 1. Train Tracking Policy
\`\`\`bash
python training/train_tracking_ppo.py --timesteps 1000000
\`\`\`

### 2. Train Search Policy
\`\`\`bash
python training/train_search_ppo.py --timesteps 500000
\`\`\`

### 3. Run Evaluation
\`\`\`bash
python info_mml_main.py
\`\`\`

The evaluation script will automatically:
- Use tracking policy when particle filter has valid tracks
- Switch to search policy when all tracks are lost
- Track metrics for both modes

## Key Differences

| Aspect | Tracking Policy | Search Policy |
|--------|----------------|---------------|
| **Observation** | Particle filter estimates | Agent state + history |
| **Environment** | gym_pursuit_env.py | gym_search_env.py |
| **Reward** | Distance to estimates | Finding actual targets |
| **Training Script** | train_tracking_ppo.py | train_search_ppo.py |
| **Model Location** | models/tracking/ | models/search/ |

## Next Steps

1. Complete implementation of \`environments/gym_search_env.py\`
2. Complete implementation of \`training/train_search_ppo.py\`
3. Update \`info_mml_main.py\` to load both policies and switch between them
4. Train both policies
5. Evaluate combined performance

## Notes

- Original files are kept in root directory for backward compatibility
- Import statements may need updating to use \`from environments.xxx import ...\`
- Both policies use RecurrentPPO (LSTM) for temporal reasoning
'@
    Set-Content -Path $readmePath -Value $readmeContent -Encoding UTF8
    Write-Host "  ✓ Created: PROJECT_STRUCTURE.md" -ForegroundColor Green
} else {
    Write-Host "  ○ Already exists: PROJECT_STRUCTURE.md" -ForegroundColor Gray
}

Write-Host ""

# ============================================================
# 7. SUMMARY
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Created folder structure:" -ForegroundColor Yellow
Write-Host "  ✓ environments/" -ForegroundColor Green
Write-Host "  ✓ training/" -ForegroundColor Green
Write-Host "  ✓ models/tracking/" -ForegroundColor Green
Write-Host "  ✓ models/search/" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. Complete implementation of environments/gym_search_env.py" -ForegroundColor White
Write-Host "  2. Complete implementation of training/train_search_ppo.py" -ForegroundColor White
Write-Host "  3. Update info_mml_main.py to use dual-policy system" -ForegroundColor White
Write-Host "  4. Train both policies" -ForegroundColor White
Write-Host ""
Write-Host "See PROJECT_STRUCTURE.md for detailed documentation." -ForegroundColor Cyan
Write-Host ""
