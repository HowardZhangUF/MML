import pygame
import pymunk
import numpy as np
from pymunk.vec2d import Vec2d
from math import sqrt


class Player:
    def __init__(
        self,
        space: pymunk.Space,
        mass=1.0,
        window_size=750.0,
        position=None,
        positionRadius=200.0,
        max_lin_velx=150.0,
        max_lin_vely=10.0,
        max_ang_vel=np.pi,
        timeConst=0.25,
        is_target=False,
        collision_type=2,
        use_initial_conditions=False,
    ):
        if is_target:
            self.image = pygame.image.load("./env_images/opponent.png")
            self.image_ghost = pygame.image.load("./env_images/opponent.png")
            # print("target")
        else:
            self.image = pygame.image.load("./env_images/player.png")
            self.image_ghost = pygame.image.load("./env_images/player.png")
            # print("player")
        self.use_initial_conditions = use_initial_conditions
        self.size = self.image.get_width()
        self.image_ghost.set_alpha(150)
        self.mass = mass
        self.radius = 0.99 * self.image.get_width() // 2
        self.moment = pymunk.moment_for_circle(self.mass, 0, self.radius)
        self.linearResistCx = self.mass / (max_lin_velx * timeConst)
        self.linearResistCy = self.mass / (max_lin_vely * timeConst)
        self.angularResistC = self.moment / (max_ang_vel * timeConst)
        self.maxForcex = self.linearResistCx * max_lin_velx**2
        self.maxForcey = self.linearResistCy * max_lin_vely**2
        self.maxForce = (self.maxForcex**2 + self.maxForcey**2) ** 0.5
        self.max_lin_vel = (max_lin_velx**2 + max_lin_vely**2) ** 0.5
        self.max_ang_vel = max_ang_vel
        self.maxTorque = self.angularResistC * max_ang_vel**2
        self.body = pymunk.Body(self.mass, self.moment, pymunk.Body.KINEMATIC)
        self.shape = pymunk.Circle(self.body, self.radius)
        self.shape.elasticity = 0.5
        self.shape.friction = 0.5
        self.shape.collision_type = collision_type
        self.dead = False
        self.killed_by = 0
        # obstacle is 0
        # wall is 1
        # each player is unique and each target is unique
        self.obstacle_collision_handler = space.add_collision_handler(
            self.shape.collision_type, 0
        )
        self.wall_collision_handler = space.add_collision_handler(
            self.shape.collision_type, 1
        )
        self.player_collision_handler = space.add_collision_handler(
            self.shape.collision_type, 2
        )
        self.target_collision_handler = space.add_collision_handler(
            self.shape.collision_type, 3
        )

        self.obstacle_collision_handler.pre_solve = self.obstacle_collide
        self.wall_collision_handler.pre_solve = self.wall_collide
        self.player_collision_handler.begin = self.player_collide
        self.target_collision_handler.begin = self.target_collide
        self.target_collision_handler.pre_solve = self.target_collide

        if is_target:
            self.shape.color = (255, 0, 0, 255)
        else:
            self.shape.color = (0, 0, 255, 255)
        self.window_size = window_size
        if position is None:
            # Random position within window bounds
            positionArray = np.random.uniform(self.size, self.window_size - self.size, 2)
            self.body.position = (
                positionArray[0],
                positionArray[1],
            )
        else:
            # if choose initial conditions, then choose the location else do random inside
            if self.use_initial_conditions:
                #print("if")
                # choose a location inside the base that isn't already chosen - simple 1:1 coordinates
                self.body.position = position[0], position[1]
            else:
                # print("else")
                # choose a location inside the base that isn't already chosen - simple 1:1 coordinates
                newPosition = np.array(position) + np.random.uniform(
                    -positionRadius / sqrt(2.0), positionRadius / sqrt(2.0), 2
                )
                self.body.position = newPosition[0], newPosition[1]
        self.body.angle = np.random.uniform(-np.pi, np.pi)
        self.startPosition = self.body.position
        self.startAngle = self.body.angle

        space.add(self.body, self.shape)

    def zero(self, position=None, positionRadius=200.0):
        # if position is None:
        #     self.body.position = np.random.uniform(self.image.get_width(),self.window_size-self.image.get_width()),np.random.uniform(self.image.get_width(),self.window_size-self.image.get_width())
        # else:
        #     self.body.position = np.random.uniform(position[0]-positionRadius/sqrt(2.0),position[0]+positionRadius/sqrt(2.0)),np.random.uniform(position[1]-positionRadius/sqrt(2.0),position[1]+positionRadius/sqrt(2.0))
        self.body.angle = np.random.uniform(-np.pi, np.pi)
        self.body.velocity = 0.0, 0.0
        self.body.angular_velocity = 0.0

    def obstacle_collide(self, arbiter, space: pymunk.Space, data):
        self.dead = True
        self.killed_by = 0
        return True

    def wall_collide(self, arbiter, space: pymunk.Space, data):
        self.dead = True
        self.killed_by = 1
        return True

    def player_collide(self, arbiter, space: pymunk.Space, data):
        self.dead = True
        self.killed_by = 2
        return True

    def target_collide(self, arbiter, space: pymunk.Space, data):
        self.dead = True
        self.killed_by = 3
        return True

    def reset(self, space: pymunk.Space, position=None, positionRadius=200.0):
        self.dead = False
        self.killed_by = 0
        if position is None:
            # Random position within window bounds
            self.body.position = np.random.uniform(
                self.image.get_width(), self.window_size - self.image.get_width()
            ), np.random.uniform(
                self.image.get_width(), self.window_size - self.image.get_width()
            )
        else:
            # if choose initial conditions, then choose the location else do random inside
            if self.use_initial_conditions:
                # choose a location inside the base that isn't already chosen - simple 1:1 coordinates
                self.body.position = (
                    position[0],
                    position[1],
                )
            else:
                # choose a location inside the base that isn't already chosen - simple 1:1 coordinates
                newPosition = np.zeros(2)
                newPosition = np.array(position) + np.random.uniform(
                    -positionRadius / sqrt(2.0), positionRadius / sqrt(2.0), 2
                )
                self.body.position = newPosition[0], newPosition[1]
        self.body.angle = np.random.uniform(-np.pi, np.pi)
        self.startPosition = self.body.position
        self.startAngle = self.body.angle
        self.body.velocity = 0.0, 0.0
        self.body.angular_velocity = 0.0
        space.add(self.body, self.shape)

    def updateVelocity(self, linear_vel, angular_vel):
        # Wrap the angle to [-pi, pi]
        self.body.angle = (self.body.angle + np.pi) % (2 * np.pi) - np.pi
        self.body.velocity = linear_vel[0], linear_vel[1]
        self.body.angular_velocity = angular_vel
        # velocityBody = self.body.velocity.rotated(-self.body.angle)
        # resistanceForcex = -self.linearResistCx * abs(velocityBody[0]) * velocityBody[0]
        # resistanceForcey = -self.linearResistCy * abs(velocityBody[1]) * velocityBody[1]

    def updateWrench(self, keyForce=None, keyTorque=None, globalForce=False):
        velocityBody = self.body.velocity.rotated(-self.body.angle)
        resistanceForcex = -self.linearResistCx * abs(velocityBody[0]) * velocityBody[0]
        resistanceForcey = -self.linearResistCy * abs(velocityBody[1]) * velocityBody[1]
        # resistanceForce = Vec2d(resistanceForcex, resistanceForcey)
        # resistanceTorque = -self.angularResistC * abs(self.body.angular_velocity) * self.body.angular_velocity
        # resistanceTorque = 0.0

        # force = resistanceForce
        # torque = resistanceTorque
        force = Vec2d(0.0, 0.0)
        torque = 0.0

        if keyForce is not None and keyTorque is not None:
            inputForce = Vec2d(keyForce[0], keyForce[1])
            if globalForce:
                inputForce = inputForce.rotated(-self.body.angle)
            force += inputForce
            torque += keyTorque
        # # inputTorque = keyTorque
        # print("lin vel "+str(self.body.velocity))
        # print("ang vel "+str(self.body.angular_velocity))
        # print("resist force "+str(resistanceForce))
        # print("resist torque "+str(resistanceTorque))
        # print("input force "+str(force))
        # print("input torque "+str(torque))

        # print("total force "+str(force))
        # print("total torque "+str(torque))
        self.body.apply_force_at_local_point(force=force)
        self.body._set_torque(torque)

    def checkInBounds(self):
        leftOfScreen = self.body.position.x < self.image.get_width() // 2
        rightOfScreen = (
            self.body.position.x > self.window_size - self.image.get_width() // 2
        )
        upOfScreen = (
            self.body.position.y > self.window_size - self.image.get_width() // 2
        )
        downOfScreen = self.body.position.y < self.image.get_width() // 2
        if leftOfScreen or rightOfScreen or upOfScreen or downOfScreen:
            return False
        else:
            return True

    def checkDirection(self, goal):
        before = np.linalg.norm(self.body.position - goal.position)

        x = self.body.position[0]
        y = self.body.position[1]

        x += np.cos(self.body.angle) * 1
        y += np.sin(self.body.angle) * 1

        copy = np.array([x, y])
        after = np.linalg.norm(copy - goal.position)

        return 1 + (before - after)
