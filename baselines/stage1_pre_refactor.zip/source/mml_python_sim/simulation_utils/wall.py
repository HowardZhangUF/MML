import pygame
import pymunk
import numpy as np


class Wall:
    def __init__(self, space, wall, window_size=750.0, fov_size=512, collision_type=0):
        self.mass = np.inf
        self.moment = np.inf
        self.wall = wall
        self.window_size = window_size
        self.fov_size = fov_size
        self.radius = 20
        self.body = pymunk.Body(self.mass, self.moment, pymunk.Body.STATIC)
        self.shape = pymunk.Segment(
            self.body, (0, 0), (self.window_size + self.radius, 0), radius=self.radius
        )
        self.shape.color = (255, 255, 255, 255)
        self.shape.elasticity = 0.5
        self.shape.friction = 0.5
        self.shape.collision_type = collision_type
        if self.wall == 1:
            self.body.position = (0 + self.fov_size, 0 + self.fov_size)
            self.body.angle = np.pi / 2
        elif self.wall == 2:
            self.body.position = (0 + self.fov_size, 0 + self.fov_size)
            self.body.angle = 0
        elif self.wall == 3:
            self.body.position = (
                self.window_size + self.fov_size + self.radius,
                0 + self.fov_size,
            )
            self.body.angle = np.pi / 2
        elif self.wall == 4:
            self.body.position = (
                self.window_size + self.fov_size + self.radius,
                self.window_size + self.fov_size + self.radius,
            )
            self.body.angle = np.pi

        space.add(self.body, self.shape)

    def reset(self, space):
        # if self.wall == 1:
        #     self.body.position = (0+self.fov_size, 0+self.fov_size)
        #     self.body.angle = np.pi / 2
        # elif self.wall == 2:
        #     self.body.position = (0+self.fov_size,0+self.fov_size)
        #     self.body.angle = 0
        # elif self.wall == 3:
        #     self.body.position = (self.window_size+self.fov_size, 0+self.fov_size)
        #     self.body.angle = np.pi / 2
        # elif self.wall == 4:
        #     self.body.position = (self.window_size+self.fov_size, self.window_size+self.fov_size)
        #     self.body.angle = np.pi
        space.add(self.body, self.shape)
