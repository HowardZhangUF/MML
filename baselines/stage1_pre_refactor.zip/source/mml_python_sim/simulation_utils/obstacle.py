import pymunk
import numpy as np
from pymunk.vec2d import Vec2d
from shapely.geometry import Polygon
from math import sqrt


class Obstacle:
    def __init__(
        self,
        space,
        window_size=750.0,
        minSize=100.0,
        maxSize=100.0,
        base_position=None,
        baseRadius=None,
        collision_type=0,
    ):
        self.mass = np.inf
        self.moment = np.inf
        self.window_size = window_size
        self.minSize = minSize
        self.maxSize = maxSize
        self.body = pymunk.Body(self.mass, self.moment, pymunk.Body.STATIC)
        self.shape = pymunk.Poly.create_box(
            self.body,
            size=(
                np.random.uniform(self.minSize, self.maxSize),
                np.random.uniform(self.minSize, self.maxSize),
            ),
        )
        self.shape.color = (255, 255, 255, 255)
        self.shape.elasticity = 0.5
        self.shape.friction = 0.5
        self.shapeRadius = self.maxSize / sqrt(2.0)
        self.shape.collision_type = collision_type

        # print(baseRadius+self.shapeRadius)

        # prevent obstacle from starting in base
        if base_position is not None and baseRadius is not None:
            base_positionArray = np.array(base_position)
            positionArray = np.random.uniform(0.0, self.window_size, 2)

            # print("initial\n"+str(positionArray))

            while np.linalg.norm(base_positionArray - positionArray) < baseRadius:
                positionArray = np.random.uniform(0.0, self.window_size, 2)
                # print("next\n"+str(positionArray))
            self.body.position = positionArray[0], positionArray[1]
        else:
            self.body.position = np.random.uniform(0, self.window_size), np.random.uniform(0, self.window_size)
        self.body.angle = np.random.uniform(-np.pi, np.pi)

        # self.body.angle = 0.0
        rotatedVertices = []
        for v in self.shape.get_vertices():
            x, y = v.rotated(self.body.angle) + self.body.position
            rotatedVertices.append(Vec2d(x, y))
            # print ("shape in world " + str(x) + " " + str(y))
        self.polygon = Polygon(rotatedVertices)  # used to check for communication
        # print ("polygon " + str(self.polygon))
        space.add(self.body, self.shape)

    def reset(self, space, base_position=None, baseRadius=None):
        self.shape = pymunk.Poly.create_box(
            self.body,
            size=(
                np.random.uniform(self.minSize, self.maxSize),
                np.random.uniform(self.minSize, self.maxSize),
            ),
        )
        self.polygon = Polygon(self.shape.get_vertices())
        self.shape.color = (255, 255, 255, 255)
        self.shape.elasticity = 0.5
        self.shape.friction = 0.5

        # prevent obstacle from starting in base or any obstacles
        if base_position is not None and baseRadius is not None:
            base_positionArray = np.array(base_position)
            positionArray = np.random.uniform(0.0, self.window_size, 2)

            intersectsBase = True
            while intersectsBase:
                intersectsBase = False
                positionArray = np.random.uniform(0.0, self.window_size, 2)
                if np.linalg.norm(base_positionArray - positionArray) < (
                    baseRadius + self.shapeRadius
                ):
                    intersectsBase = True

            self.body.position = positionArray[0], positionArray[1]
        else:
            self.body.position = np.random.uniform(0, self.window_size), np.random.uniform(0, self.window_size)
        self.body.angle = np.random.uniform(-np.pi, np.pi)

        # self.body.angle = 0.0
        rotatedVertices = []
        for v in self.shape.get_vertices():
            x, y = v.rotated(self.body.angle) + self.body.position
            rotatedVertices.append(Vec2d(x, y))
            # print ("shape in world " + str(x) + " " + str(y))
        self.polygon = Polygon(rotatedVertices)  # used to check for communication
        # print ("polygon " + str(self.polygon))
        space.add(self.body, self.shape)

    def intersects(self, polygon):
        return polygon.intersects(self.polygon)
