# Recovery Metric Audit and Unified Benchmark Protocol

## Purpose

This document records how recovery is currently computed in:

- `src/mml_guidance/mml_guidance/mml_network/benchmark_diffpf_vs_cfm.py`
- `src/mml_guidance/mml_guidance/mml_network/benchmark_cv_dmmn.py`
- `scripts/metrics.py`

It also defines the recovery protocol that should be used for the paper. The
main correction is to distinguish three different quantities:

1. **Recovery success rate**: the percentage of scheduled occlusion events for
   which the tracker reacquires the target within a fixed horizon.
2. **Recovery latency**: the number of filter updates required to reacquire the
   target after an occlusion ends.
3. **Exit-side accuracy**: whether a motion model predicts the correct side of
   an occlusion. This is a motion-prediction metric, not a tracking recovery
   rate.

The current code reports recovery latency for successful events only. It does
not currently report a failure-aware recovery rate.

## Executive Decision for the Paper

Use one shared, event-level recovery evaluator for every method:

- PF+CFM with fixed sigma
- PF+CFM-AS
- PF+NF
- DiffPF
- PF+CV / `MultiPFVel`
- PF+DMMN / `MultiPFTra`

For every method, report both:

- `Recovery success (%)` with an upward arrow because higher is better.
- `Recovery latency (steps)` with a downward arrow because lower is better.

Also report the number of scheduled events and a failure-aware capped latency.
Do not label a latency such as `6.92 steps` as a percentage or as a recovery
rate.

The recommended table columns are:

| Tracker | RMSE all (m) | RMSE visible (m) | RMSE occluded (m) | Recovery success (%) | Recovery latency (steps) | Capped latency (steps) | Events | Runtime (ms/step) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|

The table caption must not say that every metric is lower-is-better. Recovery
success is higher-is-better.

## Current Data Flow

| File or class | Methods | Benchmark level | Current recovery quantity |
|---|---|---|---|
| `benchmark_diffpf_vs_cfm.py` | PF+CFM fixed, PF+CFM-AS, PF+NF, DiffPF | Standalone filter benchmark | Successful-event recovery latency |
| `benchmark_cv_dmmn.py` | PF+CV, offline PF+DMMN | Standalone filter benchmark | Imports the same successful-event latency code from `benchmark_diffpf_vs_cfm.py` |
| `metrics.py:FilterBenchmarkTracker` | `MultiPFVel`, `MultiPFTra`, and other full-system trackers | `info_mml_main.py` full simulation | Successful-event recovery latency |
| `metrics.py:OcclusionRecoveryTracker` | Motion-model trajectory fans | Full simulation diagnostic | Exit-side prediction accuracy, currently named `modal_recovery_rate` |

`.run.sh` passes `--benchmark_metrics`, so its benchmark `recovery_steps` value
comes from `FilterBenchmarkTracker`. It does not come from
`OcclusionRecoveryTracker` unless `--recovery_metric` is also passed.

## 1. `benchmark_diffpf_vs_cfm.py`

### Functionality

This script is a filter-level benchmark. It creates a simulated trajectory and
visibility mask, runs PF+CFM, PF+CFM-AS, PF+NF, and DiffPF on that trajectory,
and summarizes RMSE, recovery latency, and runtime.

Within a run, all four trackers receive the same target trajectory and the same
visibility schedule. Their random number generators are seeded, so the setup is
appropriate for paired comparisons at the run level.

### Current recovery definition

The relevant constant and function are:

```python
RECOVERY_THRESHOLD = 0.3

def recovery_times(errors, vis_mask):
    times = []
    for t in range(1, len(vis_mask)):
        if vis_mask[t] and not vis_mask[t - 1]:
            k = t
            while k < len(errors) and errors[k] >= RECOVERY_THRESHOLD:
                k += 1
            if k < len(errors):
                times.append(k - t)
    return times
```

For an occluded-to-visible transition at step `t`, the code finds the first
later step `k` with position error below `0.3 m` and records:

\[
\tau_e = k-t.
\]

The `summarize()` function first averages successful events within each run,
then reports the mean and population standard deviation across runs that have a
value.

### Consequences of the current definition

- `6.92` means an average latency of `6.92` filter steps. It is not `6.92%`.
- A result of `0.01 steps` can arise when nearly all successful events recover
  at the exit step (`0`) and a small number recover one step later. It does not
  mean that one step has a recovery rate of `0.01`.
- Events that never reach the threshold before the run ends are omitted.
- Runs with no completed recovery are omitted from the recovery mean.
- There is no fixed recovery deadline.
- The scan may continue through a later loss of visibility or another
  occlusion, so the eventual threshold crossing may not belong cleanly to the
  original event.
- `n_recovery_events` is the number of successful completed events, not the
  number of scheduled occlusion exits.

Therefore, the current value is a **conditional successful-event latency**. It
cannot be used to calculate a recovery percentage because the failure
denominator is not retained.

### Required implementation for the standard protocol

Replace `recovery_times()` with the shared event scorer defined below. This
script should:

1. Generate the event list once from the common truth and visibility schedule.
2. Assign stable event IDs such as `(run_seed, target_id, event_index)`.
3. Score every method against exactly that event list.
4. Save both successful and failed events to an event-level CSV.
5. Aggregate the event rows instead of averaging a list containing only
   successes.

Conceptual call site:

```python
events = extract_recovery_events(
    physically_occluded=physically_occluded,
    evaluation_available=evaluation_available,
    run_seed=run_seed,
    horizon_steps=config.horizon_steps,
)

event_rows = score_recovery_events(
    events=events,
    assigned_errors=errors,
    config=config,
    method=name,
)
```

The event list must be constructed outside the method loop. That prevents one
method from receiving a different denominator.

## 2. `benchmark_cv_dmmn.py`

### Functionality

This script adds the standalone PF+CV and offline PF+DMMN filter baselines. It
uses the offline ScratchTransformer checkpoint for DMMN and runs both methods on
the same generated trajectory and visibility mask.

The script currently imports these components from
`benchmark_diffpf_vs_cfm.py`:

```python
from benchmark_diffpf_vs_cfm import (
    BootstrapPFTracker,
    recovery_times,
    run_tracker,
    summarize,
)
```

It uses trajectory seed `1000 + run`, measurement seed `5000 + run`, and PF /
Torch seed `9000 + run` for both PF+CV and PF+DMMN.

### Current recovery definition

`benchmark_cv_dmmn.py` does not define a separate recovery metric. After each
tracker run, it calls:

```python
rec = recovery_times(errors, vis_mask)
```

It therefore has exactly the same definition and limitations as
`benchmark_diffpf_vs_cfm.py`:

- recovery is latency in steps;
- only successful threshold crossings are saved;
- failures and the scheduled event denominator are not saved;
- per-run latency is the mean of successful events in that run;
- runs without a successful event become missing values.

### Required implementation for the standard protocol

This file should not implement its own recovery formula. It should import the
same shared event extractor and scorer used by the four-method benchmark:

```python
from recovery_metrics import (
    RecoveryConfig,
    extract_recovery_events,
    score_recovery_events,
    summarize_recovery_events,
)
```

For each seed, construct one event list and reuse it for PF+CV and PF+DMMN. The
event IDs and seed schedule must also match the event IDs used by PF+CFM-AS when
performing paired tests.

Do not append corrected PF+CV/PF+DMMN recovery values to a table containing the
old four-method recovery definition. Either rescore all six methods from stored
per-step outputs or rerun only the recovery evaluation under the unified
protocol.

## 3. `scripts/metrics.py`

This file contains two different recovery-related classes. They must not share
the same metric name in the paper.

### A. `FilterBenchmarkTracker`

#### Functionality

`FilterBenchmarkTracker` collects full-system benchmark metrics from
`scripts/info_mml_main.py`. At each tracking update it:

- performs Hungarian assignment between true positions and confirmed tracks;
- records matched-target position errors;
- separates visible and unavailable-measurement errors;
- records filter-loop runtime;
- detects unavailable-to-available measurement transitions;
- records the steps until assigned error is below `0.3 m`.

In `info_mml_main.py`, the `visible` argument passed to this class is currently
`guidance.filter.is_update`. It means that a measurement is available because
the target is in the agent FOV and outside an occlusion. It is not a pure
physical-occlusion indicator.

#### Current recovery definition

For each target, a pending recovery starts when:

```python
visible[target_id] and not previous_visibility[target_id]
```

provided that the target was visible at least once previously. While a recovery
is pending, the class increments a counter until the Hungarian-assigned error is
finite and less than `recovery_threshold`. It then appends the counter to
`self.recovery_steps`.

The run summary contains:

```python
"recovery_steps": mean(self.recovery_steps)
"n_recoveries": len(self.recovery_steps)
```

Again, `n_recoveries` counts successful completions only. Pending failures at
the end of a run are not finalized or written to the CSV.

There are two additional interpretation problems in the full-system path:

1. Measurements are added before the benchmark error is evaluated. The first
   post-occlusion measurement can therefore make recovery latency zero.
2. The current detections are exact true positions (`z_[i, :2]`) in this path.
   With no measurement noise, same-update recovery is especially likely.

The existing 100-run full-system files illustrate the denominator problem:

- `MultiPFVel` saved 888 successful recoveries across 100 runs.
- `MultiPFTra` saved 936 successful recoveries across 100 runs.
- 7 `MultiPFVel` runs and 10 `MultiPFTra` runs had no successful recovery value
  and were excluded from the recovery-latency mean.

The files do not record the number of scheduled events, so these counts cannot
separate different exposure schedules from actual recovery failures.

#### Required implementation for the standard protocol

`FilterBenchmarkTracker.append()` should receive two different masks:

```python
append(
    true_positions,
    tracked_positions,
    measurement_available,
    physically_occluded,
    runtime_ms,
    step,
)
```

- `physically_occluded` defines entry and exit from fixed occlusion geometry.
- `measurement_available` records sensor/FOV availability and is used for the
  visible RMSE split.

The tracker must retain one row per scheduled event, including unresolved
events. It also needs a `finalize()` method that marks all expired or open events
as failures instead of silently dropping them.

For motion-model evaluation, record the assigned error twice at an exit:

- **Exit-prior error**: before consuming the first post-occlusion measurement.
- **Post-update recovery latency**: after normal filtering updates resume.

The exit-prior error tests propagation through the occlusion. Post-update
latency tests tracker reacquisition. Reporting both avoids a zero-step
measurement update hiding differences between motion models.

#### Full-system fairness limitation

In a policy-in-the-loop experiment, different trackers can change the agent
trajectory and therefore change the FOV measurement schedule. Such a result is
a valid end-to-end system comparison, but it is not a paired filter-recovery
experiment.

For the paper's filter recovery claim, use a frozen replay:

- save one truth trajectory, agent trajectory, physical-occlusion mask, and
  noisy detection stream per seed;
- replay that identical stream for every tracker;
- build the scheduled event list once per replay;
- verify that every method has exactly the same event IDs.

The policy-in-the-loop result can be reported separately as a system-level
metric, together with exposure counts and matched-target fraction.

### B. `OcclusionRecoveryTracker`

#### Functionality

`OcclusionRecoveryTracker` evaluates the trajectory fan generated when a target
enters an occlusion. It records whether the fan predicts an exit above or below
the occlusion center and compares that prediction with the actual exit side.

Its current `modal_recovery_rate()` is:

\[
\text{modal accuracy}
= \frac{1}{N}\sum_{e=1}^{N}
  \mathbf{1}[\widehat{s}_e=s_e].
\]

The displayed percentage is this mean multiplied by 100. `mean_prob_correct()`
instead averages the fan probability mass placed on the actual side.

This class does not measure position-error recovery or recovery steps.

#### Required naming and reporting

Rename the paper-facing metric to avoid ambiguity:

- `modal_recovery_rate` -> `exit_side_accuracy`
- `mean_prob_correct` -> `mean_correct_side_probability`

The old method name may remain as a temporary compatibility alias, but CSV
headers, plot labels, and paper text should use `exit_side_accuracy`.

Pending entries at the end of a run should be reported as censored exit-side
events or excluded under a documented event-completion rule. They must not be
mixed into tracker reacquisition success.

## Unified Mathematical Definition

### Common event set

For run `r`, target `j`, and update `t`, define:

\[
o_{rjt} =
\begin{cases}
1, & \text{target }j\text{ is inside fixed physical occlusion geometry},\\
0, & \text{otherwise}.
\end{cases}
\]

An occlusion entry occurs when `o[r,j,t-1] = 0` and `o[r,j,t] = 1`. An exit
occurs at `t_e` when `o[r,j,t_e-1] = 1` and `o[r,j,t_e] = 0`.

The valid event set `E` must be generated from truth before any tracker is run.
Only include events that have the complete preregistered evaluation window. For
example, require that `t_e + H` is inside the replay. Apply this rule once to
the common event list, never separately by method.

### Assigned position error

Let `pi_t(j)` be the Hungarian assignment from true target `j` to a confirmed
track at update `t`. Define:

\[
e_{m,e}(k) =
\begin{cases}
\left\|\widehat{x}^{m}_{\pi_{t_e+k}(j),t_e+k}
-x_{j,t_e+k}\right\|_2,
& \text{if target }j\text{ is matched},\\
+\infty, & \text{if target }j\text{ is unmatched}.
\end{cases}
\]

An unmatched target must therefore count against recovery instead of
disappearing from the metric.

### Success and latency

Choose these values before looking at the final benchmark results:

- distance threshold `delta = 0.3 m`;
- recovery horizon `H` in filter updates;
- confirmation length `M`, recommended `M = 3` consecutive updates.

For event `e` and method `m`, define recovery latency as the first update `k`
whose next `M` assigned errors are all below the threshold:

\[
\tau_{m,e} =
\min\left\{
k\in\{0,\ldots,H-M+1\}: 
e_{m,e}(k+q)<\delta\ \forall q\in\{0,\ldots,M-1\}
\right\}.
\]

If no such `k` exists, set the event success indicator to zero:

\[
S_{m,e}=\mathbf{1}[\tau_{m,e}\text{ exists}].
\]

A latency of zero is valid: it means the tracker is already within the
threshold at the first evaluated post-exit update and remains there for the
confirmation window.

### Primary recovery summaries

The pooled event-level success rate is:

\[
R_m = 100\,\frac{\sum_{e\in E}S_{m,e}}{|E|}.
\]

The conditional latency among successful events is:

\[
L_m^{\mathrm{success}} =
\frac{\sum_{e\in E}S_{m,e}\tau_{m,e}}
     {\sum_{e\in E}S_{m,e}}.
\]

Because conditional latency alone can favor a method that recovers only on easy
events, also define a failure-aware capped latency:

\[
\widetilde{\tau}_{m,e} =
\begin{cases}
\tau_{m,e}, & S_{m,e}=1,\\
H+1, & S_{m,e}=0,
\end{cases}
\qquad
L_m^{\mathrm{capped}} =
\frac{1}{|E|}\sum_{e\in E}\widetilde{\tau}_{m,e}.
\]

Report `R_m`, conditional latency, median successful latency, capped latency,
and `|E|`. The paper must state `delta`, `H`, `M`, the filter update frequency,
and whether evaluation is before or after the measurement update.

## Shared Code Design

Recovery should not have three independent implementations. Add one shared
module, for example `scripts/recovery_metrics.py`, and import it from both
standalone benchmark scripts and `scripts/metrics.py`.

Recommended public API:

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class RecoveryConfig:
    threshold_m: float = 0.3
    horizon_steps: int = 30
    consecutive_steps: int = 3


def extract_recovery_events(
    physically_occluded,
    run_seed,
    horizon_steps,
):
    """Return method-independent events with stable IDs."""


def score_recovery_events(
    events,
    assigned_errors,
    method,
    config,
):
    """Return one row per event, including failures."""


def summarize_recovery_events(event_rows):
    """Return pooled success, conditional latency, and capped latency."""
```

Each event-level CSV row should contain at least:

```text
method
run
seed
target_id
event_index
event_id
entry_step
exit_step
deadline_step
threshold_m
horizon_steps
consecutive_steps
recovered
recovery_steps
capped_recovery_steps
exit_prior_error_m
```

The `recovery_steps` field should be blank for failure, while
`capped_recovery_steps` must be `H + 1`. This preserves both the conditional
latency and the failure-aware value without overloading one column.

## Aggregation and Statistical Comparison

Use event-pooled success as the primary recovery rate:

```text
total successful events / total scheduled events
```

Do not average only runs with successful events. Per-run rates may be included
as a secondary mean and standard deviation, but zero-event or zero-success runs
must have an explicit, documented treatment.

For comparison with PF+CFM-AS:

- pair rows by `event_id`;
- assert that the event-ID set is identical for every method;
- use paired bootstrap confidence intervals clustered by run;
- compare paired success outcomes with McNemar's test;
- compare latency only with a clearly stated paired subset or use a censored
  time-to-recovery analysis;
- report the number of events and runs used by every test.

## Controlled Recovery Benchmark

The ordinary `100 runs x 2000 steps` benchmark does not guarantee exactly the
same number of natural occlusions in every run. That is acceptable if the event
schedule is identical across methods and pooled event counts are reported.

If the paper requires exactly the same number of events per run, add a separate
controlled recovery benchmark:

1. Pre-generate `K` complete occlusion episodes for each of 100 seeds.
2. Use the same entry state, truth trajectory, noisy measurements, and
   occlusion duration for every method.
3. Ensure every episode has at least `H` post-exit updates.
4. Score all methods on the same `100 x K` event IDs.
5. Report this controlled result as the recovery benchmark and retain the
   2000-step result as the natural-trajectory benchmark.

This is preferable to extending individual runs until each tracker happens to
observe `K` events, because tracker-dependent stopping can change the test
distribution.

## Existing Result Disposition

- Existing RMSE and runtime values can remain as historical benchmark outputs
  if their protocols are otherwise unchanged.
- Existing `Recovery (steps)` values for the first four standalone methods are
  successful-event latencies, not rates.
- Existing standalone PF+CV/PF+DMMN values use the same old latency function,
  but they must not be mixed with full-system `MultiPFVel`/`MultiPFTra` values.
- Existing full-system recovery summaries cannot be converted into correct
  recovery rates because scheduled events and failed events were not saved.
- Correct recovery results require rescoring stored per-step errors and masks,
  if those arrays exist, or rerunning the recovery benchmark with event-level
  logging.

## Verification Checklist

Before publishing a recovery table, verify all of the following:

- [ ] All methods use the same truth trajectories and noisy detection streams.
- [ ] All methods have exactly the same sorted set of `event_id` values.
- [ ] Physical occlusion and measurement availability are stored separately.
- [ ] The event list is created before tracker execution.
- [ ] Unmatched targets have infinite error for recovery scoring.
- [ ] Failed and run-end events remain in the denominator.
- [ ] `delta`, `H`, and `M` are fixed before final evaluation.
- [ ] Update order is documented as pre-measurement or post-measurement.
- [ ] Exit-prior error is reported when evaluating motion propagation.
- [ ] Recovery success is labeled `%` and higher-is-better.
- [ ] Recovery latency is labeled `steps` and lower-is-better.
- [ ] Exit-side accuracy is not called tracker recovery rate.
- [ ] Event counts and paired statistical tests are reported.

