# Configuration
$guidance_modes = @("MultiPFInfo", "MultiPFInfoPPO", "MultiPFInfoPPO_LSTM")
$prediction_methods = @("MultiPFTra", "MultiPFVel")
$num_runs = 10

# Create output directory
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$output_dir = "experiment_results_$timestamp"
New-Item -ItemType Directory -Path $output_dir -Force | Out-Null

Write-Host "`n🚀 Starting Experiment Suite" -ForegroundColor Green
Write-Host "Output directory: $output_dir"
Write-Host "Runs per mode: $num_runs`n"

foreach ($guidance_mode in $guidance_modes) {
    Write-Host "`n$('#' * 60)" -ForegroundColor Cyan
    Write-Host "# Experiments for: $guidance_mode" -ForegroundColor Cyan
    Write-Host "$('#' * 60)`n" -ForegroundColor Cyan
    
    # Create subdirectory
    $mode_dir = Join-Path $output_dir $guidance_mode
    New-Item -ItemType Directory -Path $mode_dir -Force | Out-Null
    
    for ($i = 0; $i -lt $num_runs; $i++) {
        $run_num = $i + 1
        Write-Host "`nRun $run_num/$num_runs for $guidance_mode..." -ForegroundColor Yellow
        
        # Run simulation
        python info_mml_main.py `
            --guidance_mode $guidance_mode `
            --prediction_method $prediction_method `
            --run_number $i
        
        # Move CSV file
        $csv_name = "${prediction_method}_${guidance_mode}.csv"
        if (Test-Path $csv_name) {
            $new_name = "${prediction_method}_${guidance_mode}_run$($run_num.ToString('00')).csv"
            $dest_path = Join-Path $mode_dir $new_name
            Move-Item -Path $csv_name -Destination $dest_path -Force
            Write-Host "✓ Saved: $dest_path" -ForegroundColor Green
        } else {
            Write-Host "⚠ CSV not found: $csv_name" -ForegroundColor Red
        }
    }
}

Write-Host "`n$('=' * 60)" -ForegroundColor Green
Write-Host "COMPLETED - Results in: $output_dir" -ForegroundColor Green
Write-Host "$('=' * 60)`n" -ForegroundColor Green