"""
Attention-based feature extractor for variable-length target tracking.

Network dimensions (simplified — search_prior branch removed):
  agent_encoder    : 4  → 64
  target_encoder   : 5  → 64  (5 = rel_x, rel_y, rel_vx, rel_vy, confidence)
  transformer      : 64 → 64 per token, 2 layers, 4 heads
  output_layer     : 64 + 64 = 128 → 128
  features_dim     : 128

The search_prior branch (Phase 3) has been removed.
GMM-guided search runs as an algorithmic module in info_mml_main.py,
completely separate from the RL policy.  The policy trains on the
simpler {agent, targets, mask} observation and is easier to converge.
"""
import torch
import torch.nn as nn
import math
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor
from gymnasium import spaces
import numpy as np


class PositionalEncoding(nn.Module):
    def __init__(self, d_model=64, max_len=10):
        super().__init__()
        pe       = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:x.size(1), :]


class AttentionFeatureExtractor(BaseFeaturesExtractor):
    """
    Feature extractor using Transformer attention for multi-target tracking.

    Observation keys consumed:
      'agent'   : [B, 4]      — agent [x, y, vx, vy]
      'targets' : [B, N, 5]   — per-target [rel_x, rel_y, rel_vx, rel_vy, conf]
      'mask'    : [B, N]      — 1=exists, 0=padding

    The confidence dimension (dim 5) carries the state signal:
      conf > 0  → target visible, slot contains real PF estimate
      conf = 0  → target lost, slot zeroed; LSTM h_t carries last trajectory

    Output: [B, 128] feature vector passed to the LSTM policy head.
    """

    def __init__(self, observation_space: spaces.Dict, features_dim: int = 128):
        super().__init__(observation_space, features_dim=features_dim)

        # ── Agent encoder: [x, y, vx, vy] → 64 ──────────────────────────────
        self.agent_encoder = nn.Sequential(
            nn.Linear(4, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
        )

        # ── Target encoder: [rel_x, rel_y, rel_vx, rel_vy, conf] → 64 ───────
        # Reads dim from obs space so it adapts if the schema changes.
        target_feature_dim = observation_space['targets'].shape[-1]   # 5
        self.target_encoder = nn.Linear(target_feature_dim, 64)

        # ── Positional encoding ───────────────────────────────────────────────
        self.positional_encoding = PositionalEncoding(d_model=64, max_len=10)

        # ── Transformer encoder ───────────────────────────────────────────────
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=64,
            nhead=4,
            dim_feedforward=128,
            dropout=0.1,
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=2)

        # ── Output layer: agent(64) + targets(64) → 128 ──────────────────────
        self.output_layer = nn.Sequential(
            nn.Linear(64 + 64, 128),
            nn.ReLU(),
        )

    def forward(self, observations: dict) -> torch.Tensor:
        """
        Args:
            observations:
                'agent'   : [B, 4]
                'targets' : [B, N, 5]
                'mask'    : [B, N]   (1=exists, 0=padding)

        Returns:
            features: [B, 128]
        """
        # Agent branch
        agent_features = self.agent_encoder(observations['agent'])       # [B, 64]

        # Target branch
        target_features = self.target_encoder(observations['targets'])   # [B, N, 64]
        target_features = self.positional_encoding(target_features)

        mask         = observations['mask'].bool()
        padding_mask = ~mask                                              # True = ignore
        target_features = self.transformer(
            target_features,
            src_key_padding_mask=padding_mask,
        )                                                                 # [B, N, 64]

        # Masked mean pool over valid slots
        mask_expanded   = mask.unsqueeze(-1)                             # [B, N, 1]
        masked_features = target_features * mask_expanded
        count           = mask.sum(dim=1, keepdim=True).clamp(min=1)    # [B, 1]
        target_pooled   = masked_features.sum(dim=1) / count            # [B, 64]

        # Fuse and project to 128-D
        combined = torch.cat([agent_features, target_pooled], dim=-1)   # [B, 128]
        return self.output_layer(combined)                               # [B, 128]