# Conditional Flow Matching (CFM) — Codebase Guide

## What is CFM here?

The CFM module implements **OT-CFM (Optimal Transport Conditional Flow Matching)**, a generative model trained to predict target velocity `(vx, vy)` conditioned on a window of recent position history. It replaces the Transformer motion model in the particle filter and produces stochastic velocity proposals at inference time, which is critical for multi-modal target motion.

---

## Related Files

### Core implementation

| File | Role |
|------|------|
| `src/mml_guidance/mml_guidance/mml_network/cfm_motion_model.py` | `CFMMotionModel` (train + infer) and `CFMShim` (drop-in wrapper for ParticleFilter) |
| `src/mml_guidance/mml_guidance/mml_network/velocity_network.py` | Neural net: Transformer context encoder + MLP velocity head |
| `src/mml_guidance/mml_guidance/mml_network/utils.py` | `load_training_csv`, `make_history_dataset`, `chronological_split`, `HistoryBuffer` |
| `src/mml_guidance/mml_guidance/mml_network/__init__.py` | Package exports for all CFM classes and utilities |

### Training

| File | Role |
|------|------|
| `src/mml_guidance/mml_guidance/mml_network/generate_synthetic_data.py` | Simulates 8-node Markov graph trajectories → writes training CSV |
| `src/mml_guidance/mml_guidance/mml_network/train_cfm.py` | Loads CSV, trains `CFMMotionModel`, saves checkpoint + loss curve |
| `src/mml_guidance/models/cfm_motion_model.pth` | Saved checkpoint (weights + full hyperparameter config) |
| `src/mml_guidance/models/cfm_training_loss.png` | Loss curve from last training run |

### Integration / inference

| File | Role |
|------|------|
| `src/mml_guidance/mml_guidance/ParticleFilter.py` | Production particle filter — loads CFM via `load_cfm_model()` when `prediction_method == "CFM"` |
| `src/mml_guidance/mml_guidance/mml_network/particle_filter.py` | Lightweight bootstrap PF for notebooks / unit tests (not production) |
| `scripts/info_mml_main.py` | Simulation entry point — creates `ParticleFilter` with CFM, draws trajectory fan |
| `config.yaml` | Simulation-level parameters (`number_targets`, `dt`, `number_sim_steps`) |

---

## Architecture

```
History window (N_th=10 steps, 2 coords each)
        │
        ▼
 ContextEncoder (Transformer)
   blocks × n_layer, embed dim n_embed
        │  context embedding
        ▼
 VelocityHead (MLP)
   inputs: [x_tau (2), tau (1), context_emb (n_embed)]
        │
        ▼
  u_pred  ← predicted flow velocity field
```

At **training** the network learns the OT-CFM vector field.  
At **inference** Euler integration (N_FE steps) integrates that field to produce a velocity sample.

---

## Step-by-Step: Training

### 1 — Generate synthetic training data

```bash
cd src/mml_guidance/mml_guidance/mml_network
python generate_synthetic_data.py
```

**What it does:**
- Simulates targets moving on an 8-node Markov road graph
- Adds position noise and occlusion gaps (matching real filter behaviour)
- Uses `dt = 0.033 s` (30 Hz pygame timestep)
- Builds sliding windows of `N_th = 10` history steps
- Each row: `X = [x0,y0, x1,y1, ..., x9,y9]`  (20 columns), `y = [vx, vy]`
- Writes: `sim_data/training_data/converted_noisy_5_v2_velocities_training_data.csv`

### 2 — Train the CFM model

```bash
cd src/mml_guidance/mml_guidance/mml_network

# Recommended (matches the saved checkpoint hyperparameters)
python train_cfm.py \
    --epochs 1500 \
    --n_th 10 \
    --n_embed 64 \
    --n_head 8 \
    --n_layer 2 \
    --vel_hidden 128 \
    --n_fe 10 \
    --anchor_sigma 0.3

# Quick smoke-test
python train_cfm.py --epochs 200 --n_th 10

#run the sim
python scripts/info_mml_main.py --prediction_method CFM

#run the sim without fan when using the CFM to reduce the latency.
python scripts/info_mml_main.py --prediction_method CFM --no_fan
```

**Key constraint:** `n_embed` must be divisible by `n_head` (64 / 8 = 8 ✓).

**What happens inside `train_cfm.py`:**
1. Loads and validates CSV shape against `--n_th`
2. Chronological 70/30 train/test split (`chronological_split`)
3. Instantiates `CFMMotionModel` with given hyperparams
4. Calls `cfm.train(X_train, y_train, ...)` — see OT-CFM loop below
5. Evaluates test OT-CFM loss
6. Saves checkpoint: `../../models/cfm_motion_model.pth`
7. Saves loss curve PNG

**OT-CFM training loop** (inside `CFMMotionModel.train`):

```
For each batch (c_batch, y_batch):
    v_anchor = finite_difference_velocity(c_batch)   # (x_k - x_{k-1}) / dt
    x0       = v_anchor + anchor_sigma * N(0, I)     # anchored base point
    tau      ~ Uniform(0, 1)
    x_tau    = (1 - tau) * x0 + tau * y_batch        # linear interpolant
    u_target = y_batch - x0                          # target vector field
    u_pred   = network(x_tau, tau, c_batch)
    loss     = MSE(u_pred, u_target)
```

The cosine-annealing LR scheduler decays from `lr` to `lr * 0.01` over all epochs.

---

## Step-by-Step: Inference

### Loading the model

```python
from mml_guidance.mml_guidance.mml_network.cfm_motion_model import load_cfm_model

motion_model = load_cfm_model(
    model_path="src/mml_guidance/models/cfm_motion_model.pth",
    input_dim=2,
    block_size=10,   # N_th — must match training
    dt=0.033,
)
# Returns CFMShim wrapping a CFMMotionModel.
# Hyperparameters are overridden from the checkpoint config automatically.
```

### Single-step velocity prediction

```python
# X: (N_particles, N_th * 2) — flattened history windows
v_pred = motion_model.predict(X)   # shape: (N_particles, 2)

# Next position
next_pos = current_pos + v_pred * dt
```

**Euler ODE flow** (inside `CFMMotionModel.propose`):

```
encode context → emb  (done once)
x = v_anchor + anchor_sigma * N(0, I)   # anchored start in velocity space
delta = 1 / N_FE
for s in 0 .. N_FE-1:
    tau = s * delta
    v   = network.predict_velocity(x, tau, emb)
    x   = x + delta * v
return x   # final velocity sample (vx, vy)
```

### Multi-step trajectory rollout (visualisation)

`info_mml_main.py` builds a trajectory fan this way:

```python
# build_motion_model_trajectory_fan(pf, n_samples=80, n_steps=30)
#   — samples weighted particles, rolls forward n_steps using pf.motion_model.predict()
```

Or directly via `multi_step_rollout(cfm_model, context, n_steps, n_samples, dt)`.

### Inside the particle filter (production)

`ParticleFilter.py` calls `self.motion_model.predict(X)` every filter step:
- `X` shape: `(N_particles, N_th * 2)`  with `N_th = 10`
- The CFM produces stochastic samples → each particle gets a different velocity draw
- This is what makes CFM superior to the deterministic Transformer for multi-modal targets

---

## Critical Constants — Must Stay Consistent

| Parameter | Value | Where it matters |
|-----------|-------|-----------------|
| `N_th` / `block_size` | **10** | data generation, training `--n_th`, `ParticleFilter.N_th` |
| `input_dim` | **2** `[x, y]` | all three above |
| `dt` | **0.033 s** | velocity label scale in data gen, `CFMMotionModel.dt`, ParticleFilter |
| `n_embed % n_head` | **must be 0** | `train_cfm.py` validates this |

`config.yaml` has `dt: 0.05` — that is the *env step* dt for the outer simulation loop, not the CFM velocity scale.

---

## Data Flow Summary

```
generate_synthetic_data.py
        │
        │  CSV: (N, 20) context + (N, 2) velocity
        ▼
train_cfm.py  ──►  cfm_motion_model.pth
                         │
                         ▼
                  load_cfm_model()
                         │
                         ▼
                    CFMShim.predict()
                         │  (N_particles, 2) velocity
                         ▼
                  ParticleFilter  ──►  particle propagation
                         │
                         ▼
                  Guidance / info_mml_main.py
```
