# Multi-Agent Reinforcement Learning (MARL) for Target Tracking

## QUICK START
```bash
conda activate dee_adp_mml

#training 
python train_marl.py --num_agents 2 --num_targets 2 --timesteps 20000000 --config ../config.yaml

#log
tensorboard --logdir training/models_marl
```

## Overview

This implementation extends the single-agent tracking system to **cooperative multi-agent tracking** using:
- **PettingZoo**: Multi-agent environment API
- **SuperSuit**: Vectorization wrapper for Stable Baselines3 compatibility  
- **RecurrentPPO**: Temporal modeling with LSTM and parameter sharing
- **OSPA Metric**: Optimal Subpattern Assignment for multi-target tracking rewards

## Architecture

```
┌─────────────────────────────────────────────────┐
│  Multi-Agent Tracking Environment (PettingZoo) │
│  - Per-agent partial observations (FOV limited) │
│  - Per-agent particle filters for estimation    │
│  - Shared team reward (OSPA distance)           │
└──────────────────┬──────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│          SuperSuit Vectorization                │
│  - Converts dict observations to tensors        │
│  - Handles action/observation batching          │
└──────────────────┬──────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│        RecurrentPPO (Shared Parameters)         │
│  - Single neural network (parameter sharing)    │
│  - Per-agent LSTM states (memory)               │
│  - Policy: π(a_i | o_i, h_i)                   │
└─────────────────────────────────────────────────┘
```

## Files Modified/Created

### ✅ Modified Files
1. **config.yaml**
   - Changed `number_agents: 1` → `4`
   - Added MARL parameters: `fov_angle`, `fov_range`, `ospa_cutoff`, `reward_type`

2. **environments/pygame_large_env.py**
   - **step()**: Now accepts list of actions `[[vx0,vy0,w0], [vx1,vy1,w1], ...]` with backwards compatibility
   - **getState()**: Fixed to extract ALL agents (was only returning agent[0])

### ✅ New Files Created
3. **utils/ospa_metric.py** (~180 lines)
   - `ospa_distance()`: Main OSPA metric using Hungarian algorithm
   - `decomposed_ospa()`: Returns separate localization and cardinality errors
   - `ospa_reward()`: Converts distance to reward signal

4. **scripts/test_multi_agent.py** (~200 lines)
   - `test_independent_motion()`: Verifies 4 agents move independently (circle, counter-circle, figure-8, spiral)
   - `test_backwards_compatibility()`: Tests single-action broadcast still works
   - `test_collision_detection()`: Validates agent-agent collisions

5. **environments/multi_agent_tracking_env.py** (~520 lines) **[CORE]**
   - PettingZoo `ParallelEnv` wrapper
   - Per-agent partial observations (FOV-limited, with occlusions)
   - Per-agent particle filters for target state estimation
   - Team OSPA-based reward calculation
   - Observation space: `[own_state(6) + target_estimates(5*num_targets)]`
   - Action space: `[vx, vy, omega]` per agent

6. **training/train_marl.py** (~250 lines)
   - Training script using RecurrentPPO
   - SuperSuit vectorization for PettingZoo → SB3
   - Parameter sharing architecture (single network, per-agent LSTM)
   - Configurable hyperparameters (LSTM size, learning rate, etc.)
   - Checkpoint and evaluation callbacks

7. **scripts/eval_marl.py** (~300 lines)
   - Evaluation script for trained models
   - Calculates OSPA metrics per episode
   - Visualization of multi-agent coordination
   - Saves metrics to CSV for analysis

8. **requirements_marl.txt**
   - PettingZoo, SuperSuit, SciPy dependencies

9. **run_marl.sh**
   - Automated setup and training script
   - Installs dependencies, runs tests, starts training

## Quick Start

### 1. Install Dependencies
```bash
conda activate tracking_ppo
pip install -r requirements_marl.txt
```

Or use the automated script:
```bash
./run_marl.sh
```

### 2. Test Multi-Agent Control
```bash
python scripts/test_multi_agent.py
```

This verifies:
- ✅ Independent agent control (4 different motion patterns)
- ✅ Backwards compatibility (single action broadcast)
- ✅ Collision detection between agents

### 3. Train MARL Model
```bash
python training/train_marl.py \
    --num_agents 4 \
    --num_targets 2 \
    --timesteps 2000000 \
    --lstm_size 256 \
    --num_envs 4 \
    --config config.yaml
```

**Training Parameters:**
- `--num_agents`: Number of cooperating agents (default: 4)
- `--num_targets`: Number of targets to track (default: 2)
- `--timesteps`: Total training timesteps (default: 2M)
- `--lstm_size`: LSTM hidden dimension (default: 256)
- `--lr`: Learning rate (default: 3e-4)
- `--num_envs`: Parallel environments for sampling (default: 4)

**Outputs:**
- Checkpoints saved every 50k steps: `models_marl/<run_dir>/checkpoints/`
- Best model (by eval reward): `models_marl/<run_dir>/best_model/`
- TensorBoard logs: `models_marl/<run_dir>/tensorboard/`

### 4. Evaluate Trained Model
```bash
python scripts/eval_marl.py \
    --model models_marl/<run_dir>/best_model/best_model.zip \
    --episodes 10 \
    --render
```

**Evaluation Outputs:**
- Episode metrics: reward, OSPA distance, localization error
- Summary statistics: mean ± std across episodes
- CSV file saved to: `eval_results_marl/eval_<timestamp>.csv`

### 5. Visualize Coordination
```bash
python scripts/eval_marl.py \
    --model models_marl/<run_dir>/final_model.zip \
    --visualize \
    --num_agents 4
```

This opens Pygame window showing real-time multi-agent coordination.

## Key Concepts

### Observation Space (Per Agent)
Each agent receives **partial observations**:
```python
obs = [
    x, y, theta, vx, vy, omega,          # Own state (6 dims)
    est_x1, est_y1, cov_xx1, cov_yy1, detected1,  # Target 1 estimate (5 dims)
    est_x2, est_y2, cov_xx2, cov_yy2, detected2,  # Target 2 estimate (5 dims)
    ...
]
```

**Key Properties:**
- **Local FOV**: Only targets within `fov_range` (2.5m) and `fov_angle` (120°) are detected
- **Occlusions**: Obstacles block line-of-sight
- **State Estimation**: Each agent maintains particle filters for targets
- **Uncertainty**: Covariance values indicate estimation confidence

### Action Space (Per Agent)
Continuous control:
```python
action = [vx, vy, omega]  # Linear velocities (m/s) and angular velocity (rad/s)
```

Bounds: `vx, vy ∈ [-0.6, 0.6]`, `omega ∈ [-5.0, 5.0]`

### Reward Function
**Team OSPA Reward** (shared by all agents):
```python
reward = -ospa_distance(agent_estimates, true_targets, c=10.0, p=2)
```

**OSPA Components:**
1. **Localization Error**: Distance between matched estimates and targets
2. **Cardinality Error**: Penalty for missing targets or false detections

Agents are **fully cooperative** (same reward) to encourage coordination.

### Parameter Sharing
- **Single neural network** shared by all agents (reduces parameters)
- **Per-agent LSTM states** maintain individual memory
- Benefits: Sample efficiency, emergent coordination, scalability

## Configuration (config.yaml)

```yaml
simulation:
  environment:
    number_agents: 4           # Number of tracking agents
    num_targets: 2             # Number of targets
    fov_range: 2.5            # Field-of-view range (meters)
    fov_angle: 120.0          # Field-of-view angle (degrees)
    enable_occlusions: True   # Enable occlusion zones
    num_occlusions: 2         # Number of occlusion zones
    ospa_cutoff: 10.0         # OSPA cutoff parameter (c)
    ospa_order: 2             # OSPA order parameter (p)
    reward_type: "team_ospa"  # Reward type: "team_ospa" | "decomposed_ospa"
```

## Monitoring Training

### TensorBoard
```bash
tensorboard --logdir models_marl/<run_dir>/tensorboard/
```

**Key Metrics:**
- `rollout/ep_rew_mean`: Average episode reward
- `train/policy_loss`: Policy gradient loss
- `train/value_loss`: Value function loss
- `rollout/ep_len_mean`: Average episode length

### Checkpoints
Models are saved every 50k steps:
```
models_marl/<run_dir>/
├── checkpoints/
│   ├── marl_model_50000_steps.zip
│   ├── marl_model_100000_steps.zip
│   └── ...
├── best_model/
│   └── best_model.zip          # Best model by evaluation reward
├── final_model.zip             # Final model after training
└── training_config.yaml        # Training hyperparameters
```

## Troubleshooting

### Issue: "Module 'pettingzoo' not found"
```bash
pip install pettingzoo supersuit
```

### Issue: "step() only accepts single action"
**Solution:** Already fixed in [pygame_large_env.py](environments/pygame_large_env.py). The step() method now handles both:
- Multi-agent: `actions = [[vx0,vy0,w0], [vx1,vy1,w1], ...]`
- Single-agent (backwards compatible): `action = [vx, vy, omega]`

### Issue: Training is slow
**Solutions:**
- Increase `--num_envs` (parallel environments)
- Decrease `--lstm_size` (smaller network)
- Reduce `n_steps` or `batch_size` in training script

### Issue: Agents don't coordinate
**Solutions:**
- Train longer (>2M timesteps)
- Increase LSTM size for better memory
- Tune `ospa_cutoff` parameter (lower = stricter tracking)
- Add reward shaping (e.g., penalty for agent collisions)

## Next Steps

### Experimentation
- **Scalability**: Test with 6, 8, or 10 agents
- **Target Dynamics**: Add faster or adversarial targets
- **Communication**: Add explicit agent-to-agent communication channels
- **Curriculum Learning**: Start with easy scenarios, gradually increase difficulty

### Advanced Features
- **Heterogeneous Agents**: Different agent capabilities (FOV, speed)
- **Attention Mechanisms**: Self-attention for agent-agent interactions
- **Graph Neural Networks**: Model agent relationships explicitly
- **Value Decomposition**: QMIX/QPLEX for credit assignment

## Citation

If using this implementation, please cite the relevant papers:
- **OSPA Metric**: Schuhmacher et al., "A Consistent Metric for Performance Evaluation of Multi-Object Filters" (IEEE Trans. Signal Processing, 2008)
- **RecurrentPPO**: Schulman et al., "Proximal Policy Optimization Algorithms" (arXiv:1707.06347, 2017)
- **PettingZoo**: Terry et al., "PettingZoo: Gym for Multi-Agent Reinforcement Learning" (NeurIPS, 2021)

## Support

For issues or questions:
1. Check TensorBoard logs for training diagnostics
2. Run `scripts/test_multi_agent.py` to verify environment
3. Review episode videos to understand agent behavior
4. Check `eval_results_marl/*.csv` for quantitative metrics

---
**Last Updated:** 2025-02-17  
**Status:** ✅ Ready for training

