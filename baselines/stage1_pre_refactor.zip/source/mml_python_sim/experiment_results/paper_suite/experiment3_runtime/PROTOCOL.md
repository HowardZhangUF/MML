# Experiment 3 protocol

CFM NFE sweep: [1, 2, 5, 10, 20, 50].
Diffusion DDIM step sweep: [1, 2, 5, 10, 20].
Particle count: 250; horizon: 40.
Timing uses 10 warm-up and 50 measured synchronized calls.
Motion inference and complete PF update are timed separately.
Diffusion uses a valid reduced-step DDIM sampler; the checkpoint noise schedule is not overwritten.
Energy Distance is computed using the Experiment 1 protocol.
TRR is computed using scheduled nonzero measurement blackouts and the Experiment 2 recovery definition.
