# Experiment 1 protocol

Motion models are evaluated outside the particle filter.
Scenarios: straight, two_way_balanced, two_way_unbalanced, three_way.
Contexts per scenario: 120.
Predicted and simulator futures per context: 1000 each.
Prediction horizon: 40 updates.
Branch JSD includes off-road as an additional category, so invalid mass is not hidden.
Energy Distance uses full flattened trajectories and at most 200 samples per set.
Off-road means the 90th-percentile distance to the nearest branch centerline exceeds 0.180 m.
Lower is better for all three metrics.
