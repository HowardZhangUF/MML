# Existing-data audit

- **PASS** `Experiment 1 rows`: observed 2400; expected 2400.
- **PASS** `Experiment 1 rows per method/scenario`: observed 120..120; expected 120.
- **PASS** `Experiment 1 duplicate rows`: observed 0; expected 0.
- **PASS** `Experiment 2 rows`: observed 3600; expected 3600.
- **PASS** `Experiment 2 rows per method/road/gap`: observed 40..40; expected 40.
- **PASS** `Experiment 2 methods per paired episode`: observed 6..6; expected 6.
- **PASS** `Experiment 2 shared seed per episode`: observed 1; expected 1.
- **PASS** `Zero-gap controls excluded from recovery`: observed 0; expected 0.
- **PASS** `Nonzero-gap recovery denominator`: observed 2880; expected 2880. 480 scheduled events per method.
- **PASS** `Experiment 3 configurations`: observed 15; expected 15.
- **PASS** `Experiment 3 duplicate rows`: observed 0; expected 0.
