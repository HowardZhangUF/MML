# Evaluation of existing Experiments 1-3

## Scope

This report analyzes existing CSV rows only. No simulator, tracker, or model was rerun.
The current Experiment 1 and 2 scenarios are procedural evaluations outside the fixed training graph.
They are therefore labeled OOD. Because no original-map ID partition is present, this report cannot calculate an ID-to-OOD generalization gap.

## Integrity

All automated integrity checks passed: **True**.
Contexts and episodes, rather than samples, particles, or time steps, are the statistical units.

## Experiment 1: motion distribution

The lowest pooled JSD is produced by **PF+CV**, and the lowest pooled Energy Distance by **PF+CV**.
Across learned methods, pooled off-road rates range from **0.986** to **1.000**.
These off-road rates are a validity warning. They may represent genuine OOD failure, but an original-map diagnostic is required before attributing them to model architecture.
Do not use the pooled OOD ranking as evidence of in-distribution motion-model quality.

## Experiment 2: controlled occlusion

The highest macro-average TRR over nonzero gaps is produced by **PF+CV**.
Adaptive-minus-fixed CFM TRR effects across gaps range from **-0.017** to **0.033**.
Adaptive-minus-fixed occlusion-RMSE effects range from **-0.065** to **-0.003 m**; negative favors adaptive CFM.
TRR and particle-hit comparisons use exact paired McNemar tests. Continuous metrics use paired bootstrap intervals and Wilcoxon tests.
MORT remains success-only and must always be displayed beside TRR or failure-aware latency.

## Experiment 3: quality-runtime tradeoff

The strongest CFM TRR in the sweep is **0.211** at NFE=50 and 15.42 ms.
The strongest diffusion TRR is **0.567** at 2 DDIM steps and 7.34 ms.
The global Energy-Distance frontier is **PF+CV (baseline=1)**; the global TRR frontier is **PF+CV (baseline=1)**.
After excluding CV, the learned-model Energy-Distance frontier is **PF+DMMN (baseline=1), PF+Diffusion (DDIM steps=1)**, and the learned-model TRR frontier is **PF+DMMN (baseline=1), PF+Diffusion (DDIM steps=1), PF+Diffusion (DDIM steps=2)**.
Quality values inherit the same procedural/OOD limitation as Experiments 1 and 2. Runtime values remain useful as descriptive measurements.
The current timing CSV contains one aggregate timing per configuration, so it does not support timing confidence intervals.

## What can be claimed now

- Relative performance on the existing procedural/OOD contexts and scheduled occlusions.
- Paired fixed-versus-adaptive CFM effects on those episodes.
- Descriptive quality-runtime and Pareto comparisons on the existing benchmark.

## What cannot be claimed yet

- An ID-to-OOD generalization gap, because no comparable original-map ID rows exist.
- Effects of different training-data distributions, because the CSVs do not contain checkpoint or training-distribution identifiers.
- That architecture alone caused off-road failure, before the original-map diagnostic passes.

## Minimum next evaluation

Create one cached original-map ID set, run the same frozen checkpoints on it, and append rows with `test_distribution`, `checkpoint_id`, and `train_distribution` columns.
Existing procedural/OOD rows should remain unchanged and become the OOD side of the final comparison.
