# Experiment 2 protocol

Targets and sensor paths are generated once per episode and reused by every method.
Occlusion is a scheduled measurement blackout; target dynamics continue normally.
Road types: straight, two_way, three_way.
Gap lengths: [0, 10, 20, 40, 60]; zero is a control and is excluded from TRR.
Episodes per road/gap cell: 40.
Scheduled nonzero-gap recovery events: 480 per method.
Particle count: 250; hard systematic resampling is shared.
Particle hit radius: 0.300 m at the last hidden update.
Recovery: error below 0.300 m for 3 consecutive updates, with first-streak onset no later than 20 updates after reappearance.
Failures receive a capped benchmark latency of 21; this is not an observed recovery time.
MORT is the successful-recovery mean only and must be reported beside TRR.
Adaptive sigma: sigma=min(2.500, 1+0.050*measurement_age).
