import torch
import numpy as np
from torch import randn
import torch.optim as optim
import torch.nn.functional as F

from .dnn import DNN

use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")
cpu_device = torch.device("cpu")

# uses only the velocity deltas for the dnn since derivative of position is velocity
class ICLv2:
    # constructor to initialize a Dynamics object
    def __init__(
        self,
        lambda_1: torch.float,
        Delta_t_theta: torch.float,
        p: torch.int,
        k_theta: torch.float,
        Gamma_theta: torch.float,
        h: torch.int,
        n: torch.int,
        nn: torch.int,
        lr_min: torch.float,
        lr_max: torch.float,
        step_max: torch.float,
        x_diff_min=1,
        use_gu=False,
    ):
        self.Delta_t_theta = torch.tensor(
            Delta_t_theta, dtype=torch.float, device=device
        )  # integration window size
        self.p = p  # size of output weights
        self.h = h  # size of hidden weights
        self.nn = nn  # size of input
        self.n = n  # size of state, only using dnn for velocity
        # self.n_2 = n
        self.k_theta = k_theta  # icl gain
        self.Gamma_theta = Gamma_theta  # icl gain
        self.phi_hat = DNN(
            device=device, input_size=self.nn, hidden_size=self.h, output_size=self.p
        )  # dnn
        self.lr_min = lr_min  # min learning rate
        self.lr_max = lr_max  # max learning rate
        self.step_max = step_max  # number simulation steps
        self.lr_slope = (
            self.lr_min - self.lr_max
        ) / self.step_max  # slope for learning rate
        self.theta_hat = (
            0.01 * randn((self.p, self.n), device=device, requires_grad=False).detach()
        )  # output weights, only for velocity
        # self.x_diff_min = x_diff_min # minimum distance between states
        self.last_t = None  # holds last value for time
        self.last_x = None  # holds last value for the state
        self.last_x_ups = None  # holds last value for the input
        self.last_gu = None  # holds last value for the policy
        self.t_buff = []  # buffer to store times as a tensor to batch process
        self.x_buff = []  # buffer to store just the x data as a tensor to batch process
        self.x_ups_buff = (
            []
        )  # buffer to store just the x ups data as a tensor to batch process
        self.gu_buff = (
            []
        )  # buffer to store just the gu data as a tensor to batch process
        self.use_gu = use_gu
        # self.x_buff = [] # buffer for the x terms
        # self.phi_buff = [] # buffer for the phi terms

        # # if there is no g(x)*u then dont need this, for systems with x_dot = f(x) + g(x)*u
        # if use_gu:
        #     self.gu_buff = [] # buffer for the g(x)*u terms
        # else:
        #     self.gu_buff = None

        # self.phi_phi_sum = zeros((self.p,self.p), dtype=torch.float) # sum of the phi^T*phi terms
        # self.phi_x_Sum = zeros(self.p, dtype=np.float32) # sum of the phi^T*x or phi^T*(x-g*u) terms
        self.phi_phi_sum_min_eig = (
            0.0  # current minimum eigenvalue for the phi^T*phi sum
        )
        self.T_1 = 0.0  # time the minimum eigenvalue is satisfied, if satisfied
        self.lambda_1_met = False  # indicates if the eigenvalue condition is satisfied
        self.optimizer = optim.Adam(self.phi_hat.parameters(), lr=self.lr_max, eps=1e-5)
        self.loss = torch.nn.MSELoss()
        self.dnn_converged = False

    # linearly decay the learning rate
    def linear_scale(self, step):
        lr = self.lr_slope * step + self.lr_max
        return lr

    def appends(self, x_ups, t, gu=None):
        # dont add the data if the minimum eigenvalue is good
        # using the sliding buffer method for icl and dnn to save time, not the only way to do it though
        # add the data to the buffers
        self.last_t = t
        self.last_x_ups = np.copy(x_ups)
        if self.use_gu:
            self.last_x = np.copy(x_ups[0 : self.n])
            self.last_gu = np.copy(gu)
        else:
            self.last_x = np.copy(x_ups[self.n :])

        if self.use_gu:
            self.t_buff.append(
                torch.tensor(t, dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
                .unsqueeze(0)
            )  # unsqueeze to get correct dim
            self.x_buff.append(
                torch.tensor(
                    np.copy(x_ups[0 : self.n]), dtype=torch.float, device=device
                )
                .detach()
                .unsqueeze(0)
            )
            self.x_ups_buff.append(
                torch.tensor(np.copy(x_ups), dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
            )
            self.gu_buff.append(
                torch.tensor(np.copy(gu), dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
            )
        else:
            self.t_buff.append(
                torch.tensor(t, dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
                .unsqueeze(0)
            )
            self.x_buff.append(
                torch.tensor(np.copy(x_ups[self.n :]), dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
            )
            self.x_ups_buff.append(
                torch.tensor(np.copy(x_ups), dtype=torch.float, device=device)
                .detach()
                .unsqueeze(0)
            )

        # if enough data to integrate then integrate and optimize
        if len(self.t_buff) > 3:

            # check if more data than needed for the integral then remove oldest if there is
            buff_Delta_t = self.t_buff[-1] - self.t_buff[2]
            if buff_Delta_t > self.Delta_t_theta:
                # pop the oldest to remove
                self.t_buff.pop(0)
                self.x_buff.pop(0)
                self.x_ups_buff.pop(0)
                if self.use_gu:
                    self.gu_buff.pop(0)
            del buff_Delta_t

    def optimizes(self, step):
        # if enough data to integrate then integrate and optimize
        if step > 15 and len(self.t_buff) > 3 and not self.dnn_converged:
            # self.optimizer = optim.Adam(self.phi_hat.parameters(),lr=lr,eps=1e-5)
            for param in self.optimizer.param_groups:
                param["lr"] = self.linear_scale(step)

            # stack the batches, when full looks like
            # [x[t_i]]
            # [x[t_i+i]]
            #
            # [x[t_i+Dt]]
            t_batch = torch.cat(self.t_buff, dim=0).detach()
            x_batch = torch.cat(self.x_buff, dim=0).detach()
            x_ups_batch = torch.cat(self.x_ups_buff, dim=0).detach()
            gu_batch = None
            if self.use_gu:
                gu_batch = torch.cat(self.gu_buff, dim=0).detach()

            # using the batch of x data now calculate the batch of phi
            # [phi(x[t_i])]
            # [phi(x[t_i+1])]
            #
            # [phi(x[t_i+Dt])]

            # split up batches to calculate the integrals using trapezoidal rule
            #
            # sum{0.5*dt_i*( f(x_i) + f(x_i+1) )}

            # i batch
            t_batch_ = t_batch[0:-1, :].detach().clone()
            x_batch_ = x_batch[0:-1, :].detach().clone()
            x_ups_batch_ = x_ups_batch[0:-1, :].detach().clone()
            gu_batch_ = None
            if self.use_gu:
                gu_batch_ = gu_batch[0:-1, :].detach().clone()

            # i+1 batch
            t_batch_next = t_batch[1:, :].detach().clone()
            x_batch_next = x_batch[1:, :].detach().clone()
            x_ups_batch_next = x_ups_batch[1:, :].detach().clone()
            gu_batch_next = None
            if self.use_gu:
                gu_batch_next = gu_batch[1:, :].detach().clone()

            # calculate phis
            phi_batch_ = self.phi_hat(x_ups_batch_)
            phi_batch_next = self.phi_hat(x_ups_batch_next)

            # calculate integrals
            Delta_t_batch = t_batch_next - t_batch_
            Delta_x_batch = x_batch_next - x_batch_
            var_phi_batch = 0.5 * Delta_t_batch * (phi_batch_next + phi_batch_)
            var_G_batch = None
            if self.use_gu:
                var_G_batch = 0.5 * Delta_t_batch * (gu_batch_next + gu_batch_)

            # calculate the icl update and the loss
            Delta_x_hat_batch = (
                var_phi_batch @ self.theta_hat
            )  # estimate of Delta_x_batch
            if self.use_gu:
                Delta_x_hat_batch += var_G_batch
            dnn_loss = self.loss(Delta_x_hat_batch, Delta_x_batch)  # dnn loss is MSE

            # # optimize

            # if self.use_gu:
            #     print("pursuer loss "+str(dnn_loss))
            # else:
            #     print("evader loss "+str(dnn_loss))

            ###### NEED TO FIX BUT NOT SURE WHAT'S HAPPENING
            self.optimizer.zero_grad()
            dnn_loss.backward()
            self.optimizer.step()

            Delta_x_tilde_batch = Delta_x_batch - Delta_x_hat_batch  # estimate error
            icl_sum = (
                var_phi_batch.T @ Delta_x_tilde_batch
            )  # icl sum for output weights
            self.theta_hat += (
                Delta_t_batch[-1] * self.k_theta * self.Gamma_theta * icl_sum
            ).detach()

            print("loss " + str(dnn_loss))
            if dnn_loss.to(cpu_device).detach().numpy() < 0.01:
                print("loss converged " + str(dnn_loss))
                self.dnn_converged = True

            del dnn_loss, icl_sum
            del Delta_x_hat_batch, Delta_x_tilde_batch
            del Delta_t_batch, Delta_x_batch, var_phi_batch, var_G_batch
            del phi_batch_, phi_batch_next
            del t_batch_next, x_batch_next, x_ups_batch_next, gu_batch_next
            del t_batch_, x_batch_, x_ups_batch_, gu_batch_
            del t_batch, x_batch, x_ups_batch, gu_batch

            # print(dnn_loss)

            # D_x = x_batch[-1] - x_batch[0]
            # var_phi = (Dt_batch*var_phi_batch).sum(dim=0)
            # var_G = None
            # if self.use_gu:
            #     var_G = (Dt_batch*var_G_batch).sum(dim=0)

            # fix the ICL and then use the batch to train as well
            # once trained enough then can stop replacing the ICL data?

            # # check to make sure the integral data isn't 0
            # if (np.linalg.norm(var_phi.to(cpu_device).numpy()) > 0.1) and (np.linalg.norm((D_x-var_G).to(cpu_device).numpy()) > 0.1):
            #     # add the data to saved data
            #         self.Ybuff.append(Yint)
            #         # print("Y \n"+str(Y))
            #         YY = Yint.T@Yint
            #         # print("YY \n"+str(YY))
            #         Ytau = Yint.T@tauInt
            #         # print("Ytau \n"+str(Ytau))
            #         self.YYsum += YY
            #         self.YtauSum += Ytau
            #         self.YYsumMinEig = np.min(eigvals(self.YYsum))

            #         # check if the new data makes the eigenvalue large enough
            #         if self.YYsumMinEig > self.lambdaCL:
            #             self.TCL = t
            #             self.lambdaCLMet = True

            # # calculate the integral using trapezoidal rule
            # for ii in range(len(self.data_buff)-1):
            #     dt_i = self.data_buff[ii+1].t-self.data_buff[ii].t
            #     phi_avg_i = 0.5*(phi_batch[ii+1,:]+phi_batch[ii,:]).to(device=cpu_device)
            #     tauAvgi =  0.5*(self.intBuff[ii+1].tau+self.intBuff[ii].tau)
            #     Yint += dti*YAvgi
            #     tauInt += dti*tauAvgi

    # return estimate
    def theta_phi_hat(self, x):
        with torch.no_grad():
            phi_hat_ = self.phi_hat(torch.tensor(x, device=device, dtype=torch.float))
            theta_phi_hat_ = self.theta_hat.T @ phi_hat_
            return theta_phi_hat_.to(cpu_device).numpy()

    # return weights
    def theta_hat_(self):
        with torch.no_grad():
            return self.theta_hat.to(cpu_device).numpy()
