import numpy as np


class VelComp:
    def __init__(self, input_size: 2, dt: 0.1):
        self.theta_hat = np.zeros(input_size)
        self.gamma = 0.01
        self.k = 10.0
        self.dt = dt

    def u(self, x_dot: np.float32, x_dot_d: np.float32):
        e = x_dot_d - x_dot
        Y = np.diag(x_dot)
        theta_hat_dot = self.gamma * Y.T @ e
        # print(Y@self.theta_hat)
        # print(self.k*e)
        u_ = Y @ self.theta_hat + self.k * e
        self.theta_hat += self.dt * theta_hat_dot
        return u_
