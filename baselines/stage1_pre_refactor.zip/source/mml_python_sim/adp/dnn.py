import torch
import torch.nn as nn
from collections import OrderedDict

# create a class wrapper from PyTorch nn.Module to use exp
class Exp(nn.Module):
    """
    Applies exponential radial basis \n
    Returns:
    -------
    \t Exp(x) = exp(-x**2) \n
    """

    def __init__(self):
        super().__init__()

    def forward(self, x):
        return torch.exp(-(x**2))


class DNN(nn.Module):
    def __init__(
        self,
        device: torch.device,
        input_size: torch.int,
        hidden_size: torch.int,
        output_size: torch.int,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.model = nn.Sequential(
            OrderedDict(
                [
                    ("ni", nn.LayerNorm(input_size)),
                    ("li", nn.Linear(input_size, hidden_size, dtype=torch.float)),
                    ("ai", nn.Tanh()),
                    ("lm", nn.Linear(hidden_size, hidden_size, dtype=torch.float)),
                    ("am", nn.Tanh()),
                    ("lo", nn.Linear(hidden_size, output_size, dtype=torch.float)),
                    ("am", nn.Tanh()),
                ]
            )
        )
        self.model.to(device=device)

    def forward(self, x: torch.Tensor):
        model = self.model(x)
        return model

    def saveActorCritic(self, path: str):
        torch.save(self.state_dict(), path + "/model.pth")

    def loadActorCritic(self, path: str, device: torch.device):
        self.load_state_dict(torch.load(path + "/model.pth", map_location=device))
