import numpy as np
import yaml

# from .icl_v2 import ICL
from .icl_single_layer import ICL
import sys
import os

# Add parent directory to Python path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

from environments.pygame_large_env import PygameEnvironment
from .vel_comp import VelComp

# read in config file
def load_config(file_path):
    with open(file_path) as f:
        return yaml.safe_load(f)


class ADP:
    def __init__(self, env: PygameEnvironment, eta_: list):
        np.random.seed(0)
        # load parameters:
        config_params = load_config("config.yaml")
        agent = env.agents[0]
        # simulation environment structure
        self.dt = config_params["dt"]  # time step for sim
        self.n = config_params["n"]  # state size [position,velocity]
        self._3n = 3 * self.n
        self.m_eta = config_params["m_eta"]  # [x,y velocity]
        self.m = self.m_eta + self.n

        # target model
        p_z = config_params["p_z"]  # output size
        h_z = config_params["h_z"]  # hidden size
        lambda_1 = config_params["lambda_1"]  # minimum eigenvalue
        Delta_t_theta = config_params["Delta_t_theta"]  # integration window
        k_theta = config_params["k_theta"]  # icl gain
        Gamma_theta = config_params["Gamma_theta"]  # icl gain
        lr_max = config_params["lr_max"]  # max learning rate
        lr_min = config_params["lr_min"]  # min learning rate
        step_max = config_params["number_sim_steps"]  # max steps
        self.theta_z_icl = ICL(
            lambda_1,
            Delta_t_theta,
            p_z,
            k_theta,
            Gamma_theta,
            h_z,
            self.n,
            2 * self.n,
            lr_min,
            lr_max,
            step_max,
            use_gu=False,
        )

        # agent model
        p_eta = config_params["p_eta"]  # output size
        h_eta = config_params["h_eta"]  # hidden size
        self.theta_eta_icl = ICL(
            lambda_1,
            Delta_t_theta,
            p_eta,
            k_theta,
            Gamma_theta,
            h_eta,
            self.n,
            2 * self.n,
            lr_min,
            lr_max,
            step_max,
            use_gu=True,
        )

        # actor critic
        # self.L = sum(np.arange(1,self._3n+1,1)) # size of polynomial basis
        self.L = (
            self._3n + 1
        )  # dimension of simplex basis for staf is one more than the state
        self.W_c_hat = 2.0 * np.ones(self.L)  # critic weights
        self.W_a_hat = 1.0 * np.ones(self.L)  # actor weights
        self.Gamma_c = 5.0 * np.eye(self.L)  # critic gain
        self.k_c1 = config_params["k_c1"]  # gain on critic on trajectory
        self.k_c2 = config_params["k_c2"]  # gain on critic off trajectory
        self.k_a1 = config_params["k_a1"]  # gain on difference between Wa and Wc
        self.k_a2 = config_params["k_a2"]  # gain on Wa
        self.k_nu = config_params["k_nu"]  # gain for staf
        self.beta_c = config_params["beta_c"]  # gain for Gamma on Gamma
        self.gamma_1 = config_params["gamma_1"]  # gain for normalization factor
        self.N = config_params["N"]  # number of extrapolation points
        # Qn = config_params["Qn"] # state cost for each block
        Q_e_z = config_params["Q_e_z"]  # state cost for each block
        Q_e_d = config_params["Q_e_d"]  # state cost for each block
        Q_e_eta = config_params["Q_e_eta"]  # state cost for each block
        Q_ = np.concatenate((Q_e_z, Q_e_d, Q_e_eta))
        # self.Q = np.kron(np.identity(3),np.diag(Qn)) # state cost
        self.Q = np.diag(Q_)
        self.R = config_params["R"]  # input cost
        self.k_d = config_params["k_d"]  # gain on target error
        self.r = config_params["r"]  # radius of ball around state for extrapolation
        self.K_a = config_params["K_a"]  # gain for actor
        self.f_scale = config_params["f_scale"]  # max speed about z axis
        self.RI = 1.0 / self.R  # inverse of input cost
        # self.MI = np.diag([1.0/agent.mass,1.0/agent.mass]) # inverse of inertia
        # self.g = np.zeros((self.n,self.m_eta)) # we can make g identity for position only
        # self.g[2:,:] = np.diag([1.0/agent.mass,1.0/agent.mass])
        self.g = np.identity(self.n)
        # self.g = np.identity(self.n) # we can make g ideself.Gamma_cntity for position only
        self.g_psuedo = np.linalg.inv(self.g.T @ self.g) @ self.g.T
        self.g_g = self.g @ self.g_psuedo
        self.G_sd = self.g_g - np.identity(self.n)
        self.G = np.zeros((self._3n, self.m))
        self.G[self.n : 2 * self.n, self.m_eta : self.m] = np.identity(self.n)
        self.G[2 * self.n : self._3n, 0 : self.m_eta] = self.g
        self.G[2 * self.n : self._3n, self.m_eta : self.m] = self.G_sd
        self.G_T = self.G.T
        self.G_R = self.RI * self.G @ self.G_T
        self.max_force = agent.maxForce
        self.max_torque = agent.maxTorque
        self.max_lin_vel = agent.max_lin_vel
        self.max_ang_vel = agent.max_ang_vel
        self.max_dist = env.max_dist
        self.vel_comp = VelComp(self.n, self.dt)

        self.eta_d = np.array(
            [eta_[0], eta_[1]]
        )  # virtual desired trajectory initialize to initial state
        self.d = np.zeros((self._3n, self.L))  # simplex matrix for staf
        self.d[0, 0] = 1.0
        inv_3n = 1.0 / self._3n
        self.x_0 = None
        self.x_0_norm = None

        for j in range(1, self.L):
            self.d[0, j] = -inv_3n

        for i in range(1, self._3n):
            d_i = self.d[0:i, i]
            d_i_d_i = np.dot(d_i, d_i)
            self.d[i, i] = np.sqrt(1.0 - d_i_d_i)

            for j in range(i + 1, self.L):
                d_j = self.d[0:i, j]
                d_i_d_j = np.dot(d_i, d_j)
                self.d[i, j] = (-inv_3n - d_i_d_j) / self.d[i, i]

        # print(self.d)

    # def g(self, eta_: np.ndarray):
    #     # g will be
    #     # [   0_3x3      ]
    #     # [ R(theta)*M^-1 ]
    #     g_ = np.zeros((self.n,self.m_eta))
    #     c_angle = cos(angle)
    #     s_angle = sin(angle)
    #     rotation = np.array([[c_angle, -s_angle, 0],
    #                          [s_angle,  c_angle, 0],
    #                          [      0,        0, 1]])
    #     g_[3:,:] = rotation@self.MI
    #     return g_

    # basis
    def sigma(self, x: np.ndarray):
        # general staf sigma
        s = np.copy(x)
        if self.x_0_norm > 0.0001:
            s /= self.x_0_norm

        # s_s = np.dot(s,s)
        # nu = (s_s+0.01)/(1.0+self.k_nu*s_s)
        # grad_nu = 2.0*(1.0-0.01*self.k_nu)/((1.0+self.k_nu*s_s)**2)*s

        # sigma_ = np.zeros(self.L)
        # grad_sigma_ = np.zeros((self.L,self._3n))

        # for ii in range(self.L):
        #     d_i = self.d[0:self._3n,ii]
        #     s_d_i = np.dot(s,d_i)
        #     nu_d_i = 0.7*nu*d_i
        #     c_i = s + nu_d_i
        #     sigma_[ii] = np.dot(s,c_i)
        #     grad_sigma_[ii,0:self._3n] = c_i+s+s_d_i*grad_nu

        # Rushi's original method
        s_s = np.dot(s, s)
        nu = (s_s + 0.01) / (1.0 + self.k_nu * s_s)
        grad_nu = 2.0 * (1.0 - 0.01 * self.k_nu) / ((1.0 + self.k_nu * s_s) ** 2) * s

        sigma_ = np.zeros(self.L)
        grad_sigma_ = np.zeros((self.L, self._3n))

        for ii in range(self.L):
            d_i = self.d[0 : self._3n, ii]
            s_d_i = np.dot(s, d_i)
            nu_d_i = nu * d_i
            c_i = s + nu_d_i
            s_c_i = np.dot(s, c_i)
            # sigma_[ii] = np.exp(s_c_i)-1
            # grad_sigma_[ii,0:self._3n] = (c_i+s+s_d_i*grad_nu)*np.exp(s_c_i)
            sigma_[ii] = s_c_i
            grad_sigma_[ii, 0 : self._3n] = c_i + s + s_d_i * grad_nu

        return sigma_, grad_sigma_, nu

    def F(self, x: np.ndarray):
        e_z = x[0 : self.n]
        e_d = x[self.n : 2 * self.n]
        e_eta = x[2 * self.n : 3 * self.n]
        s_1 = e_z  # z
        s_2 = e_eta + e_d + self.k_d * e_z  # eta
        s_12 = np.concatenate((s_1, s_2))

        # calculate F and G for current state
        # f_hat = self.theta_z_hat.T@self.phi_z_hat(torch.tensor(s_12)).numpy()
        # h_hat = self.theta_eta_hat.T@self.phi_eta_hat(torch.tensor(s_12)).numpy()
        # icl is only for velocities
        # target
        e = s_1 - s_2
        e_z = s_1
        f_z = self.max_lin_vel * (e / 100.0) * np.exp(-0.5 * np.dot(e, e) / 100.0**2)

        # position_to_agent = s_2 - s_1
        # distance_to_agent = np.linalg.norm(position_to_agent)
        # repulse_force = -self.f_scale*self.max_lin_vel*(position_to_agent/self.max_dist)*np.exp(-self.f_scale*self.max_lin_vel*(distance_to_agent/self.max_dist)**2)
        # f_hat = np.copy(f_z)
        f_hat_icl = self.theta_z_icl.theta_phi_hat(s_12)  # dynamics
        f_hat = np.copy(f_hat_icl)

        # agent
        h_hat = np.zeros(self.n)

        # test with real dynamics for accel since its zero
        # h_hat[self.n_2:] = self.theta_eta_icl.theta_phi_hat(s_12) # dynamics

        # g = self.g(s_2)
        # g_psuedo = np.linalg.inv(g.T@g)@g.T
        # F_sd = g@g_psuedo@h_hat
        # G_sd = g@g_psuedo - np.identity(self.n)
        F_sd = self.g_g @ h_hat

        F_hat = np.concatenate((f_hat, -self.k_d * f_hat, h_hat - F_sd))
        # G = np.zeros((self._3n,self.m))
        # G[self.n:2*self.n,self.m_eta:self.m] = np.identity(self.n)
        # G[2*self.n:self._3n,0:self.m_eta] = g
        # G[2*self.n:self._3n,self.m_eta:self.m] = G_sd
        return F_hat, f_hat_icl, f_z

    # # bellman error extrapolation, calculates policy and value function information too
    # def BEE(self, F_hat: np.ndarray, G: np.ndarray, y: np.ndarray):
    #     sigma,grad_sigma = self.sigma(y)
    #     # G_R = self.RI*G@G.T
    #     G_sigma = grad_sigma@self.G_R@grad_sigma.T
    #     mu_hat = -0.5*self.RI*G.T@grad_sigma.T@self.W_a_hat
    #     x_dot_hat = F_hat + G@mu_hat
    #     omega = grad_sigma@x_dot_hat
    #     rho = 1.0+self.gamma_1*np.dot(omega,omega)
    #     cost = np.dot(y,self.Q@y)+self.R*np.dot(mu_hat,mu_hat)
    #     delta = cost + np.dot(self.W_c_hat,omega)
    #     return mu_hat,omega,rho,delta,G_sigma,sigma

    # bellman error extrapolation, calculates policy and value function information too
    def BEE(self, F_hat: np.ndarray, y: np.ndarray):
        sigma, grad_sigma, nu = self.sigma(y)
        # G_R = self.RI*G@G.T
        G_sigma = grad_sigma @ self.G_R @ grad_sigma.T
        # mu_hat = -self.max_lin_vel*np.tanh(0.5*(self.RI/self.max_lin_vel)*self.G_T@grad_sigma.T@self.W_a_hat)
        mu_hat = -0.5 * self.RI * self.G_T @ grad_sigma.T @ self.W_a_hat
        x_dot_hat = F_hat + self.G @ mu_hat
        omega = grad_sigma @ x_dot_hat
        rho = 1.0 + self.gamma_1 * np.dot(omega, omega)
        cost = np.dot(y, self.Q @ y) + self.R * np.dot(mu_hat, mu_hat)
        delta = cost + np.dot(self.W_c_hat, omega)
        return mu_hat, omega, rho, delta, G_sigma, sigma, grad_sigma, nu

    def forwards(self, z_: np.ndarray, eta_: np.ndarray, t: np.float32, step: np.int32):
        """forward takes in current state information, updates learning, and approximates value/policy"""

        z = np.array([z_[0], z_[1]])  # position
        eta = np.array([eta_[0], eta_[1]])  # position

        # calculate state and desired state
        e_z = z
        e_d = self.eta_d - self.k_d * e_z
        e_eta = eta - self.eta_d


        # x = np.concatenate((e_z,e_eta,e_d))
        x = np.concatenate((e_z, e_d, e_eta))

        # print("e_z: "+str(e_z))
        # print("e_d: "+str(e_d))
        # print("e_eta: "+str(e_eta))

        if self.x_0 is None:
            self.x_0 = np.copy(x)
            self.x_0_norm = np.linalg.norm(self.x_0)

        # dynamics and control effectiveness for current state
        # F_hat, G = self.F_G(x)

        F_hat, f_hat_icl, f_z = self.F(x)
        # print("z_: "+str(z_))
        # print("z: "+str(z))
        # print("F_hat: "+str(F_hat))
        # print("f_hat_icl: "+str(np.round(f_hat_icl,3)))
        # print("repulse vel: "+str(np.round(f_z,3)))

        # calcualate BE for current state
        # mu_hat,omega,rho,delta,G_sigma,sigma = self.BEE(F_hat,G,x)
        mu_hat, omega, rho, delta, G_sigma, sigma, grad_sigma, nu = self.BEE(F_hat, x)
        mu_eta_hat = mu_hat[0 : self.m_eta]
        mu_d_hat = mu_hat[self.m_eta : self.m]

        # calculate input
        h_d_hat = np.zeros(self.n)
        # h_d_hat = self.theta_eta_icl.theta_phi_hat(z_eta_d)
        # g_d = self.g(self.eta_d)
        # g_d_psuedo = np.linalg.inv(g_d.T@g_d)@g_d.T
        # u_d_hat = g_d_psuedo@(mu_d_hat-h_d_hat)
        u_d_hat = self.g_psuedo @ (mu_d_hat - h_d_hat)
        # keeps getting stuck on wrong side because mu_eta and mu_d cancel each other out
        # want to try and give it a push outside to avoid this local min
        # wrong_side = z_dist-eta_dist > 0
        u_hat = mu_eta_hat + u_d_hat

        # extrapolations starting with first point
        W_c_BE = self.k_c1 * delta / (rho**2) * omega
        W_a_BE = (
            self.K_a
            * self.k_c1
            / (4.0 * rho**2)
            * G_sigma.T
            @ np.outer(self.W_a_hat, omega)
            @ self.W_c_hat
        )
        Gamma_c_BE = self.k_c1 / (rho**2) * np.outer(omega, omega)

        for jj in range(self.N):
            x_ii = x + nu * np.random.randn(self._3n)  # random point around x
            # F_hat_ii,G_ii = self.F_G(x_ii) # dynamics for that point
            F_hat_ii, _, _ = self.F(x_ii)  # dynamics for that point
            _, omega_ii, rho_ii, delta_ii, G_sigma_ii, _, _, _ = self.BEE(
                F_hat_ii, x_ii
            )
            W_c_BE += self.k_c2 * delta_ii / (rho_ii**2) * omega_ii
            W_a_BE += (
                self.K_a
                * self.k_c2
                / (4.0 * rho_ii**2)
                * G_sigma_ii.T
                @ np.outer(self.W_a_hat, omega_ii)
                @ self.W_c_hat
            )
            Gamma_c_BE += self.k_c2 / (rho_ii**2) * np.outer(omega_ii, omega_ii)

        W_c_hat_dot = -1.0 / (self.N + 1) * self.Gamma_c @ W_c_BE
        W_a_hat_dot = (
            -self.K_a * self.k_a1 * (self.W_a_hat - self.W_c_hat)
            - self.K_a * self.k_a2 * self.W_a_hat
            + 1.0 / (self.N + 1) * W_a_BE
        )
        Gamma_c_dot = (
            self.beta_c * self.Gamma_c
            - 1.0 / (self.N + 1) * self.Gamma_c @ Gamma_c_BE @ self.Gamma_c
        )

        # should I take this step before?
        self.W_c_hat = np.clip(self.W_c_hat + W_c_hat_dot * self.dt, 0.05, 10.0)
        self.W_a_hat = np.clip(self.W_a_hat + W_a_hat_dot * self.dt, 0.05, 10.0)
        # self.W_c_hat += W_c_hat_dot*self.dt
        # self.W_a_hat += W_a_hat_dot*self.dt
        self.Gamma_c += Gamma_c_dot * self.dt
        #self.eta_d = np.clip(self.eta_d+mu_d_hat*self.dt,-self.max_dist,self.max_dist)
        #self.eta_d += mu_d_hat * self.dt
        self.eta_d = np.clip(self.eta_d + mu_d_hat * self.dt, -3.0, 3.0)
        self.Gamma_c = np.clip(self.Gamma_c,0.01,100.0)
        # print(self.Gamma_c)

        V_hat = np.dot(self.W_c_hat, sigma)

        if V_hat > 1000:
            print(V_hat)

        # saturate
        vel_hat_sat_des = self.max_lin_vel * np.tanh(u_hat / self.max_lin_vel)
        vel = eta_[3:5]
        # u_hat_sat = self.vel_comp.u(vel,vel_hat_sat_des)
        # u_hat_sat = self.max_lin_vel*np.tanh(u_hat/self.max_lin_vel)
        # u_hat_sat = np.zeros(2)
        # u_hat_sat = np.copy(u_hat)
        u_hat_sat = vel_hat_sat_des


        # update icl and dnn
        z_eta = np.concatenate((z, eta))
        # g = self.g(eta)

        self.theta_z_icl.appends(z_eta, t)
        self.theta_z_icl.optimizes(step)
        # gu_hat = self.g@u_hat
        # # self.theta_eta_icl.appends(z_eta,t,gu_hat[self.n_2:])
        # # self.theta_eta_icl.optimizes(step)

        # calculate torque to point in direction of eta_d
        relative_positionii = z[0:2] - eta[0:2]
        relative_distanceii = np.linalg.norm(relative_positionii)
        relative_directionii = (relative_positionii) / (
            relative_distanceii + 0.00001
        )  # the add of a small number to avoid singular
        agent_directionii = np.array([np.cos(eta_[2]), np.sin(eta_[2])])
        cos_ii = (
            relative_directionii[0] * agent_directionii[0]
            + relative_directionii[1] * agent_directionii[1]
        )  # from dot product
        sin_ii = (
            -relative_directionii[1] * agent_directionii[0]
            + relative_directionii[0] * agent_directionii[1]
        )  # from cross product
        angledii = np.arctan2(sin_ii, cos_ii)

        ang_vel = -self.max_ang_vel * np.sin(angledii / 2.0)
        tau = np.array([u_hat_sat[0], u_hat_sat[1], ang_vel])

        return (
            tau,
            u_hat,
            mu_eta_hat,
            self.W_c_hat,
            self.W_a_hat,
            V_hat,
            self.theta_z_icl.theta_hat_(),
            self.theta_eta_icl.theta_hat_(),
            self.eta_d,
            vel,
            vel_hat_sat_des,
            mu_d_hat,
            e_z,
            e_d,
            e_eta,
            f_hat_icl,
            f_z,
        )
