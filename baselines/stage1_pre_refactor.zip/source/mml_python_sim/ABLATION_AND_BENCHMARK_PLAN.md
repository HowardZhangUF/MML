# Ablation and Benchmark Plan

This document defines the paper's filter-level benchmark suite and the next
ablations. It records the completed 100-run results so the paper can separate
evidence already obtained from experiments that still need to be run.

## Scope and Protocol

Every reported tracker uses the same 100 simulated trajectories of 2000 steps
and the same measurement stream for a given run. The shared seed schedule is
the one in `benchmark_diffpf_vs_cfm.py`:

| Source of randomness | Seed for run `r` |
|---|---:|
| Trajectory | `1000 + r` |
| Measurement noise | `5000 + r` |
| Particle-filter and Torch sampling | `9000 + r` |

The bootstrap PF has 500 particles, Gaussian process noise (`0.01`), a
Gaussian measurement likelihood (`sigma_meas = 0.05 m`), and systematic
resampling when ESS is below `N / 2`. All metrics are lower-is-better:

| Metric | Definition |
|---|---|
| RMSE all (m) | Position RMSE over every tracking step. |
| RMSE visible (m) | Position RMSE only where a measurement is present. |
| RMSE occluded (m) | Position RMSE only during occlusion. |
| Recovery (steps) | Mean steps after an occlusion-to-visible transition until error is below `0.3 m`. |
| ms/step | Wall-clock filter cost per tracking step. |

Per-run measurements live in
`src/mml_guidance/models/diffpf_vs_cfm_per_run.csv`. Pairwise comparisons use
matching run IDs, with PF+CFM-AS as the reference.

## Benchmark Status

The completed suite is now six 100-run benchmarks. Values are mean +/-
run-to-run standard deviation. Runtime is machine-dependent and should be
reported with the workstation configuration used for the final paper run.

| Tracker | RMSE all (m) | RMSE visible (m) | RMSE occluded (m) | Recovery (steps) | ms/step |
|---|---:|---:|---:|---:|---:|
| PF+CFM, fixed `sigma=1.0` | 0.578 +/- 0.195 | 0.030 +/- 0.018 | 0.816 +/- 0.188 | 0.19 +/- 0.77 | 10.74 +/- 2.20 |
| PF+CFM-AS, adaptive `sigma` | 0.461 +/- 0.187 | **0.024 +/- 0.005** | 0.643 +/- 0.183 | **0.02 +/- 0.12** | 11.39 +/- 1.98 |
| PF+NF | 0.461 +/- 0.295 | 0.029 +/- 0.019 | 0.624 +/- 0.325 | 0.16 +/- 0.57 | 10.88 +/- 2.14 |
| DiffPF | 0.626 +/- 0.190 | 0.621 +/- 0.217 | 0.622 +/- 0.252 | 6.92 +/- 14.37 | 7.66 +/- 1.41 |
| **PF+CV** | **0.260 +/- 0.123** | 0.030 +/- 0.005 | **0.365 +/- 0.124** | 0.22 +/- 1.32 | **0.24 +/- 0.04** |
| **PF+DMMN** | 1.055 +/- 0.260 | 0.531 +/- 0.209 | 1.380 +/- 0.240 | 89.33 +/- 107.52 | 9.76 +/- 0.76 |

The new baselines establish two points that should be reflected accurately in
the paper:

- PF+CV is the strongest overall and occlusion baseline in this synthetic
  task. It should be treated as a strong hand-coded motion-prior benchmark,
  not a weak strawman. PF+CFM-AS has better visible-step RMSE, but not better
  all-step or occluded RMSE.
- PF+CFM-AS decisively improves on the offline DMMN baseline on all accuracy
  and recovery metrics. That is the appropriate historical learned-model
  comparison for the paper.
- PF+CFM-AS and PF+NF remain statistically tied on overall and occluded RMSE
  in the previously completed runs; adaptive sigma's clearest established
  benefit is against fixed-sigma CFM.

### Paired Tests Against PF+CFM-AS

Difference is `PF+CFM-AS - comparator`; negative favors PF+CFM-AS. The
Wilcoxon values are tie-corrected normal approximations because SciPy is not a
dependency of this repository.

| Comparator | Metric | Mean difference | PF+CFM-AS lower in | Paired t p | Wilcoxon p | Reading |
|---|---|---:|---:|---:|---:|---|
| PF+CV | RMSE all | +0.2010 | 6/100 | 3.11e-28 | 1.35e-17 | PF+CV wins. |
| PF+CV | RMSE visible | -0.0055 | 88/100 | 4.89e-12 | 1.42e-13 | PF+CFM-AS wins. |
| PF+CV | RMSE occluded | +0.2781 | 6/100 | 4.23e-31 | 1.48e-17 | PF+CV wins. |
| PF+CV | Recovery | -0.2037 | 15/99 | 0.132 | 0.021 | Mostly ties; tests disagree, so do not make a recovery claim. |
| PF+DMMN | RMSE all | -0.5942 | 100/100 | 4.42e-58 | 3.96e-18 | PF+CFM-AS wins. |
| PF+DMMN | RMSE visible | -0.5062 | 100/100 | 3.23e-43 | 3.96e-18 | PF+CFM-AS wins. |
| PF+DMMN | RMSE occluded | -0.7368 | 99/100 | 3.59e-57 | 4.20e-18 | PF+CFM-AS wins. |
| PF+DMMN | Recovery | -89.3085 | 92/98 | 1.11e-12 | 8.28e-17 | PF+CFM-AS wins. |

## Added Baselines

### PF+CV

PF+CV is the standard bootstrap PF with the finite-difference proposal

`v_k = (x_k - x_(k-1)) / dt`

computed independently from each particle's two most recent states. Velocity
is clipped to `1.5 m/s`; the regular PF process noise supplies particle
diversity. This baseline answers whether a learned or generative motion model
outperforms a transparent constant-velocity prior.

### PF+DMMN

For this paper, DMMN means the offline `ScratchTransformer` checkpoint, not
the online adaptive `MotionModel` class used by `prediction_method="DMMN"` in
`ParticleFilter.py`.

Checkpoint:

`src/mml_guidance/mml_guidance/mml_network/models/best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth`

Its architecture is the original offline Transformer configuration in
`ParticleFilter.py`:

| Setting | Value |
|---|---:|
| `input_dim` | 2 |
| `block_size` | 5 |
| `n_embed` | 20 |
| `n_head` | 8 |
| `n_layer` | 2 |
| `hidden_dim` | 20 |

The network emits a deterministic velocity for each particle history. The PF
uses the same process noise, measurement weighting, ESS threshold, and hard
systematic resampling as all bootstrap-PF comparators, so its particle spread
does not depend on adding a separate stochastic learned head.

The reproducible implementation is
`src/mml_guidance/mml_guidance/mml_network/benchmark_cv_dmmn.py`. It protects
the existing completed rows from accidental duplication. To intentionally
replace only the PF+CV and PF+DMMN CSV rows after a code or metric change, run:

```bash
python src/mml_guidance/mml_guidance/mml_network/benchmark_cv_dmmn.py \
  --n_runs 100 --n_steps 2000 --pf_particles 500 --replace_existing
```

## Ablation Suite

### Completed

| Question | Ablation | Status |
|---|---|---|
| Does adaptive proposal spread help CFM? | Fixed `sigma=1.0` versus PF+CFM-AS. | Complete; adaptive sigma strongly improves occluded RMSE. |
| Is the CFM anchor spread important? | Anchor sigma sweep `{0.3, 1.0, 2.0}`. | Complete; `1.0` is the useful interior setting. |
| Is CFM head capacity the explanation? | Velocity-head hidden width `64` versus `128`. | Complete; larger width was not better. |
| Does CFM compete with another learned generative velocity model? | PF+CFM-AS versus PF+NF. | Complete; overall and occluded RMSE are tied. |
| Does CFM compete with a diffusion PF? | PF+CFM-AS versus DiffPF. | Complete; CFM-AS is better on visible and overall RMSE. |
| Does a hand-coded prior suffice? | PF+CV. | Complete; CV is strongest overall and during occlusion. |
| Does CFM improve on the previous offline learned motion model? | PF+DMMN with ScratchTransformer. | Complete; CFM-AS wins decisively. |

### Next High-Value Ablations

| Priority | Ablation | Values or design | Question answered |
|---:|---|---|---|
| 1 | Adaptive CFM sigma sweep | `gamma in {0.025, 0.05, 0.10}`, `sigma_max in {2.0, 2.5, 3.0}`. Hold base sigma at `1.0`. | Is the current adaptive schedule tuned robustly, or only fortuitously? |
| 2 | NF adaptive variance / temperature | Draw `z = s(Delta k) epsilon` before inverse RealNVP, with a schedule comparable to CFM-AS. | Is CFM's advantage due to flow matching or to controllable proposal spread? |
| 3 | Learned CFM sigma schedule | Freeze the CFM velocity field and learn only the sigma schedule through a differentiable PF objective. | Can proposal uncertainty be learned rather than hand-scheduled? |
| 4 | Resampling training ablation | Compare hard-resampling stop-gradient, soft resampling, and OT/Sinkhorn resampling while learning sigma. | Does differentiable resampling make learned sigma trainable and useful? |
| 5 | Branch-KL multimodality | At Markov junctions, compare predicted particle distribution with the empirical branch distribution using KL or another symmetric distributional score. | Do mean RMSE metrics hide multimodal prediction quality? |

For priorities 1 and 2, use a modest selection split or short paired pilot to
choose a setting, then run one locked 100-run final configuration. Do not
select directly on the final 100-run test set.

## Resampling Clarification

The final benchmark and every reported comparison above use standard hard PF
resampling: systematic resampling copies particles according to their weights
when ESS falls below `N / 2`, then resets weights uniformly. It is a discrete
ancestor-selection operation, so gradients cannot pass through which parent
particle was chosen.

Soft resampling and OT/Sinkhorn resampling are relevant only if sigma is being
learned through the full filter:

| Method | What it does | Why it helps training |
|---|---|---|
| Soft resampling | Smooths or mixes particle weights with uniform mass before drawing/copying. | Reduces abrupt changes in the particle set as weights change. |
| OT/Sinkhorn resampling | Builds a differentiable, entropy-regularized transport from weighted particles to an equally weighted set. | Lets gradients flow approximately through the resampling transform. |

Use these methods first only as training tools for the learned-sigma ablation.
The learned-sigma model must be evaluated again with the same hard systematic
resampling used by PF+CFM-AS, PF+CV, and PF+DMMN. Otherwise a measured gain
could be caused by a changed resampling rule rather than the learned proposal
uncertainty.

## Paper Claims and Limits

Supported claims:

- Adaptive CFM proposal spread improves fixed-sigma CFM.
- CFM-AS is competitive with the NF baseline and clearly better than the
  offline DMMN and DiffPF baselines under this protocol.
- The learned/generative model does not yet outperform the strong
  constant-velocity PF on all-step or occluded RMSE.

Claims to avoid until new evidence exists:

- That CFM-AS is the best tracker overall.
- That differentiable resampling or learned sigma improves final hard-PF
  evaluation; these are planned ablations, not completed results.
- That any method has superior multimodal branch prediction before the
  branch-distribution experiment is run.
