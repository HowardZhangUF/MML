import sys
import os

# Add parent directory to Python path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

from environments.pygame_large_env import PygameEnvironment
import numpy as np

import torch

import yaml

from adp import ADP

use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")

# read in config file
def load_config(file_path):
    with open(file_path) as f:
        return yaml.safe_load(f)


if __name__ == "__main__":
    # load params
    config_params = load_config("config.yaml")
    number_targets = config_params["number_targets"]  # number of targets
    number_sim_steps = config_params["number_sim_steps"]  # number of steps for the sim
    initial_model = config_params["initial_model"]  # initial model
    dt = config_params["dt"]  # time step

    # environments to train
    env = PygameEnvironment()

    # reset environment and get initial state
    state, _ = env.reset()
    eta_ = state[0,:]
    # state is a 2D array with shape (number_agents + number_targets, 6)
    z_ = state[1,:]
    model = ADP(env, eta_)
    if initial_model != "None":
        model.loadActorCritic(path=initial_model, device=device)

    # start stepping through the sim
    env.render_init()
    step = 0
    while step < number_sim_steps:
        # print("state:\n"+str(state))
        eta_ = state[0,:]
        z_ = state[1,:]
        t = step * dt
        (
            tau,
            u_hat,
            mu_eta_hat,
            W_c_hat,
            W_a_hat,
            V_hat,
            theta_z_hat,
            theta_eta_hat,
            eta_d,
            vel,
            vel_hat_sat_des,
            mu_d_hat,
            e_z,
            e_d,
            e_eta,
            f_hat_icl,
            f_z,
        ) = model.forwards(z_, eta_, t, step)

        next_state, _ = env.step(tau)
        state = next_state
        env.render()
        step += 1

    print("Closing sim")
    env.render_close()

