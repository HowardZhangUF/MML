#!/usr/bin/env python3
"""
Offline GMM search-prior visualizer — heatmap edition.

Reads obs_history.pkl (written by ObservationHistoryManager with save_to_file=True)
and produces three panels:

  Left   : Combined heatmap — sum of all target GMM densities over a 2D grid
  Centre : Per-target heatmap grid (one row per target, colour-coded)
  Right  : Raw observation scatter with GMM means overlaid as stars

Usage
-----
  # After training with --save_history:
  conda run -n tracking_ppo python scripts/visualize_gmm.py

  # Single target only:
  conda run -n tracking_ppo python scripts/visualize_gmm.py --target_id 0

  # Higher GMM resolution / more components:
  conda run -n tracking_ppo python scripts/visualize_gmm.py \
      --n_components 5 --grid_res 300
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
import pickle
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from matplotlib.patches import Ellipse


# ── Environment constants ───────────────────────────────────────────────────────
ROAD_NODES = np.array([
    [-1.5,  1.0], [ 0.0,  1.0], [ 2.1,  1.0],
    [-1.5, -1.0], [ 0.0, -1.0], [ 0.3,  0.0],
    [ 1.7,  0.0], [ 2.1, -1.0],
], dtype=np.float32)

ENV_LIM        = 3.0      # environment is [-3, 3] m in both axes
OCC_CENTER     = np.array([0.0, 0.0])
OCC_HALF       = 0.5      # default occlusion half-width in metres


# ── GMM helpers ─────────────────────────────────────────────────────────────────

def fit_gmm(positions: np.ndarray, n_components: int = 3):
    """
    Fit a GMM to (N,2) positions.
    Road nodes are used as pseudo-observations when history is thin (< 5 pts),
    mirroring construct_search_prior() in gym_pursuit_env.py.

    Returns
    -------
    gmm    : fitted GaussianMixture (so caller can call score_samples)
    means  : (k, 2)  — sorted by descending weight
    covs   : (k, 2, 2)
    weights: (k,)
    """
    from sklearn.mixture import GaussianMixture

    if len(positions) >= 5:
        data = positions
    elif len(positions) > 0:
        data = np.vstack([positions, ROAD_NODES])
    else:
        data = ROAD_NODES.copy()

    k   = min(n_components, len(data))
    gmm = GaussianMixture(n_components=k, covariance_type='full',
                          max_iter=200, n_init=5, random_state=42)
    gmm.fit(data)

    order   = np.argsort(gmm.weights_)[::-1]
    return gmm, gmm.means_[order], gmm.covariances_[order], gmm.weights_[order]


def gmm_density_grid(gmm, grid_res: int = 250) -> tuple:
    """
    Evaluate GMM probability density on a square grid.

    Returns
    -------
    XX, YY : (grid_res, grid_res) meshgrid arrays (metres)
    Z      : (grid_res, grid_res) density values
    """
    x  = np.linspace(-ENV_LIM, ENV_LIM, grid_res)
    y  = np.linspace(-ENV_LIM, ENV_LIM, grid_res)
    XX, YY = np.meshgrid(x, y)
    pts    = np.column_stack([XX.ravel(), YY.ravel()])

    log_p  = gmm.score_samples(pts)     # log-likelihood per point
    Z      = np.exp(log_p).reshape(XX.shape)
    return XX, YY, Z


# ── Shared axis decoration ────────────────────────────────────────────────────

def _decorate_ax(ax, title='', xlabel='X (m)', ylabel='Y (m)'):
    ax.set_xlim(-ENV_LIM - 0.2, ENV_LIM + 0.2)
    ax.set_ylim(-ENV_LIM - 0.2, ENV_LIM + 0.2)
    ax.set_aspect('equal')
    ax.set_title(title, fontsize=11)
    ax.set_xlabel(xlabel, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(True, alpha=0.2, linestyle=':')

    # Environment boundary
    env_rect = mpatches.Rectangle((-ENV_LIM, -ENV_LIM), 2*ENV_LIM, 2*ENV_LIM,
                                   linewidth=2, edgecolor='white',
                                   facecolor='none', zorder=5)
    ax.add_patch(env_rect)

    # Default occlusion zone
    occ = mpatches.Rectangle(OCC_CENTER - OCC_HALF, 2*OCC_HALF, 2*OCC_HALF,
                              linewidth=1.5, edgecolor='cyan',
                              facecolor='none', linestyle='--', zorder=6,
                              label='Occlusion zone')
    ax.add_patch(occ)

    # Road network nodes
    ax.scatter(ROAD_NODES[:, 0], ROAD_NODES[:, 1],
               marker='D', s=60, color='cyan', zorder=7, label='Road nodes')
    for ni, node in enumerate(ROAD_NODES):
        ax.annotate(f'N{ni}', node, fontsize=6, color='cyan',
                    xytext=(3, 3), textcoords='offset points')


# ── Main ────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='GMM heatmap visualizer')
    parser.add_argument('--history_path', type=str, default='obs_history.pkl')
    parser.add_argument('--n_components', type=int, default=3,
                        help='Number of GMM components per target')
    parser.add_argument('--grid_res',     type=int, default=250,
                        help='Heatmap grid resolution (pixels per side)')
    parser.add_argument('--target_id',   type=int, default=None,
                        help='Restrict to one target (default: all)')
    parser.add_argument('--max_points',  type=int, default=500,
                        help='Max scatter points per target (sub-sampled)')
    parser.add_argument('--cmap_heat',   type=str, default='hot',
                        help='Colormap for heatmaps (hot, plasma, inferno, …)')
    parser.add_argument('--save',        type=str, default='gmm_heatmap.png',
                        help='Output file (empty = display only)')
    args = parser.parse_args()

    # ── Load history ─────────────────────────────────────────────────────────
    if not os.path.exists(args.history_path):
        print(f"[ERROR] File not found: {args.history_path}")
        print("  Train with --save_history first:")
        print("    conda run -n tracking_ppo python training/train_lstm_ppo.py \\")
        print("        --use_attention --save_history --history_save_path obs_history.pkl")
        return

    with open(args.history_path, 'rb') as f:
        history_data = pickle.load(f)

    num_targets = len(history_data)
    print(f"Loaded {args.history_path}  ({num_targets} targets)")
    for tid in range(num_targets):
        print(f"  Target {tid}: {len(history_data[tid])} observations")

    target_ids = ([args.target_id] if args.target_id is not None
                  else list(range(num_targets)))

    # ── Fit GMMs ──────────────────────────────────────────────────────────────
    tab10   = matplotlib.colormaps.get_cmap('tab10')
    t_colors = [tab10(i % 10) for i in range(num_targets)]

    gmm_results = {}   # tid → (gmm, means, covs, weights, positions)
    for tid in target_ids:
        buf   = list(history_data[tid])
        pos   = (np.array([e['position'] for e in buf], dtype=np.float32)
                 if buf else np.empty((0, 2), dtype=np.float32))
        try:
            gmm, means, covs, weights = fit_gmm(pos, args.n_components)
            gmm_results[tid] = (gmm, means, covs, weights, pos)
        except Exception as e:
            print(f"  Target {tid}: GMM fit failed — {e}")

    if not gmm_results:
        print("No GMMs fitted — nothing to plot.")
        return

    # ── Figure layout ─────────────────────────────────────────────────────────
    # Row 1: [combined heatmap] [scatter + means]
    # Row 2+: one per-target heatmap per row (if >1 target)
    n_tgts = len(gmm_results)
    n_rows  = 1 + n_tgts          # row 0 = combined + scatter; rows 1..N = per-target
    fig     = plt.figure(figsize=(14, 5 + 4 * n_tgts))
    fig.patch.set_facecolor('#1a1a2e')   # dark background for heatmaps to pop

    gs = fig.add_gridspec(n_rows, 2, hspace=0.45, wspace=0.3)

    ax_combined = fig.add_subplot(gs[0, 0])
    ax_scatter  = fig.add_subplot(gs[0, 1])

    per_target_axes = [fig.add_subplot(gs[1 + i, :]) for i in range(n_tgts)]

    # ── Panel 1: Combined heatmap ─────────────────────────────────────────────
    # Sum densities from all target GMMs → shows "where targets are likely to be"
    combined_Z = None
    XX = YY = None
    for tid, (gmm, means, covs, weights, pos) in gmm_results.items():
        _XX, _YY, Z = gmm_density_grid(gmm, args.grid_res)
        if combined_Z is None:
            XX, YY, combined_Z = _XX, _YY, Z.copy()
        else:
            combined_Z += Z

    im = ax_combined.imshow(
        combined_Z,
        extent=[-ENV_LIM, ENV_LIM, -ENV_LIM, ENV_LIM],
        origin='lower',
        cmap=args.cmap_heat,
        aspect='equal',
        interpolation='bilinear',
    )
    plt.colorbar(im, ax=ax_combined, fraction=0.046, pad=0.04,
                 label='Prob. density (sum)')
    _decorate_ax(ax_combined, title='Combined GMM Heatmap\n(all targets summed)')
    # Overlay GMM means from all targets
    for tid, (gmm, means, covs, weights, pos) in gmm_results.items():
        c = t_colors[tid]
        ax_combined.scatter(means[:, 0], means[:, 1],
                            s=150, marker='*', color=c, zorder=8,
                            edgecolors='white', linewidths=0.5,
                            label=f'T{tid} means')
    ax_combined.legend(loc='upper right', fontsize=7, framealpha=0.6,
                       labelcolor='white', facecolor='#222244')

    # ── Panel 2: Scatter + GMM means ─────────────────────────────────────────
    ax_scatter.set_facecolor('#111122')
    _decorate_ax(ax_scatter, title='Observation History + GMM Means')
    for tid, (gmm, means, covs, weights, pos) in gmm_results.items():
        c = t_colors[tid]
        if len(pos) > 0:
            step = max(1, len(pos) // args.max_points)
            ax_scatter.scatter(pos[::step, 0], pos[::step, 1],
                               s=10, alpha=0.5, color=c,
                               label=f'T{tid} ({len(pos)} obs)')
        ax_scatter.scatter(means[:, 0], means[:, 1],
                           s=180, marker='*', color=c, zorder=8,
                           edgecolors='white', linewidths=0.6)
        for k, (mean, weight) in enumerate(zip(means, weights)):
            ax_scatter.annotate(f'T{tid}·G{k} {weight:.2f}',
                                mean, fontsize=7, color=c,
                                xytext=(5, -11), textcoords='offset points')
    ax_scatter.legend(loc='upper right', fontsize=7, framealpha=0.6,
                      labelcolor='white', facecolor='#222244')

    # ── Rows 2+: Per-target individual heatmaps ───────────────────────────────
    for row_i, (tid, (gmm, means, covs, weights, pos)) in \
            enumerate(gmm_results.items()):

        ax = per_target_axes[row_i]
        ax.set_facecolor('#111122')

        _, _, Z = gmm_density_grid(gmm, args.grid_res)

        # Use a per-target sequential colormap so targets look distinct
        per_cmaps = ['Reds', 'Greens', 'Blues', 'Purples', 'Oranges',
                     'YlOrBr', 'BuGn', 'PuBu', 'RdPu', 'YlGn']
        cmap_name = per_cmaps[tid % len(per_cmaps)]

        im2 = ax.imshow(
            Z,
            extent=[-ENV_LIM, ENV_LIM, -ENV_LIM, ENV_LIM],
            origin='lower',
            cmap=cmap_name,
            aspect='equal',
            interpolation='bilinear',
        )
        plt.colorbar(im2, ax=ax, fraction=0.023, pad=0.02,
                     label='Density')

        _decorate_ax(ax,
                     title=f'Target {tid} — GMM heatmap  '
                           f'({len(pos)} obs, {args.n_components} components)')

        # Overlay scatter
        if len(pos) > 0:
            step = max(1, len(pos) // args.max_points)
            ax.scatter(pos[::step, 0], pos[::step, 1],
                       s=8, alpha=0.35, color='white', label='Observed positions')

        # Overlay means with weight labels
        c = t_colors[tid]
        ax.scatter(means[:, 0], means[:, 1],
                   s=200, marker='*', color='yellow', zorder=8,
                   edgecolors='black', linewidths=0.5, label='GMM means')
        for k, (mean, weight) in enumerate(zip(means, weights)):
            ax.annotate(f'G{k}  w={weight:.2f}',
                        mean, fontsize=8, color='yellow',
                        xytext=(6, -13), textcoords='offset points',
                        fontweight='bold')

        ax.legend(loc='upper right', fontsize=7, framealpha=0.6,
                  labelcolor='white', facecolor='#222244')

    # ── Observation count bar chart ────────────────────────────────────────────
    counts = [len(list(history_data[tid])) for tid in range(num_targets)]
    inset  = ax_scatter.inset_axes([0.02, 0.02, 0.32, 0.28])
    inset.set_facecolor('#222244')
    inset.bar(range(num_targets), counts,
              color=[t_colors[i % len(t_colors)] for i in range(num_targets)],
              edgecolor='white', linewidth=0.5)
    inset.set_xlabel('Target', fontsize=7, color='white')
    inset.set_ylabel('Obs', fontsize=7, color='white')
    inset.set_title('History depth', fontsize=7, color='white')
    inset.tick_params(labelsize=6, colors='white')
    inset.spines[['top', 'right', 'left', 'bottom']].set_color('white')

    fig.suptitle('GMM Search-Prior Map', fontsize=14, color='white', y=1.01)

    if args.save:
        plt.savefig(args.save, dpi=150, bbox_inches='tight',
                    facecolor=fig.get_facecolor())
        print(f"\nSaved → {args.save}")

    plt.show()


if __name__ == '__main__':
    main()
