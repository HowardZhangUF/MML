#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT="${1:-experiment_results/paper_suite}"
PROFILE="${2:-paper}"
PYTHON_BIN="${PYTHON_BIN:-python}"

if [[ "${PROFILE}" == "paper" ]]; then
    EXP1_ARGS=(--contexts-per-scenario 120 --samples 1000 --horizon 40)
    EXP2_ARGS=(--episodes-per-cell 40 --gap-lengths 0,10,20,40,60 --particles 250)
    EXP3_ARGS=(--contexts-per-scenario 10 --samples 250 --episodes-per-cell 10 --particles 250)
    EXP4_ARGS=(--runs 100 --steps 2000)
elif [[ "${PROFILE}" == "smoke" ]]; then
    EXP1_ARGS=(--contexts-per-scenario 1 --samples 8 --horizon 3 --energy-samples 8)
    EXP2_ARGS=(--road-types straight --episodes-per-cell 1 --gap-lengths 0,2 --particles 8 --recovery-deadline 2)
    EXP3_ARGS=(--cfm-nfe 1 --diffusion-steps 1 --contexts-per-scenario 1 --samples 8 --horizon 3 --energy-samples 8 --episodes-per-cell 1 --gap-lengths 2 --particles 8 --timing-repeats 1 --timing-warmup 1)
    EXP4_ARGS=(--runs 1 --steps 10 --methods PF+CV)
else
    echo "Unknown profile '${PROFILE}'. Use 'paper' or 'smoke'." >&2
    exit 2
fi

"${PYTHON_BIN}" scripts/run_experiment1_distribution.py \
    --output-dir "${OUTPUT_ROOT}/experiment1_distribution" \
    "${EXP1_ARGS[@]}"

"${PYTHON_BIN}" scripts/run_experiment2_occlusion.py \
    --output-dir "${OUTPUT_ROOT}/experiment2_occlusion" \
    "${EXP2_ARGS[@]}"

"${PYTHON_BIN}" scripts/run_experiment3_runtime.py \
    --output-dir "${OUTPUT_ROOT}/experiment3_runtime" \
    "${EXP3_ARGS[@]}"

"${PYTHON_BIN}" scripts/run_experiment4_active.py \
    --output-dir "${OUTPUT_ROOT}/experiment4_active" \
    "${EXP4_ARGS[@]}"
