#!/usr/bin/env bash
# run_recovery_experiment.sh
# Runs CFM and MultiPFTra each N times with --recovery_metric --no_fan.
# Results land in tracking_results/ as occlusion_recovery_*.csv files.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$ROOT_DIR"

N_RUNS=${1:-10}
STEPS=${2:-2000}

echo "============================================================"
echo "Occlusion Recovery Experiment"
echo "Runs per method : $N_RUNS"
echo "Steps per run   : $STEPS"
echo "============================================================"

run_method() {
    local method=$1
    local n=$2
    local steps=$3
    echo ""
    echo "--- Method: $method ---"
    for i in $(seq 1 $n); do
        echo "  Run $i / $n ..."
        python scripts/info_mml_main.py \
            --prediction_method "$method" \
            --guidance_mode MultiPFInfo \
            --num_steps "$steps" \
            --recovery_metric \
            --no_fan \
            --run_number "$i" \
            2>&1 | grep -E "(LOST|FOUND|RECOVERY|events|rate|prob|step)"
        echo "  Run $i done."
    done
}

run_method CFM        "$N_RUNS" "$STEPS"
run_method MultiPFTra "$N_RUNS" "$STEPS"

echo ""
echo "============================================================"
echo "All runs complete. Results in tracking_results/"
echo "Now run:  python scripts/aggregate_recovery_results.py"
echo "============================================================"
