import sys
import os
import torch
import zipfile
import numpy as np
from unittest.mock import MagicMock

# =========================================================
# 1. THE BLACK HOLE PATCH (Absorbs ALL method calls)
# =========================================================
import pymunk 

class BlackHoleMock:
    """A mock that returns itself for any attribute access or method call."""
    def __init__(self, *args, **kwargs):
        # Initialize lists to empty so loops (for x in space.shapes) finish instantly
        self.shapes = []
        self.bodies = []
        self.constraints = []
        self.arbiters = []
        self.gravity = (0,0)
        self.damping = 0.0
        self.static_body = MagicMock()
        
    def __getattr__(self, name):
        # If code asks for .debug_draw, .step, .add, etc., return a dummy function
        return MagicMock()

# Replace the real Space class with our Black Hole
print("🩹 Applying black hole patch to pymunk.Space...")
pymunk.Space = BlackHoleMock
# =========================================================

from sb3_contrib import RecurrentPPO
from stable_baselines3.common.env_util import make_vec_env

# Add path to find custom code
sys.path.append(os.getcwd())

try:
    from environments.gym_pursuit_env import GymPursuitEnv
    from attention_policy import AttentionFeatureExtractor
except ImportError as e:
    print(f"Import Error: {e}")
    sys.exit(1)

# --- CONFIGURATION ---
BAD_MODEL_PATH = "models_recurrent/recurrent_ppo_ospa_info_final_20251217_032545.zip"
FIXED_MODEL_PATH = "fixed_model.zip"
USE_ATTENTION = True 

def create_fresh_model():
    # This will now initialize safely because pymunk.Space absorbs all calls
    env = make_vec_env(lambda: GymPursuitEnv(
        use_particle_filter=True,
        use_attention=USE_ATTENTION,
        max_tracked_targets=10
    ), n_envs=1)
    
    policy_kwargs = dict(
        lstm_hidden_size=256, 
        n_lstm_layers=2,
        enable_critic_lstm=True
    )

    if USE_ATTENTION:
        policy_kwargs.update(dict(
            features_extractor_class=AttentionFeatureExtractor,
            features_extractor_kwargs=dict(features_dim=128),
        ))
    
    return RecurrentPPO("MultiInputLstmPolicy", env, verbose=1, policy_kwargs=policy_kwargs)

def transplant():
    print(f"🔧 Extracting weights from {BAD_MODEL_PATH}...")
    
    with zipfile.ZipFile(BAD_MODEL_PATH, 'r') as zip_ref:
        zip_ref.extract("policy.pth", ".")
    
    print("🧠 Loading raw weights...")
    device = torch.device("cpu")
    weights = torch.load("policy.pth", map_location=device)
    
    print(f"🏥 Creating fresh model (Attention: {USE_ATTENTION})...")
    model = create_fresh_model()
    
    # --- SAFE LOAD LOGIC ---
    print("📥 Injecting weights...")
    current_model_dict = model.policy.state_dict()
    
    # Filter matching keys only
    new_state_dict = {k: v for k, v in weights.items() if k in current_model_dict}
    
    # Load with strict=False to allow minor mismatches
    model.policy.load_state_dict(new_state_dict, strict=False)
    print(f"✅ Loaded {len(new_state_dict)} layers successfully.")
    
    model.save(FIXED_MODEL_PATH)
    print(f"🎉 SUCCESS! Saved compatible model to: {FIXED_MODEL_PATH}")
    
    if os.path.exists("policy.pth"):
        os.remove("policy.pth")

if __name__ == "__main__":
    transplant()