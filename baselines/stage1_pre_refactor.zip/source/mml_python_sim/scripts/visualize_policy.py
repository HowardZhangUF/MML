"""
Visualize trained PPO policy with rendering.
"""
import argparse
import time
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from gym_pursuit_env import GymPursuitEnv


def visualize_policy(model_path, n_episodes=3, max_steps=1000, fps=30):
    """Render policy execution."""
    # Load model
    model = PPO.load(model_path)
    print(f"Loaded model from: {model_path}")
    
    # Create environment with rendering
    env = GymPursuitEnv(render_mode="human", max_steps=max_steps)
    env = DummyVecEnv([lambda: env])
    
    # Load normalization
    try:
        vecnorm_path = model_path.rsplit("/", 1)[0] + "/vecnormalize.pkl"
        env = VecNormalize.load(vecnorm_path, env)
        env.training = False
        env.norm_reward = False
        print(f"✓ Loaded normalization")
    except:
        print("⚠ No normalization found")
    
    dt = 1.0 / fps
    
    for ep in range(n_episodes):
        obs = env.reset()
        done = False
        ep_reward = 0
        step = 0
        
        print(f"\n--- Episode {ep+1}/{n_episodes} ---")
        
        while not done:
            start_time = time.time()
            
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, done, info = env.step(action)
            ep_reward += reward[0]
            step += 1
            
            # Print info
            if step % 20 == 0:
                dist = info[0].get('distance', 0)
                print(f"Step {step}: Distance={dist:.3f}m, Reward={ep_reward:.2f}")
            
            # Maintain frame rate
            elapsed = time.time() - start_time
            if elapsed < dt:
                time.sleep(dt - elapsed)
            
            if done[0]:
                capture = info[0].get('capture', False)
                dist = info[0].get('distance', 0)
                status = "CAPTURED!" if capture else f"Timeout (dist={dist:.3f}m)"
                print(f"Episode finished: {status}, Total Reward: {ep_reward:.2f}")
                time.sleep(2)  # Pause before next episode
                break
    
    env.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model", 
        type=str, 
        default=r".\policies\ppo_pursuit_20251028_115312\final_model.zip",
        help="Path to trained model"
    )
    parser.add_argument("--episodes", type=int, default=3, help="Number of episodes to visualize")
    parser.add_argument("--max-steps", type=int, default=1000, help="Max steps per episode")
    parser.add_argument("--fps", type=int, default=30, help="Rendering frame rate")
    args = parser.parse_args()
    
    visualize_policy(args.model, n_episodes=args.episodes, max_steps=args.max_steps, fps=args.fps)