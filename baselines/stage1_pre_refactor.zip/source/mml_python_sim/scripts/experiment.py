import subprocess
import os
import shutil
from datetime import datetime
import yaml

def run_experiment(guidance_mode, prediction_method, run_number, output_dir):
    """
    Run a single experiment by modifying config and calling info_mml_main.py
    """
    print(f"\n{'='*60}")
    print(f"Running: {guidance_mode} - Run {run_number + 1}/10")
    print(f"{'='*60}\n")
    
    # Modify the guidance_mode in info_mml_main.py temporarily
    # Or better: pass as command line argument (see modified version below)
    
    # Run the simulation
    result = subprocess.run(
        ["python", "info_mml_main.py", 
         "--guidance_mode", guidance_mode,
         "--prediction_method", prediction_method,
         "--run_number", str(run_number)],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        print(f"❌ Error in run {run_number + 1}:")
        print(result.stderr)
        return False
    
    # Move the generated CSV to organized folder
    csv_name = f"{prediction_method}_{guidance_mode}.csv"
    if os.path.exists(csv_name):
        # Rename with run number
        new_name = f"{prediction_method}_{guidance_mode}_run{run_number + 1:02d}.csv"
        dest_path = os.path.join(output_dir, new_name)
        shutil.move(csv_name, dest_path)
        print(f"✓ Saved: {dest_path}")
        return True
    else:
        print(f"⚠ CSV file not found: {csv_name}")
        return False

def main():
    # Configuration
    guidance_modes = [
        "MultiPFInfoPPO_LSTM"
    ]
    prediction_method = "MultiPFTra"
    num_runs = 10
    
    # Create output directory with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_output_dir = f"experiment_results_{timestamp}"
    os.makedirs(base_output_dir, exist_ok=True)
    
    print(f"\n🚀 Starting Experiment Suite")
    print(f"Output directory: {base_output_dir}")
    print(f"Guidance modes: {guidance_modes}")
    print(f"Runs per mode: {num_runs}")
    print(f"{'='*60}\n")
    
    # Run experiments for each guidance mode
    results_summary = {}
    
    for guidance_mode in guidance_modes:
        print(f"\n{'#'*60}")
        print(f"# Starting experiments for: {guidance_mode}")
        print(f"{'#'*60}")
        
        # Create subdirectory for this guidance mode
        mode_output_dir = os.path.join(base_output_dir, guidance_mode)
        os.makedirs(mode_output_dir, exist_ok=True)
        
        successful_runs = 0
        
        for run_num in range(num_runs):
            success = run_experiment(
                guidance_mode, 
                prediction_method, 
                run_num, 
                mode_output_dir
            )
            if success:
                successful_runs += 1
        
        results_summary[guidance_mode] = successful_runs
        print(f"\n✓ Completed {successful_runs}/{num_runs} runs for {guidance_mode}")
    
    # Print final summary
    print(f"\n{'='*60}")
    print("EXPERIMENT SUMMARY")
    print(f"{'='*60}")
    for mode, count in results_summary.items():
        status = "✓" if count == num_runs else "⚠"
        print(f"{status} {mode}: {count}/{num_runs} successful runs")
    print(f"\nResults saved to: {base_output_dir}")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()