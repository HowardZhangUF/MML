import sys
import os

# Add parent directory to Python path
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

from environments.pygame_large_env import PygameEnvironment
import numpy as np

import torch

import yaml

use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")

# read in config file
def load_config(file_path):
    with open(file_path) as f:
        return yaml.safe_load(f)
    
def pd_tracker(agent_pos, target_pos, agent_vel, target_vel, Kp=1.0, Kd=0.1):
    """
    PD controller for tracking target position.
    tau = Kp * position_error + Kd * velocity_error
    """
    position_error = target_pos - agent_pos
    velocity_error = target_vel - agent_vel
    tau = Kp * position_error + Kd * velocity_error
    # add a third element of angular velocity = 0
    tau = np.append(tau, 0)
    return tau

if __name__ == "__main__":
    # load params
    config_params = load_config("config.yaml")
    number_targets = config_params["number_targets"]  # number of targets
    number_sim_steps = config_params["number_sim_steps"]  # number of steps for the sim
    initial_model = config_params["initial_model"]  # initial model
    dt = config_params["dt"]  # time step

    # environments to train
    env = PygameEnvironment()

    # reset environment and get initial state
    state, _ = env.reset()
    eta_ = state[0,:]
    # state is a 2D array with shape (number_agents + number_targets, 6)
    z_ = state[1,:]
    # PD controller gains
    Kp = 1.0
    Kd = 0.1

    # start stepping through the sim
    env.render_init()
    step = 0
    while step < number_sim_steps:
        eta_ = state[0,:]  # agent state
        z_ = state[1,:]    # target state
        # Assuming positions are first two elements, velocities are next two
        agent_pos = eta_[:2]
        agent_vel = eta_[2:4]
        target_pos = z_[:2]
        target_vel = z_[2:4]
        tau = pd_tracker(agent_pos, target_pos, agent_vel, target_vel, Kp, Kd)
        next_state, _ = env.step(tau)
        state = next_state
        env.render()
        step += 1

    print("Closing sim")
    env.render_close()

