import pandas as pd
import numpy as np
import os
import glob
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import datetime

def analyze_tracking_results(results_dir="tracking_results", date_filter=None):
    """
    Analyze CSV files from tracking_results folder.
    
    Args:
        results_dir: Directory containing CSV files
        date_filter: Dict like {'MultiPFInfo': '20251208', 'MultiPFInfoPPO_LSTM': '20251209'}
                     to filter files by date. Use None to include all dates.
    """
    
    # Find all CSV files
    csv_pattern = os.path.join(results_dir, "MultiPFTra_*.csv")
    all_csv_files = glob.glob(csv_pattern)
    
    if not all_csv_files:
        print(f"❌ No CSV files found in {results_dir}")
        return None, None
    
    print(f"📂 Found {len(all_csv_files)} total CSV files in {results_dir}")
    
    # Group by guidance mode
    grouped_files = {}
    skipped_files = {}
    
    for csv_file in all_csv_files:
        filename = os.path.basename(csv_file)
        # Format: MultiPFTra_{GuidanceMode}_tracking_metrics_{YYYYMMDD}_{HHMMSS}.csv
        parts = filename.replace("MultiPFTra_", "").split("_tracking_metrics_")
        
        if len(parts) >= 2:
            guidance_mode = parts[0]
            timestamp_part = parts[1].replace('.csv', '')  # e.g., "20251208_155524"
            date_str = timestamp_part.split('_')[0]  # e.g., "20251208"
            
            # Apply date filter if provided
            if date_filter and guidance_mode in date_filter:
                expected_date = date_filter[guidance_mode]
                if date_str != expected_date:
                    # Track skipped files
                    if guidance_mode not in skipped_files:
                        skipped_files[guidance_mode] = []
                    skipped_files[guidance_mode].append((filename, date_str))
                    continue  
            
            if guidance_mode not in grouped_files:
                grouped_files[guidance_mode] = []
            grouped_files[guidance_mode].append(csv_file)
    
    print(f"\n📊 Guidance modes found: {list(grouped_files.keys())}")
    
    # Print file counts and date info
    for mode, files in grouped_files.items():
        print(f"\n  {'='*50}")
        print(f"  {mode}:")
        print(f"    ✓ Using {len(files)} files")
        
        if date_filter and mode in date_filter:
            print(f"    📅 Filter: date = {date_filter[mode]}")
            
            # Show what was skipped
            if mode in skipped_files:
                print(f"    ⏭️  Skipped {len(skipped_files[mode])} files from other dates:")
                date_counts = {}
                for _, date in skipped_files[mode]:
                    date_counts[date] = date_counts.get(date, 0) + 1
                for date, count in sorted(date_counts.items()):
                    print(f"       • {date}: {count} files")
    
    print(f"\n{'='*60}")
    
    all_results = {}
    
    for mode, csv_files in grouped_files.items():
        print(f"\n{'='*60}")
        print(f"Analyzing: {mode} ({len(csv_files)} runs)")
        print(f"{'='*60}")
        
        if len(csv_files) == 0:
            print(f"  ⚠️  No files matching filter for {mode}")
            continue
        
        # Load all runs for this mode
        dfs = []
        for csv_file in csv_files:
            try:
                df = pd.read_csv(csv_file)
                dfs.append(df)
                filename = os.path.basename(csv_file)
                date_time = filename.split("_tracking_metrics_")[1].replace('.csv', '')
                print(f"  ✓ {date_time}")
            except Exception as e:
                print(f"  ❌ Error loading {os.path.basename(csv_file)}: {e}")
                continue
        
        if not dfs:
            print(f"  ⚠️  No valid data for {mode}")
            continue
        
        # Print column names from first file
        print(f"\n  📋 Available columns: {list(dfs[0].columns)}")
        
        # Compute statistics across runs
        final_metrics = {}
        
        # Dynamically find metric columns
        metric_columns = [col for col in dfs[0].columns 
                         if col not in ['step', 'time', 'timestamp', 'episode']]
        
        for metric_col in metric_columns:
            final_metrics[metric_col] = []
            for df in dfs:
                if metric_col in df.columns:
                    # Use mean over entire run
                    final_metrics[metric_col].append(df[metric_col].mean())
        
        # Compute statistics
        stats = {}
        for metric, values in final_metrics.items():
            if values:
                stats[f'{metric}_mean'] = np.mean(values)
                stats[f'{metric}_std'] = np.std(values)
                stats[f'{metric}_min'] = np.min(values)
                stats[f'{metric}_max'] = np.max(values)
                stats[f'{metric}_median'] = np.median(values)
                stats['n_runs'] = len(values)
        
        all_results[mode] = stats
        
        # Print statistics
        print(f"\n  📈 Statistics for {mode} (n={len(csv_files)} runs):")
        for metric in metric_columns:
            if f'{metric}_mean' in stats:
                print(f"    {metric:20s}: {stats[f'{metric}_mean']:7.4f} ± {stats[f'{metric}_std']:7.4f}  "
                      f"[{stats[f'{metric}_min']:7.4f}, {stats[f'{metric}_max']:7.4f}]  "
                      f"median={stats[f'{metric}_median']:7.4f}")
    
    # Create summary DataFrame
    if all_results:
        summary_df = pd.DataFrame(all_results).T
        
        # Save with date filter info in filename
        if date_filter:
            filter_str = "_".join([f"{k.replace('MultiPF', '')}_{v}" for k, v in date_filter.items()])
            summary_file = os.path.join(results_dir, f"summary_statistics_{filter_str}.csv")
        else:
            summary_file = os.path.join(results_dir, "summary_statistics_all.csv")
        
        summary_df.to_csv(summary_file)
        print(f"\n✅ Summary saved to: {summary_file}")
        
        return all_results, summary_df
    else:
        print("\n❌ No results to summarize")
        return None, None


def plot_comparison(results_dir, summary_df, date_filter=None):
    """Create comparison bar plots with available metrics"""
    
    if summary_df is None or summary_df.empty:
        print("⚠️  No data to plot")
        return
    
    # Find available metrics (columns ending with '_mean')
    mean_cols = [col for col in summary_df.columns if col.endswith('_mean') and col != 'n_runs']
    
    if not mean_cols:
        print("⚠️  No metrics found to plot")
        return
    
    # Create plots
    n_metrics = len(mean_cols)
    n_cols = min(3, n_metrics)
    n_rows = (n_metrics + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(6*n_cols, 5*n_rows))
    if n_metrics == 1:
        axes = [axes]
    else:
        axes = axes.flatten() if isinstance(axes, np.ndarray) else [axes]
    
    for idx, metric_col in enumerate(mean_cols):
        ax = axes[idx]
        
        metric_name = metric_col.replace('_mean', '')
        std_col = metric_col.replace('_mean', '_std')
        
        modes = summary_df.index.tolist()
        means = summary_df[metric_col].values
        stds = summary_df[std_col].values if std_col in summary_df.columns else np.zeros(len(modes))
        
        # Create bar plot
        x_pos = np.arange(len(modes))
        bars = ax.bar(x_pos, means, yerr=stds, capsize=8, alpha=0.8, 
                     edgecolor='black', linewidth=1.5)
        
        # Color bars differently
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8']
        for bar, color in zip(bars, colors[:len(bars)]):
            bar.set_color(color)
        
        ax.set_ylabel(metric_name.upper(), fontweight='bold', fontsize=12)
        ax.set_title(f'{metric_name.upper()} Comparison', fontweight='bold', fontsize=13)
        ax.set_xticks(x_pos)
        ax.set_xticklabels([m.replace('MultiPF', '') for m in modes], 
                          rotation=30, ha='right', fontsize=10)
        ax.grid(axis='y', alpha=0.3, linestyle='--')
        
        # Add value labels on bars
        for i, (bar, mean, std) in enumerate(zip(bars, means, stds)):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + std,
                   f'{mean:.4f}\n±{std:.4f}',
                   ha='center', va='bottom', fontsize=9, fontweight='bold')
        
        # Add sample size
        n_runs = summary_df.loc[modes[0], 'n_runs'] if 'n_runs' in summary_df.columns else 'N/A'
        ax.text(0.02, 0.98, f'n={int(n_runs)} runs/mode', 
               transform=ax.transAxes, va='top', fontsize=9,
               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # Hide unused subplots
    for idx in range(len(mean_cols), len(axes)):
        axes[idx].set_visible(False)
    
    # Add title with date filter info
    if date_filter:
        filter_info = " | ".join([f"{k.replace('MultiPF', '')}: {v}" for k, v in date_filter.items()])
        fig.suptitle(f'Tracking Performance Comparison\nDate Filters: {filter_info}', 
                    fontsize=14, fontweight='bold', y=0.995)
    
    plt.tight_layout()
    
    # Save with date filter info in filename
    if date_filter:
        filter_str = "_".join([f"{k.replace('MultiPF', '')}_{v}" for k, v in date_filter.items()])
        plot_file = os.path.join(results_dir, f"comparison_{filter_str}.png")
    else:
        plot_file = os.path.join(results_dir, "comparison_all.png")
    
    plt.savefig(plot_file, dpi=300, bbox_inches='tight')
    print(f"✅ Comparison plot saved to: {plot_file}")
    plt.show()


def plot_time_series(results_dir, date_filter=None):
    """Plot metrics over time for each guidance mode"""
    
    csv_pattern = os.path.join(results_dir, "MultiPFTra_*.csv")
    all_csv_files = glob.glob(csv_pattern)
    
    if not all_csv_files:
        return
    
    # Group by guidance mode with date filter
    grouped_files = {}
    for csv_file in all_csv_files:
        filename = os.path.basename(csv_file)
        parts = filename.replace("MultiPFTra_", "").split("_tracking_metrics_")
        
        if len(parts) >= 2:
            guidance_mode = parts[0]
            timestamp_part = parts[1].replace('.csv', '')
            date_str = timestamp_part.split('_')[0]
            
            # Apply date filter
            if date_filter and guidance_mode in date_filter:
                if date_str != date_filter[guidance_mode]:
                    continue
            
            if guidance_mode not in grouped_files:
                grouped_files[guidance_mode] = []
            grouped_files[guidance_mode].append(csv_file)
    
    if not grouped_files:
        print("⚠️  No files match the date filter for time series")
        return
    
    # Plot each mode
    for mode, csv_files in grouped_files.items():
        print(f"\n📈 Plotting time series for {mode} ({len(csv_files)} runs)")
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        axes = axes.flatten()
        
        metrics = ['wasserstein', 'ospa', 'rmse', 'num_tracks']
        colors = plt.cm.tab10(np.linspace(0, 1, len(csv_files)))
        
        for file_idx, csv_file in enumerate(csv_files):
            try:
                df = pd.read_csv(csv_file)
                
                for idx, metric in enumerate(metrics):
                    if metric in df.columns:
                        if 'time' in df.columns:
                            axes[idx].plot(df['time'], df[metric], 
                                         alpha=0.4, linewidth=1, 
                                         color=colors[file_idx])
                        else:
                            axes[idx].plot(df[metric], 
                                         alpha=0.4, linewidth=1,
                                         color=colors[file_idx])
            except Exception as e:
                print(f"  ⚠️  Error plotting {os.path.basename(csv_file)}: {e}")
        
        for idx, metric in enumerate(metrics):
            axes[idx].set_ylabel(metric.upper(), fontweight='bold', fontsize=12)
            axes[idx].set_xlabel('Time (s)' if 'time' in df.columns else 'Step', 
                                fontweight='bold', fontsize=11)
            axes[idx].set_title(f'{metric.upper()} over Time', 
                              fontweight='bold', fontsize=13)
            axes[idx].grid(alpha=0.3, linestyle='--')
        
        # Add title with date info
        if date_filter and mode in date_filter:
            title = f'{mode} - Time Series\n(n={len(csv_files)} runs, date={date_filter[mode]})'
        else:
            title = f'{mode} - Time Series (n={len(csv_files)} runs)'
        
        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        # Save with date filter info
        if date_filter and mode in date_filter:
            plot_file = os.path.join(results_dir, f"{mode}_{date_filter[mode]}_timeseries.png")
        else:
            plot_file = os.path.join(results_dir, f"{mode}_timeseries.png")
        
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        print(f"  ✓ Saved: {plot_file}")
        plt.close()
def analyze_covariance_health(results_dir="tracking_results", date_filter=None):
    """
    Analyze covariance determinant values to identify potential issues.
    """
    csv_pattern = os.path.join(results_dir, "MultiPFTra_*.csv")
    all_csv_files = glob.glob(csv_pattern)
    
    print(f"\n{'='*60}")
    print("COVARIANCE HEALTH ANALYSIS")
    print(f"{'='*60}")
    
    for csv_file in all_csv_files:
        filename = os.path.basename(csv_file)
        parts = filename.replace("MultiPFTra_", "").split("_tracking_metrics_")
        
        if len(parts) >= 2:
            guidance_mode = parts[0]
            timestamp_part = parts[1].replace('.csv', '')
            date_str = timestamp_part.split('_')[0]
            
            # Apply date filter
            if date_filter and guidance_mode in date_filter:
                if date_str != date_filter[guidance_mode]:
                    continue
            
            try:
                df = pd.read_csv(csv_file)
                
                if 'determinant_of_covariance' in df.columns:
                    det_values = df['determinant_of_covariance'].dropna()
                    
                    if len(det_values) > 0:
                        print(f"\n{guidance_mode} - {timestamp_part}:")
                        print(f"  Determinant range: [{det_values.min():.6e}, {det_values.max():.6e}]")
                        print(f"  Determinant mean: {det_values.mean():.6e} ± {det_values.std():.6e}")
                        
                        # Check for suspiciously small values
                        very_small = (det_values < 1e-6).sum()
                        if very_small > 0:
                            print(f"  ⚠️  {very_small}/{len(det_values)} steps have det < 1e-6")
                        
                        # Check for zero determinants
                        zeros = (det_values == 0).sum()
                        if zeros > 0:
                            print(f"  ❌ {zeros}/{len(det_values)} steps have ZERO determinant!")
            
            except Exception as e:
                print(f"  Error reading {filename}: {e}")
    
    print(f"{'='*60}\n")

if __name__ == "__main__":
    import sys
    
    results_dir = "tracking_results"
    
    # ✅ Define date filters for each guidance mode
    # Change these dates to match your actual files
    date_filter = {
        'MultiPFInfo': '20251215',           # Files from Dec 8, 2025 (11 files available)
        'MultiPFInfoPPO': '20251216',  
        'MultiPFInfoPPO_LSTM': '20251217'    # Files from Dec 9, 2025 (⚠️ NO FILES YET!)
    }
    
    # Check if we should use all files or filter by date
    use_filter = True  # Set to False to analyze ALL files
    
    if not use_filter:
        date_filter = None
        print("\n⚠️  Date filter DISABLED - analyzing ALL files\n")
    
    # Override from command line if provided
    if len(sys.argv) > 1:
        results_dir = sys.argv[1]
    
    if not os.path.exists(results_dir):
        print(f"❌ Directory not found: {results_dir}")
        sys.exit(1)
    
    print(f"\n{'='*60}")
    print(f"TRACKING RESULTS ANALYSIS")
    print(f"{'='*60}")
    print(f"Directory: {results_dir}")
    
    if date_filter:
        print(f"\n📅 Date Filters Applied:")
        for mode, date in date_filter.items():
            print(f"  {mode}: only files from {date}")
    else:
        print(f"\n📅 No date filter - using ALL files")
    
    print(f"{'='*60}\n")
    
    # Analyze results with date filter
    all_results, summary_df = analyze_tracking_results(results_dir, date_filter=date_filter)
    analyze_covariance_health(results_dir, date_filter=date_filter)
    if summary_df is not None:
        # Create comparison plots
        plot_comparison(results_dir, summary_df, date_filter=date_filter)
        
        # Create time series plots
        plot_time_series(results_dir, date_filter=date_filter)
        
        print(f"\n{'='*60}")
        print("SUMMARY STATISTICS")
        print(f"{'='*60}")
        print(summary_df.to_string())
        print(f"\n{'='*60}")
        print("✅ ANALYSIS COMPLETE")
        print(f"{'='*60}")
    else:
        print("\n❌ Analysis failed - no valid data found")