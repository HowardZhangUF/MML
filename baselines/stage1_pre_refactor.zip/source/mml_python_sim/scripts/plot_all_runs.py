import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# Set the font sizes for the plot labels
font = {"family": "serif", "weight": "normal", "size": 18}
sns.set_theme()
sns.set_style("white")
sns.set_context("paper", font_scale=2)


def plot_error_bars(
    error_df, outdir_all, title, ylabel, xlabel, figwidth, islegend=False
):
    ## PLOTS
    rms_estimator = lambda x: np.sqrt(np.mean(np.square(x)))
    dpi = 300
    # BAR
    fig, ax = plt.subplots(figsize=(figwidth, 6.5))
    sns.barplot(
        y="Guidance Method",
        x="Error",
        data=error_df,
        ax=ax,
        hue="hue",
        estimator=rms_estimator,
        capsize=0.1,
        errorbar="sd",
        width=1.0,
        legend=islegend,  # Suppress the legend
        err_kws={"linewidth": 1.5},
    )
    if islegend:
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(
            handles, labels, title="Guidance Methods", fontsize=16,
            title_fontsize=18, loc="upper right"
        )
    # ax.set_xticklabels(ax.get_xticklabels(), fontdict=font)
    ax.set_ylabel(ylabel=ylabel, fontdict=font)
    ax.set_xlabel(xlabel=xlabel, fontdict=font)
    # ax.set_ylim([0, 5])
    sns.despine(right=True)
    plt.tight_layout()  # Automatically adjust subplot parameters to give specified padding
    # plt.show()
    plt.savefig(outdir_all + title + ".png", dpi=dpi)

def main():
    # Set the name of the input CSV directory
    folder_path = "./tracking_results/"

    include_data = {
        "err estimation norm": "$ee$ $[m]$",
        "err tracking norm": "$te$ $[m]$",
        "entropy data": "Entropy",
        "n eff particles data": "Effective Number of Particles",
        "xyTh estimate cov det": r"$\det({\Sigma_k})$  $[m^2]$",
        "is update data": r"\% FOV",
        "wasserstein_2d": "Wasserstein Distance [m]",
        "ospa": "OSPA Distance [m]", 
        "cardinality_error": "Cardinality Error",
        "rmse": "RMSE [m]",
        "determinant_of_covariance": r"$\det({\Sigma_k})$  $[m^2]$",
    }

    guidance_method = {
        "Velocity": "VEL",
        "KF": "KF",
        "DMMN": "DMMN",
        "VelTimNN": "DNN",
        "PosTRA": "PFWM",
        "MeanKF": "KF",
        "PosTRA": "PosTRA",
        "PosNN": "PosNN",
        "VelTRA": "VelTRA",
        "VelNN": "VelNN",
        "PosTimTRA": "PosTimTRA",
        "PosTimNN": "PosTimNN",
        "VelTimTRA": "VelTimTRA",
        "VelTimNN": "VelTimNN",
        "PFVelocity": "PFVelocity",
        "MultiKF": "Multi-KF",
        "MultiPF": "Multi-PF",
        "KF_Lawnmower": "KF Lawnmower",
        "MultiKF_MultiKFInfo": "Multi-KF Info",
        "MultiPFVel_MultiPFInfo": "Multi-PF Vel Info",
        "MultiPFTra_MultiPFInfo": "MultiPF Tra Info",
    }

    filenames = os.listdir(folder_path)
    print("Number of individual runs found:", len(filenames))
    csv_dict = dict()
    all_values_dict = dict()
    for filename in filenames:
        if filename.endswith(".csv"):
            first_word = "_".join(filename.split("_")[:2])
            if first_word not in csv_dict:
                csv_dict[first_word] = dict()
                all_values_dict[first_word] = dict()
            datetime_file = "_".join(filename[:-4].split("_")[-2:])  # ignore ".csv"
            csv_dict[first_word][datetime_file] = dict()

            file_df = pd.read_csv(folder_path + filename, low_memory=False)

            # Collect data for RMS values csv
            for col_name in file_df.columns:
                if (any(col_name == word for word in include_data)):
                    rms = round(np.sqrt(np.mean(file_df[col_name] ** 2)), 3)
                    sd = round(np.std(file_df[col_name]), 3)  # standard deviation
                    csv_dict[first_word][datetime_file][col_name] = (float(rms), float(sd))
                    if col_name not in all_values_dict[first_word]:
                        all_values_dict[first_word][col_name] = file_df[col_name]
                    else:
                        all_values_dict[first_word][col_name] = pd.concat([all_values_dict[first_word][col_name], file_df[col_name]], ignore_index=True)
            csv_dict[first_word][datetime_file]["num_elements"] = len(file_df)
            csv_dict[first_word][datetime_file]["total_time"] = file_df["time"].iloc[-1] if "time" in file_df.columns else None
    print("List of columns found:", file_df.columns.tolist())

    print("List of methods found: ", list(csv_dict.keys()))
    joined_dir = os.path.join(folder_path, "joined")
    error_df = pd.DataFrame()
    rms_std_dict = dict()
    for method in all_values_dict.keys():
        csv_df = pd.DataFrame.from_dict(csv_dict[method], orient="index")
        method_dir = os.path.join(joined_dir, method)
        if not os.path.exists(method_dir):
            os.makedirs(method_dir)
        datetime_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_df.to_csv(os.path.join(method_dir, f"{datetime_str}_overall.csv"), index=True)
 
        all_csv_df = pd.DataFrame.from_dict(all_values_dict[method], orient="index").T

        # Process each metric separately
        rms_std_dict[method] = dict()
        for col_name in all_csv_df.columns:
            if col_name in include_data:
                pmean = all_csv_df[col_name].dropna().mean()
                pstd = all_csv_df[col_name].dropna().std()
                row = pd.DataFrame({
                    "Error": include_data[col_name],
                    "hue": guidance_method[method],
                    "Guidance Method": (pmean + pstd, pmean - pstd)
                })
                error_df = pd.concat([error_df, row], ignore_index=True)
                rms_std_dict[method][col_name] = (float(pmean), float(pstd))

                # histogram
                plt.figure(figsize=(6,4))
                sns.histplot(all_csv_df[col_name].dropna(), bins=30)
                plt.xlabel(include_data[col_name], fontdict={"weight": "normal", "size": 18})
                plt.ylabel("Frequency", fontdict={"weight": "normal", "size": 18})
                plt.title(f"Histogram of {include_data[col_name]} for {method}", fontdict={"weight": "normal", "size": 18})
                plt.tight_layout()
                plt.savefig(os.path.join(method_dir, f"{method}_{col_name}_histogram.png"), dpi=300)
                plt.close()

    outdir_all = os.path.join(folder_path, "all/")
    if not os.path.exists(outdir_all):
        os.makedirs(outdir_all)

    csv_df = pd.DataFrame.from_dict(rms_std_dict, orient="index")
    csv_df.to_csv(outdir_all + "all_runs_rms.csv")

    for error_type in error_df["Error"].unique():
        plot_error_bars(
            error_df[error_df["Error"] == error_type], outdir_all, error_type+"errors", "Values", "", figwidth=6, islegend=True
        )

if __name__ == "__main__":
    main()
