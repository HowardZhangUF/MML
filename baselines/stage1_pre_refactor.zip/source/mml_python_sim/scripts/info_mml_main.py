#!/usr/bin/env python3
import sys
import os
import argparse
import random
import time
from contextlib import ExitStack

parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

src_dir = os.path.join(parent_dir, "src", "mml_guidance")
sys.path.insert(0, src_dir)

import numpy as np
import torch
import yaml

from environments.pygame_large_env import PygameEnvironment
from environments.observation_history import ObservationHistoryManager
from scripts.metrics import FilterBenchmarkTracker, MetricsTracker, OcclusionRecoveryTracker
from scripts.experiment_initialization import (
    sample_visible_initial_target_positions,
)

from mml_guidance.guidance import Guidance
from mml_guidance.ParticleFilter import ParticleFilter


use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")

MULTI_PF_METHODS = frozenset(
    {
        "MultiPFVel",
        "MultiPFTra",
        "CFM",  # legacy name for the original CFM full-system path
        "PF+CFM",
        "PF+CFM-AS",
        "PF+NF",
        "PF+Diffusion",
        "DiffPF",
    }
)
MULTI_TRACKER_METHODS = MULTI_PF_METHODS | {"MultiKF"}
TRAJECTORY_FAN_METHODS = frozenset(
    {"MultiPFTra", "CFM", "PF+CFM", "PF+CFM-AS", "PF+NF", "PF+Diffusion"}
)


# ─────────────────────────────────────────────────────────────────────────────
# Config helpers
# ─────────────────────────────────────────────────────────────────────────────

def load_config(file_path):
    with open(file_path) as f:
        return yaml.safe_load(f)


def resolve_model_path(project_root: str,
                       prediction_method: str,
                       user_model_path: str | None = None) -> str | None:
    """
    Choose the correct model checkpoint for the selected prediction method.

    CFM:
        uses the original anchor-sigma checkpoint.

    PF+CFM / PF+CFM-AS:
        use the sigma=1.0 CFM checkpoint. PF+CFM-AS changes only the
        inference-time proposal spread after loading this velocity field.

    PF+NF / PF+Diffusion / DiffPF:
        use their trained standalone benchmark checkpoints.

    MultiPFTra / Transformer:
        uses the original ScratchTransformer checkpoint.

    MultiPFVel:
        no neural model checkpoint is needed.
    """
    if user_model_path is not None:
        return user_model_path

    model_dir = os.path.join(project_root, "src", "mml_guidance", "models")

    if prediction_method == "CFM":
        return os.path.join(
            model_dir,
            "cfm_motion_model.pth",
        )

    if prediction_method in {"PF+CFM", "PF+CFM-AS"}:
        return os.path.join(model_dir, "cfm_motion_model_anchor1.0.pth")

    if prediction_method == "PF+NF":
        return os.path.join(model_dir, "nf_motion_model.pth")

    if prediction_method == "PF+Diffusion":
        return os.path.join(model_dir, "diffusion_motion_model.pth")

    if prediction_method == "DiffPF":
        return os.path.join(model_dir, "diffpf_tracker.pth")

    if prediction_method == "MultiPFTra":
        candidates = [
            os.path.join(
                project_root,
                "src",
                "mml_guidance",
                "mml_guidance",
                "mml_network",
                "models",
                "best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth",
            ),
            os.path.join(
                project_root,
                "best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth",
            ),
        ]

        for path in candidates:
            if os.path.exists(path):
                return path

        # Return the first expected path even if missing so the error message
        # points to the most likely location.
        return candidates[0]

    # MultiPFVel / velocity baseline does not need a checkpoint.
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Trajectory fan helper
# ─────────────────────────────────────────────────────────────────────────────

def _normalise_weights(weights: np.ndarray) -> np.ndarray:
    """
    Robust weight normalisation.

    If weights are invalid or collapse to zero, fall back to uniform weights.
    """
    weights = np.asarray(weights, dtype=np.float64)

    if weights.ndim != 1 or len(weights) == 0:
        return weights

    if not np.all(np.isfinite(weights)) or weights.sum() <= 1e-12:
        return np.ones_like(weights, dtype=np.float64) / len(weights)

    return weights / weights.sum()


def _model_predict_numpy(model, X: np.ndarray) -> np.ndarray:
    """
    Call model.predict(X) and always return a numpy float32 array.

    Works for CFMShim and ScratchTransformer-style wrappers.
    """
    y = model.predict(X.astype(np.float32))

    if isinstance(y, torch.Tensor):
        y = y.detach().cpu().numpy()

    y = np.asarray(y, dtype=np.float32)

    if y.ndim != 2 or y.shape[1] < 2:
        raise ValueError(
            f"Motion model predict() returned invalid shape {y.shape}; "
            "expected (N, 2)."
        )

    return y[:, :2]


def build_motion_model_trajectory_fan(pf,
                                      n_samples: int = 80,
                                      n_steps: int = 30,
                                      transformer_visual_noise: float = 0.03):
    """
    Build multi-step future trajectory samples from the current particle filter.

    This works by:
        1. sampling current particle histories according to PF weights,
        2. rolling the learned motion model forward repeatedly,
        3. returning future position trajectories in metres.

    Returns
    -------
    fan:
        Shape (n_samples, n_steps, 2), future positions in metres.

    weights:
        Shape (n_samples,), corresponding sampled particle weights.

    Notes
    -----
    For CFM, this produces stochastic samples because CFMShim.predict()
    internally calls propose(), which samples different flow initial noise.

    For Transformer, the base model is deterministic, so small optional
    visualization noise is added only to show local spread. This does NOT make
    the Transformer truly multi-modal.
    """
    if pf is None:
        return None, None

    if not hasattr(pf, "prediction_method"):
        return None, None

    if pf.prediction_method not in {
        "CFM", "CFM-AS", "NF", "Diffusion", "Transformer", "NN"
    }:
        return None, None

    if not hasattr(pf, "particles") or pf.particles is None:
        return None, None

    if not hasattr(pf, "motion_model") or pf.motion_model is None:
        return None, None

    if pf.particles.ndim != 3:
        return None, None

    # Particle history shape should be:
    #     (N_th, N_particles, Nx)
    n_hist, n_particles, nx = pf.particles.shape

    if n_hist < pf.N_th:
        return None, None

    if n_particles <= 0:
        return None, None

    n_samples = min(int(n_samples), int(n_particles))
    n_steps = int(n_steps)

    weights = _normalise_weights(pf.weights.copy())

    if len(weights) != n_particles:
        weights = np.ones(n_particles, dtype=np.float64) / n_particles

    # Sample particle histories according to current PF weights.
    idx = np.random.choice(
        n_particles,
        size=n_samples,
        replace=True,
        p=weights,
    )

    # Keep only [x, y] history.
    # Shape:
    #     hist = (N_th, n_samples, 2)
    hist = pf.particles[-pf.N_th:, idx, :2].copy().astype(np.float32)

    fan = np.zeros((n_samples, n_steps, 2), dtype=np.float32)

    if pf.prediction_method in {"CFM", "CFM-AS"} and hasattr(pf.motion_model, "_cfm"):
        # Fast path: propose_sequence encodes context once per physical step
        # instead of once per Euler sub-step, giving ~7x speedup on the fan.
        c_flat = np.transpose(hist, (1, 0, 2)).reshape(n_samples, pf.N_th * 2)
        fan = pf.motion_model._cfm.propose_sequence(
            c_flat,
            n_steps=n_steps,
            dt=pf.motion_model._cfm.dt,
        )
    else:
        dt = float(pf.dt_history[-1]) if hasattr(pf, "dt_history") else 0.033
        if not np.isfinite(dt) or dt <= 0:
            dt = 0.033

        for k in range(n_steps):
            X = np.transpose(hist, (1, 0, 2)).reshape(n_samples, pf.N_th * 2)
            v_pred = _model_predict_numpy(pf.motion_model, X.astype(np.float32))

            if pf.prediction_method == "Transformer" and transformer_visual_noise > 0:
                v_pred = v_pred + np.random.randn(*v_pred.shape).astype(np.float32) * transformer_visual_noise

            next_pos = hist[-1] + v_pred * dt
            fan[:, k, :] = next_pos
            hist = np.concatenate([hist[1:], next_pos[None, :, :]], axis=0)

    # Replace any inf/nan with 0 so pygame never receives non-finite coordinates.
    fan = np.nan_to_num(fan, nan=0.0, posinf=0.0, neginf=0.0)

    fan_weights = weights[idx]
    fan_weights = _normalise_weights(fan_weights).astype(np.float32)

    return fan, fan_weights


def build_primary_trajectory_fan(guidance,
                                 prediction_method: str,
                                 step: int,
                                 n_samples: int = 40,
                                 n_steps: int = 10):
    """
    Build the trajectory fan for visualization.

    Uses guidance.filter because that is the main ParticleFilter object
    passed into Guidance. This keeps the visualization simple and compatible
    with CFM / Transformer / NN learned motion models.
    """
    if prediction_method not in TRAJECTORY_FAN_METHODS:
        return None, None

    # Draw fan only on update steps to reduce computation.
    if step % 2 != 0:
        return None, None

    if not hasattr(guidance, "filter"):
        return None, None

    if prediction_method in MULTI_PF_METHODS and hasattr(guidance, "multi_filter"):
        tracks = guidance.multi_filter.get_confirmed_tracks()
        if not tracks:
            return None, None
        pf = tracks[0].pf
    else:
        pf = guidance.filter

    # Optional readiness check. The PF has a state_history buffer, but the
    # fan actually rolls out from particles, so we mainly use this to avoid
    # drawing garbage during the very first frames.
    try:
        filled = int(np.count_nonzero(pf.state_history) // pf.Nx)
        if filled < pf.N_th:
            return None, None
    except Exception:
        pass

    try:
        return build_motion_model_trajectory_fan(
            pf,
            n_samples=n_samples,
            n_steps=n_steps,
        )
    except Exception as exc:
        print(f"[trajectory_fan] skipped: {exc}")
        return None, None


# ─────────────────────────────────────────────────────────────────────────────
# GMM search helpers
# ─────────────────────────────────────────────────────────────────────────────

_ROAD_NODES = np.array(
    [
        [-1.5,  1.0],
        [ 0.0,  1.0],
        [ 2.1,  1.0],
        [-1.5, -1.0],
        [ 0.0, -1.0],
        [ 0.3,  0.0],
        [ 1.7,  0.0],
        [ 2.1, -1.0],
    ],
    dtype=np.float32,
)


def build_gmm_means(history_manager: ObservationHistoryManager,
                    slot_id: int,
                    n_components: int = 3) -> np.ndarray:
    """
    Fit a GMM to observation history for one target slot.

    Returns
    -------
    means:
        Shape (k, 2), sorted by component weight, heaviest first.

    Falls back to road-node pseudo-observations when history is too thin.
    """
    try:
        from sklearn.mixture import GaussianMixture
    except ImportError:
        return _ROAD_NODES[:n_components]

    hist = history_manager.get_positions(slot_id)

    if len(hist) >= 5:
        positions = np.vstack([hist, _ROAD_NODES])
    else:
        positions = _ROAD_NODES.copy()

    k = min(n_components, len(positions))

    try:
        gmm = GaussianMixture(
            n_components=k,
            covariance_type="full",
            max_iter=50,
            n_init=1,
            random_state=42,
        )
        gmm.fit(positions)

        order = np.argsort(gmm.weights_)[::-1]
        return gmm.means_[order].astype(np.float32)

    except Exception:
        return _ROAD_NODES[:k]


def pick_search_goal(gmm_means: np.ndarray,
                     agent_pos: np.ndarray,
                     occlusions) -> np.ndarray:
    """
    Choose the highest-weighted GMM mean that is not inside an occlusion.

    If all means are occluded, return the one nearest to the agent. The agent
    will at least move toward the occlusion boundary, where the target may
    become observable again.
    """
    for mean in gmm_means:
        if not occlusions.in_occlusion(mean):
            return mean.copy()

    dists = np.linalg.norm(gmm_means - agent_pos, axis=1)
    return gmm_means[np.argmin(dists)].copy()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def build_parser():
    """Shared CLI for the Pygame runner and optional visualization clients."""
    parser = argparse.ArgumentParser(description="Run MML tracking simulation")

    parser.add_argument(
        "--guidance_mode",
        type=str,
        default="MultiPFInfo",
        choices=[
            "MultiKFInfo",
            "MultiPFInfo",
            "MultiPFInfoPPO",
            "MultiPFInfoPPO_LSTM",
            "Lawnmower",
            "Predefined",
        ],
    )

    parser.add_argument(
        "--prediction_method",
        type=str,
        default="MultiPFTra",
        choices=[
            "MultiPFVel",
            "MultiPFTra",
            "MultiKF",
            "CFM",
            "PF+CFM",
            "PF+CFM-AS",
            "PF+NF",
            "PF+Diffusion",
            "DiffPF",
        ],
    )

    parser.add_argument("--run_number", type=int, default=0)

    parser.add_argument(
        "--num_steps",
        type=int,
        default=None,
        help="Override config.yaml number_sim_steps.",
    )

    parser.add_argument(
        "--model_path",
        type=str,
        default=None,
        help="Optional explicit checkpoint path for the selected learned filter.",
    )

    parser.add_argument(
        "--ppo_model_path",
        type=str,
        default=None,
        help="Optional PPO / recurrent PPO model path.",
    )

    parser.add_argument(
        "--fan_samples",
        type=int,
        default=40,
        help="Number of sampled future trajectories to draw.",
    )

    parser.add_argument(
        "--fan_steps",
        type=int,
        default=10,
        help="Number of future rollout steps per trajectory fan.",
    )

    parser.add_argument(
        "--no_fan",
        action="store_true",
        help="Disable trajectory fan rendering (faster, especially for CFM).",
    )

    parser.add_argument(
        "--recovery_metric",
        action="store_true",
        help="Enable occlusion recovery rate tracking (modal-side + probability score).",
    )

    parser.add_argument(
        "--benchmark_metrics",
        action="store_true",
        help=(
            "Save per-run RMSE, visibility-split RMSE, threshold recovery, "
            "and tracking-update runtime for benchmark aggregation."
        ),
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Deterministic run seed. Defaults to 1000 + run_number.",
    )

    parser.add_argument(
        "--headless",
        action="store_true",
        help="Disable display updates and scene drawing for batch benchmarks.",
    )

    parser.add_argument(
        "--output_dir",
        type=str,
        default="tracking_results",
        help="Directory for per-step, recovery, and benchmark CSV files.",
    )

    parser.add_argument(
        "--initial_target_mode",
        choices=["visible", "environment"],
        default="visible",
        help=(
            "Initial target placement. 'visible' deterministically places every "
            "target inside the initial FOV and outside occlusions; 'environment' "
            "preserves the legacy config/random placement."
        ),
    )

    return parser


def run_simulation(args, frame_callback=None):
    """Run the original MML loop; an optional synchronous callback records frames.

    Callback arrays/objects are borrowed and must not be mutated. Copy any data
    retained for later plotting. Frames describe the current state immediately
    before its action is applied; estimates update every two physics steps.
    """

    with ExitStack() as cleanup:
        return _run_simulation(args, frame_callback, cleanup)


def _run_simulation(args, frame_callback, cleanup):
    run_seed = args.seed if args.seed is not None else 1000 + args.run_number
    random.seed(run_seed)
    np.random.seed(run_seed)
    torch.manual_seed(run_seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(run_seed)

    config_params = load_config("config.yaml")

    number_targets = int(config_params["number_targets"])

    number_sim_steps = (
        int(args.num_steps)
        if args.num_steps is not None
        else int(config_params["number_sim_steps"])
    )

    dt = float(config_params["dt"])

    prediction_method = args.prediction_method
    guidance_mode = args.guidance_mode

    model_path = resolve_model_path(
        project_root=parent_dir,
        prediction_method=prediction_method,
        user_model_path=args.model_path,
    )

    ppo_model_path = (
        args.ppo_model_path
        if args.ppo_model_path is not None
        else os.path.join(
            parent_dir,
            "models_recurrent",
            "recurrent_ppo_ospa_3850000_steps.zip",
        )
    )

    print(f"\n{'=' * 60}")
    print(f"Run #{args.run_number + 1}")
    print(f"Guidance Mode: {guidance_mode}")
    print(f"Prediction Method: {prediction_method}")
    print(f"Simulation steps: {number_sim_steps}")
    print(f"dt: {dt}")
    print(f"Seed: {run_seed}")
    print(f"Headless: {args.headless}")
    print(f"Initial target mode: {args.initial_target_mode}")
    print(f"Model path: {model_path}")
    print(f"Output directory: {args.output_dir}")
    print(f"{'=' * 60}\n")

    occlusion_centers = [1.8, 0.0, 1.2, 0.8]
    occlusion_widths = [1.0, 1.0]

    N = 250
    drone_height = 1.5

    env = PygameEnvironment(seed=run_seed, render_enabled=not args.headless)
    cleanup.callback(env.close)
    state, _ = env.reset()

    eta_ = state[0, :]
    z_ = state[1:, :]

    if args.initial_target_mode == "visible":
        # Guidance uses a 45-degree camera half-angle, so tan(45 deg) * height
        # gives the exact square FOV dimensions used by Guidance.construct_FOV().
        initial_fov_dims = np.tan(np.deg2rad([45.0, 45.0])) * drone_height
        initialization_rng = np.random.default_rng(
            np.random.SeedSequence([int(run_seed) & 0xFFFFFFFF, 0x4954464F])
        )
        initial_target_positions = sample_visible_initial_target_positions(
            agent_position=eta_[:2],
            fov_dims=initial_fov_dims,
            number_targets=number_targets,
            occlusion_centers=occlusion_centers,
            occlusion_widths=occlusion_widths,
            rng=initialization_rng,
        )
        state = env.set_target_positions_meters(initial_target_positions)
        eta_ = state[0, :]
        z_ = state[1:, :]
    else:
        initial_target_positions = z_[:, :2].copy()

    print("Initial target positions [m]:")
    for target_id, position in enumerate(initial_target_positions):
        print(f"  Target {target_id}: ({position[0]:.3f}, {position[1]:.3f})")

    filter_ = ParticleFilter(
        N,
        prediction_method,
        drone_height=drone_height,
        initial_time=0.0,
        model_path=model_path,
        initial_detection=z_[0, :2],
    )

    guidance = Guidance(
        guidance_mode,
        prediction_method,
        occlusion_centers,
        occlusion_widths,
        drone_height=drone_height,
        filter=filter_,
        initial_time=0.0,
        model_path=model_path,
        ppo_model_path=ppo_model_path,
        measurement_seed=500000 + run_seed,
    )

    guidance.update_agent_position(eta_[:2])
    initial_target_visibility = np.array(
        [
            guidance.is_in_FOV(position, guidance.FOV)
            and not guidance.occlusions.in_occlusion(position)
            for position in initial_target_positions
        ],
        dtype=bool,
    )
    if args.initial_target_mode == "visible" and not initial_target_visibility.all():
        raise RuntimeError(
            "Visible initialization failed the Guidance FOV/occlusion check: "
            f"{initial_target_visibility.tolist()}"
        )
    print(f"Initial target visibility: {initial_target_visibility.tolist()}")

    uses_transformer_policy = False
    max_targets = 10

    if guidance.ppo_model is not None:
        try:
            policy = guidance.ppo_model.policy
            if (
                hasattr(policy, "features_extractor")
                and policy.features_extractor.__class__.__name__ == "AttentionFeatureExtractor"
            ):
                uses_transformer_policy = True
                print("✓ Detected Transformer/Attention policy — track ALL targets")
            else:
                print("✓ Detected standard MLP policy — track NEAREST target")
        except Exception as exc:
            print(f"Warning: Could not detect policy type: {exc}")

    print(
        f"Policy type: "
        f"{'Transformer (all targets)' if uses_transformer_policy else 'Standard (nearest)'}"
    )
    print("=" * 60)

    # ── GMM search module init ────────────────────────────────────────────────
    search_history = ObservationHistoryManager(
        num_targets=number_targets,
        max_size=1000,
        save_to_file=True,
        save_path="obs_history.pkl",
    )
    print(f"GMM search: loaded {search_history.total_count()} historical observations")

    _gmm_cache = [None] * number_targets
    _was_visible = [False] * number_targets
    _search_goal = None
    _search_slot = 0

    fov_size = guidance.FOV_dims[0]
    env.render_init(
        occ_centers=occlusion_centers,
        occ_widths=occlusion_widths,
        fov_size=fov_size,
    )

    metrics_tracker = MetricsTracker()
    benchmark_tracker = (
        FilterBenchmarkTracker(recovery_threshold=0.3)
        if args.benchmark_metrics
        else None
    )

    recovery_tracker = (
        OcclusionRecoveryTracker(model_name=prediction_method)
        if args.recovery_metric
        else None
    )

    # Pre-compute per-occlusion zone centre y-coordinates for fast lookup.
    # occlusion_centers is [x0, y0, x1, y1, x2, y2, ...] (flattened pairs).
    _occ_zone_centers = [
        (occlusion_centers[ii * 2], occlusion_centers[ii * 2 + 1])
        for ii in range(len(occlusion_widths))
    ]

    def _nearest_occ_center_y(pos: np.ndarray) -> float:
        """Return the y-coordinate of the occlusion zone closest to pos."""
        best_dist = float("inf")
        best_y = 0.0
        for cx, cy in _occ_zone_centers:
            d = (pos[0] - cx) ** 2 + (pos[1] - cy) ** 2
            if d < best_dist:
                best_dist = d
                best_y = cy
        return best_y

    lstm_states = None
    episode_start = np.array([True])
    lstm_reset_done = False
    steps_since_last_track = 0

    step = 0

    # Values reused on odd frames.
    tau = np.zeros(2)
    target_detections = []
    tracked_positions = []
    tracked_covs = np.empty((0, 2, 2))
    future_particles = []
    particles_tracks = []

    while step < number_sim_steps:
        t = step * dt
        eta_ = state[0, :]
        z_ = state[1:, :]

        # The original code updates guidance/filter every 2 pygame frames.
        if step == 0 or step % 2 == 0:
            guidance.update_agent_position(eta_[:2])

            target_detections = []
            visibility_mask = []
            tracked_positions = []
            tracked_covs = np.empty((0, 2, 2))
            future_particles = []

            # ── Update target measurements ───────────────────────────────────
            for i in range(number_targets):
                guidance.update_target_pose(
                    z_[i, :2],
                    orientation=[z_[i, 2]],
                    linear_vel=z_[i, 3:5],
                    angular_vel=[z_[i, 5]],
                )

                measurement_available = bool(guidance.filter.is_update)
                visibility_mask.append(measurement_available)
                if measurement_available:
                    target_detections.append(z_[i, :2])

            if (
                step == 0
                and args.initial_target_mode == "visible"
                and len(target_detections) != number_targets
            ):
                raise RuntimeError(
                    "Not every target produced a detection at step zero: "
                    f"{len(target_detections)}/{number_targets}."
                )

            filter_t0 = time.perf_counter()
            guidance.guidance_filter_loop(t, detections=target_detections)
            filter_runtime_ms = 1000.0 * (time.perf_counter() - filter_t0)

            # ── Tracking state for metrics / visualization ───────────────────
            if prediction_method in MULTI_TRACKER_METHODS:
                tracked_states = guidance.multi_filter.get_track_states()

                if len(tracked_states) > 0:
                    tracked_positions = [ts[:2] for ts in tracked_states]
                    tracked_covs = guidance.multi_filter.get_track_covariances()
            else:
                tracked_positions = guidance.filter.weighted_mean[:2].reshape(1, 2)
                tracked_covs = guidance.filter.var.reshape(
                    1,
                    *guidance.filter.var.shape,
                )

            true_positions = z_[:, :2]

            if len(tracked_positions) > 0:
                tracked_positions = np.asarray(tracked_positions, dtype=np.float32)

            metrics_tracker.append_metrics(
                true_positions,
                tracked_positions,
                tracked_covs,
                step=step,
                time=t,
            )

            if benchmark_tracker is not None:
                benchmark_tracker.append(
                    true_positions=true_positions,
                    tracked_positions=tracked_positions,
                    visible=visibility_mask,
                    runtime_ms=filter_runtime_ms,
                )

            if step % 200 == 0:
                metrics_tracker.print_step_metrics()

            # ── Per-target visibility check + history recording ──────────────
            for i in range(number_targets):
                target_pos = z_[i, :2]
                in_fov = guidance.is_in_FOV(target_pos, guidance.FOV)
                in_occ = guidance.occlusions.in_occlusion(target_pos)
                visible = bool(in_fov and not in_occ)

                if visible:
                    search_history.add(
                        target_id=i,
                        position=target_pos,
                        velocity=z_[i, 3:5],
                        timestamp=t,
                        episode=0,
                    )

                    # LOST → ACTIVE: score the recovery event then clear cache.
                    if not _was_visible[i]:
                        if recovery_tracker is not None:
                            event = recovery_tracker.record_exit(
                                target_id=i,
                                step=step,
                                exit_pos=target_pos,
                            )
                            if event is not None:
                                side_str = (
                                    f"modal={'✓' if event['modal_correct'] else '✗'}  "
                                    f"prob={event['prob_correct']:.2f}"
                                    if event["prob_correct"] is not None
                                    else f"modal={'✓' if event['modal_correct'] else '✗'}"
                                )
                                print(
                                    f"[step {step}] Target {i} FOUND — "
                                    f"predicted={event['predicted_side']}  "
                                    f"actual={event['actual_side']}  {side_str}"
                                )

                        _gmm_cache[i] = None
                        _search_goal = None

                    _was_visible[i] = True

                else:
                    # ACTIVE → LOST: build fan prediction then record entry.
                    if _was_visible[i]:
                        _gmm_cache[i] = build_gmm_means(search_history, i)
                        _search_goal = None

                        print(
                            f"[step {step}] Target {i} LOST — GMM cache built "
                            f"({search_history.count(i)} obs)"
                        )

                        if recovery_tracker is not None:
                            # Build the fan unless --no_fan suppresses it.
                            if args.no_fan:
                                entry_fan, entry_weights = None, None
                            else:
                                entry_fan, entry_weights = build_primary_trajectory_fan(
                                    guidance=guidance,
                                    prediction_method=prediction_method,
                                    step=step,
                                    n_samples=args.fan_samples,
                                    n_steps=args.fan_steps,
                                )
                            recovery_tracker.record_entry(
                                target_id=i,
                                step=step,
                                occ_center_y=_nearest_occ_center_y(target_pos),
                                fan=entry_fan,
                                fan_weights=entry_weights,
                                last_known_pos=target_pos.copy(),
                                last_known_vel=z_[i, 3:5].copy(),
                            )

                    _was_visible[i] = False

            # ── Guidance action selection ────────────────────────────────────
            if guidance_mode == "MultiPFInfoPPO_LSTM":
                tracked_states_action = (
                    guidance.multi_filter.get_track_states()
                    if prediction_method in MULTI_PF_METHODS
                    else [guidance.filter.weighted_mean]
                )

                uses_attention = (
                    hasattr(guidance.ppo_model.policy, "features_extractor")
                    and guidance.ppo_model.policy.features_extractor.__class__.__name__
                    == "AttentionFeatureExtractor"
                )

                if uses_attention:
                    tau, lstm_states = guidance.get_ppo_action_all_tracks(
                        eta_,
                        tracked_states_action,
                        max_targets=max_targets,
                        lstm_states=lstm_states,
                        episode_start=episode_start,
                    )
                else:
                    tau, lstm_states = guidance.get_ppo_action_lstm(
                        eta_,
                        tracked_states_action,
                        lstm_states=lstm_states,
                        episode_start=episode_start,
                    )

                episode_start = np.array([False])

                if tau is None:
                    # LOST TRACK: GMM-guided search.
                    steps_since_last_track += 1

                    best_means = None

                    for i in range(number_targets):
                        if _gmm_cache[i] is not None:
                            best_means = _gmm_cache[i]
                            _search_slot = i
                            break

                    if best_means is None:
                        best_means = _ROAD_NODES[:3]

                    if _search_goal is None:
                        _search_goal = pick_search_goal(
                            gmm_means=best_means,
                            agent_pos=eta_[:2],
                            occlusions=guidance.occlusions,
                        )
                        print(f"[step {step}] New search goal: {_search_goal}")

                    if np.linalg.norm(eta_[:2] - _search_goal) < 0.3:
                        n_means = len(best_means)
                        current_mean_idx = 0

                        for k, mean in enumerate(best_means):
                            if np.linalg.norm(mean - _search_goal) < 0.1:
                                current_mean_idx = k
                                break

                        next_mean = best_means[(current_mean_idx + 1) % n_means]

                        if not guidance.occlusions.in_occlusion(next_mean):
                            _search_goal = next_mean.copy()
                        else:
                            _search_goal = None

                    if _search_goal is None:
                        _search_goal = pick_search_goal(
                            gmm_means=best_means,
                            agent_pos=eta_[:2],
                            occlusions=guidance.occlusions,
                        )

                    tau = env.goal_position_to_velocity(_search_goal, eta_[:2])

                    if steps_since_last_track > 100 and not lstm_reset_done:
                        lstm_states = None
                        episode_start = np.array([True])
                        lstm_reset_done = True
                        print(f"[step {step}] LSTM reset (lost > 100 steps)")

                else:
                    steps_since_last_track = 0
                    lstm_reset_done = False
                    _search_goal = None

            elif guidance_mode == "MultiPFInfoPPO":
                tracked_states_action = (
                    guidance.multi_filter.get_track_states()
                    if prediction_method in MULTI_PF_METHODS
                    else [guidance.filter.weighted_mean]
                )

                if uses_transformer_policy:
                    tau = guidance.get_ppo_action_all_tracks(
                        eta_,
                        tracked_states_action,
                        max_targets=max_targets,
                    )
                else:
                    tau = guidance.get_ppo_action_nearest_track(
                        eta_,
                        tracked_states_action,
                    )

                if tau is None:
                    # LOST TRACK: GMM-guided search.
                    steps_since_last_track += 1

                    best_means = None

                    for i in range(number_targets):
                        if _gmm_cache[i] is not None:
                            best_means = _gmm_cache[i]
                            break

                    if best_means is None:
                        best_means = _ROAD_NODES[:3]

                    if _search_goal is None:
                        _search_goal = pick_search_goal(
                            best_means,
                            eta_[:2],
                            guidance.occlusions,
                        )

                    if np.linalg.norm(eta_[:2] - _search_goal) < 0.3:
                        _search_goal = None

                    if _search_goal is None:
                        _search_goal = pick_search_goal(
                            best_means,
                            eta_[:2],
                            guidance.occlusions,
                        )

                    tau = env.goal_position_to_velocity(_search_goal, eta_[:2])

                else:
                    steps_since_last_track = 0
                    _search_goal = None

            else:
                guidance.update_goal_position(dt=dt)
                goal_position = guidance.goal_position
                tau = env.goal_position_to_velocity(goal_position[:2], eta_[:2])

        # ── Visualization data ────────────────────────────────────────────────
        if prediction_method in MULTI_PF_METHODS:
            particles_tracks = guidance.multi_filter.get_track_particles()

            future_particles = (
                [track.pf.particles for track in guidance.future_tracks]
                if hasattr(guidance, "future_tracks") and guidance.future_tracks
                else []
            )
        elif prediction_method == "MultiKF":
            particles_tracks, future_particles = [], []
        else:
            particles_tracks = guidance.filter.particles.reshape(
                1,
                *guidance.filter.particles.shape,
            )
            future_particles = []

        # ── Learned motion model trajectory fan ───────────────────────────────
        if args.no_fan:
            trajectory_fan, trajectory_weights = None, None
        else:
            trajectory_fan, trajectory_weights = build_primary_trajectory_fan(
                guidance=guidance,
                prediction_method=prediction_method,
                step=step,
                n_samples=args.fan_samples,
                n_steps=args.fan_steps,
            )

        if frame_callback is not None:
            frame_callback(
                step=step, t=t, state=state, action=tau,
                detections=target_detections, guidance=guidance, environment=env,
                filter_updated=(step % 2 == 0),
                goal=(_search_goal if _search_goal is not None else
                      guidance.goal_position if "PPO" not in guidance_mode else None),
                particles=particles_tracks, future_particles=future_particles,
                trajectory_fan=trajectory_fan, trajectory_weights=trajectory_weights,
                last_frame=(step == number_sim_steps - 1),
            )

        next_state, _ = env.step(
            tau,
            particle_tracks=particles_tracks,
            tracks=tracked_positions,
            detections=target_detections,
            goal_pos=eta_[:2],
            future_particles=future_particles,
            trajectory_fan=trajectory_fan,
            trajectory_weights=trajectory_weights,
        )

        state = next_state
        env.render()
        step += 1

    print("Closing sim")

    metrics_tracker.print_summary()
    run_prefix = (
        f"{prediction_method}_{guidance_mode}_"
        f"run{args.run_number:03d}_seed{run_seed}"
    )
    metrics_tracker.save_to_csv(
        prefix_name=run_prefix,
        directory=args.output_dir,
    )

    if benchmark_tracker is not None:
        benchmark_tracker.save_run_summary(
            directory=args.output_dir,
            tracker=prediction_method,
            run=args.run_number,
            seed=run_seed,
            n_steps=number_sim_steps,
            initial_target_mode=args.initial_target_mode,
            initial_target_positions=initial_target_positions,
        )

    if recovery_tracker is not None:
        # Discard any events that never resolved (target still occluded at run end).
        for i in range(number_targets):
            recovery_tracker.discard_pending(i)
        recovery_tracker.print_summary()
        recovery_tracker.save_to_csv(
            prefix_name=run_prefix,
            directory=args.output_dir,
        )

    return {"state": state.copy(), "steps": step, "dt": dt,
            "run_prefix": run_prefix, "output_dir": args.output_dir}


def main(argv=None):
    return run_simulation(build_parser().parse_args(argv))


if __name__ == "__main__":
    main()
