﻿# training/__init__.py
import sys
import os

# Add parent directory to path when training package is imported
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
