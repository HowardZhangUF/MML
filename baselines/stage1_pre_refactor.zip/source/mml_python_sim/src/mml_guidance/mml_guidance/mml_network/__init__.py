"""
mml_network — CFM Motion Model for Particle Filters
====================================================
    velocity_network  : v_theta(x_tau, tau, context) -> velocity
    cfm_motion_model  : CFMMotionModel (train + propose) + CFMShim + load_cfm_model
    particle_filter   : CFMParticleFilter (notebook-only PF)
    utils             : data loading, history buffers
"""
from .velocity_network  import ContextEncoder, VelocityHead, CFMVelocityNetwork
from .cfm_motion_model  import CFMMotionModel, CFMShim, load_cfm_model
from .particle_filter   import CFMParticleFilter, ParticleCloud
from .utils             import (load_training_csv, make_history_dataset,
                                 chronological_split, HistoryBuffer)

__all__ = [
    "ContextEncoder", "VelocityHead", "CFMVelocityNetwork",
    "CFMMotionModel", "CFMShim", "load_cfm_model",
    "CFMParticleFilter", "ParticleCloud",
    "load_training_csv", "make_history_dataset",
    "chronological_split", "HistoryBuffer",
]
