# Baseline Provenance: DiffPF and NF-DPF

This document records **exactly which upstream files each baseline was reimplemented from**,
what was ported faithfully, what was adapted to our task, and what was deliberately omitted.
It exists so that the claims in the paper about the baselines are defensible, and so that a
reviewer asking *"is this really their method or is it a strawman?"* has a line-by-line answer.

It also gives the **network-structure comparison** between the three generative mechanisms we
benchmark: our CFM motion model, DiffPF, and NF-DPF.

---

## 0. Upstream sources

| Baseline | Paper | Repository | Commit checked out |
|---|---|---|---|
| **DiffPF** | *DiffPF: Differentiable Particle Filtering with Generative Sampling via Conditional Diffusion Models* | `github.com/ZiyuNUS/DiffPF` | `493081c` |
| **NF-DPF** | *Normalizing Flow-based Differentiable Particle Filters*, Chen & Li 2024, [arXiv:2403.01499](https://arxiv.org/abs/2403.01499) | `github.com/xiongjiechen/Normalizing-Flows-DPFs` | `1cfcf8e` |

The NF-DPF repo notes that its conditional-flow proposal/dynamic component (`RealNVP_cond`) is the
**CNF-DPF** of [arXiv:2107.00488](https://arxiv.org/abs/2107.00488), *Differentiable Particle Filters
through Conditional Normalizing Flow* — that is the component we port, so **both papers should be
cited** for the NF baseline.

Both upstream repos target a different sensing modality than we do (DiffPF: 24×24 RGB images for
global localization in a maze; NF-DPF: image observations of a moving disk). Neither can be run
unmodified on our task, so both were reimplemented against our data. The point of this document is
to make the reimplementation auditable.

---

## 1. DiffPF → `mml_network/diffpf_tracker.py`

### 1.1 Files consulted

| Upstream file | What it defines | What we took from it |
|---|---|---|
| `ex2-global-localization/train/train.py` (L85–121) | Model assembly and the DDPM scheduler | The whole architecture spec: encoder + `ConditionalUnet1D` noise net + `state_extractor`, and `DDPMScheduler(num_train_timesteps=10, beta_schedule='squaredcos_cap_v2', clip_sample=True, prediction_type='epsilon')` |
| `DiffPF_train/models/diffpf/diffpf.py` (L3–18) | The `DiffPF` module — a dispatcher over `vision_encoder` / `noise_pred_net` / `state_extractor` | The three-part decomposition, mirrored by our `DiffPFNetwork` |
| `DiffPF_train/models/diffpf/CNN.py` (L5–61, L123–139) | `SensorModel` / `build_encoder_maze` — CNN observation encoders | Confirmed the observation encoder is *only* a feature extractor (→128-d), so it is the one component legitimately swappable per modality |
| `DiffPF_train/training/train_step2.py` (L50–77) | `model_output()` — the ancestral sampling loop | **Ported.** Our `DiffPFTracker._sample_posterior()` is the same ε-parameterized reverse loop |
| `DiffPF_train/training/train_step2.py` (L29–48) | `normalize_data` / `unnormalize_data` — min–max to [−1, 1] | **Ported.** Our `_normalize` / `_unnormalize` |
| `DiffPF_train/training/train_step2.py` (L79–113) | `predict_next_pose()` — the prediction step (odometry displacement + Gaussian noise) | The *structure* (dumb predict + noise, all learned capacity in the posterior sampler), not the odometry itself |
| `DiffPF_train/training/train_step2.py` (L115–206) | `train_diffpf()` — the training loop | **Ported.** The key mechanism: `repeat_interleave(particle_number)` replicates each example 20× and each copy draws independent diffusion noise — *the 20 posterior particles are 20 independent samples of one conditional DDPM*. Loss = MSE on ε |
| `DiffPF_train/training/train_step1.py` (L407–420) | Stage-1 training | Read to understand the two-stage recipe (see §1.3) |
| `DiffPF_train/training/train_eval_loop.py` (L43–44) | `dynamic_import(f"...train_{training_setting}")` | Confirms the shipped config runs **step1** |
| `train/config/nav01_step1.yaml` | Hyperparameters | **Ported:** `num_diffusion_iters: 10`, `particle_number: 20`. Also read: `encoding_size: 128`, `prediction_size: 3`, `lr: 1e-4`, cosine schedule + warmup |

### 1.2 Ported vs. adapted

**Ported faithfully (the paper's actual mechanism):**

1. **The core claim of DiffPF** — a conditional DDPM *samples the posterior particle set directly*,
   replacing the classical likelihood-weighting + resampling update. There is no importance weight
   anywhere in our `DiffPFTracker.step()`, exactly as in their filter.
2. Particles = independent draws from one conditional DDPM given a shared condition.
3. ε-prediction, cosine (`squaredcos_cap_v2`) β-schedule, `T = 10` denoising steps.
4. Conditioning = **concat(encoded observation, flattened predicted particle set)**, with 20
   conditioning particles.
5. Min–max normalization of states to [−1, 1] before diffusion.
6. A deliberately non-learned prediction step; all learned capacity is in the posterior sampler.

**Adapted (must be disclosed in the paper):**

| Their design | Ours | Why |
|---|---|---|
| `vision_encoder`: CNN on 24×24 RGB | `meas_encoder`: 2-layer MLP on `(x, y, visible_flag)`, with `(0,0,0)` as a null token under occlusion | Our observation is a noisy 2-D position, or *nothing* during occlusion. A CNN has nothing to encode. This is the modality swap the architecture explicitly allows |
| `noise_pred_net`: `ConditionalUnet1D`, diffusing a 4-step horizon of SE(2) poses (`pred_horizon=4, action_dim=3`) | MLP noise head diffusing a single 2-D position | Our filter estimates one 2-D position per step; a temporal 1-D U-Net over a 4-step pose chunk has no counterpart. **This makes our DiffPF smaller than theirs** — see §1.4 |
| `predict_next_pose()`: propagates particles by the robot's own **odometry** (ground-truth inter-frame displacement, body-frame) | Constant-velocity propagation from the filter's own past estimates + noise | Our target is *uncontrolled and not the ego-robot* — no odometry exists. CV is the faithful analogue of "cheap non-learned predict". **This is the single most important adaptation:** DiffPF's predict step gets a ground-truth-derived motion cue that simply does not exist in target tracking |
| `state_extractor.forward()` = `torch.cat` (the fusion MLP defined in `train.py` L100–104 is **dead code** — `forward` never calls it) | `fusion`: `Linear(2·enc_dim → cond_dim) + ReLU` | We use the fusion MLP their code defines but never invokes. This is a (small) *upgrade* over their released code, not a handicap |

**Omitted (and why it does not weaken the baseline):**

- **EMA of the weights for sampling** (`EMAModel`). Omitted for simplicity; would if anything
  slightly improve DiffPF. Worth adding if a reviewer pushes.
- **`clip_sample=True`**: `diffusers` clips the predicted $\hat{x}_0$ at *every* reverse step; we clip
  only the final sample to the environment bounds. Same intent (keep samples in-domain), applied once.
- The `particles.pt` **disk round-trip** and the `if i % 99 == 0` periodic reset. These are artifacts
  of their batched training harness, not part of the method; we keep filter state in memory.

### 1.3 A finding worth knowing about their released code

The repo ships `config/nav01_step1.yaml` with `training_setting: "step1"`, which dynamically imports
`train_step1.py`. That file **zeroes the particle conditioning vector** before building the condition:

```python
# DiffPF_train/training/train_step1.py:413-416
predict_particles = predict_next_pose(dataloader, ground_truth, last_pos, particles, ...)
predict_particles.zero_()                                   # <-- particle conditioning discarded
obs_cond = model("state_extractor", obs_img=image_features, state_vector=predict_particles)
```

So the *default, out-of-the-box* training run learns an **observation-conditioned-only** posterior
sampler; the recursive, particle-conditioned filter is the step-2 stage (`train_step2.py`, which does
not call `.zero_()`). **We implement step 2** (particle conditioning enabled), i.e. the stronger and
more faithful-to-the-paper version. Our training is teacher-forced rather than run through their
two-stage schedule.

### 1.4 Fairness caveat

Our DiffPF has **37,154 parameters** vs. 57–68k for the motion-model baselines, because their
`ConditionalUnet1D` (`down_dims: [64, 128, 256]`, hundreds of thousands of parameters) is overkill for
diffusing a single 2-D point and was replaced by an MLP head. If DiffPF underperforms, capacity is a
possible confound and should be acknowledged — or removed by scaling the noise head up.

---

## 2. NF-DPF → `velocity_network.py` (`NFVelocityNetwork`) + `nf_motion_model.py`

### 2.1 Files consulted

| Upstream file | What it defines | What we took from it |
|---|---|---|
| `nf/flows.py` (L181–239) | **`RealNVP_cond`** — the conditional coupling block: two affine coupling sub-layers per block (`t1/s1` on lower→upper, then `t2/s2` on upper→lower), each s/t net conditioned by concatenating the context | **Ported verbatim** as `_CondRealNVPBlock` (`velocity_network.py:476-531`), including the forward/inverse algebra and the log-det accumulation |
| `nf/flows.py` (L101–114) | **`FCNN`** — the s/t base network: `Linear → Tanh → Linear → Tanh → Linear` | **Ported verbatim** as `_FlowFCNN` (two hidden Tanh layers) |
| `nf/flows.py` (L191–213) | `zero_initialization(var)` — near-identity init | **Ported** (normal weights, zero bias); see the init-variance deviation below |
| `nf/models.py` (L37–66) | **`NormalizingFlowModel_cond`** — `forward` (x→z, accumulate log-det, add prior log-prob) and `inverse` (z→x, flows reversed) | **Ported.** Our `NFVelocityNetwork.log_prob()` = their `forward` + standard-normal prior; `NFVelocityNetwork.sample()` = their `inverse` from `z ~ N(0,I)`. **The direction convention is theirs**: density via `forward`, sampling via `inverse` |
| `model/models.py` (L161–172) | `build_conditional_nf(n_sequence, hidden_size, state_dim, init_var=0.01)` | The construction: a stack of `n_sequence` `RealNVP_cond` blocks over a standard-normal prior |
| `model/models.py` (L334–356) | `normalising_flow_propose()` — the flow used as the **proposal**: `cond_model.inverse(particles, [obs_encoding, particle_mean, particle_std])` | The role the flow plays in the filter (a learned proposal/dynamic model producing particles + Jacobian) |
| `model/models.py` (L305–332) | `nf_dynamic_model()` — the flow used as the **dynamic model** | Same, for the dynamics-only variant |
| `DPFs.py` (L46, L71–72) | `self.n_sequence = 2`; `nf_dyn` conditioned on `2·state_dim`, `cond_model` on `2·state_dim + hidden_size` | **Ported:** `n_flows = 2`. Their conditioning content differs — see below |
| `DPFs.py` (L160–192) | The filter loop: ESS-triggered resampling at `ESS < 0.5·num_particles`, then propose, then reweight | **Ported:** our `BootstrapPFTracker` resamples on `n_eff < N/2`, the same criterion |
| `arguments.py` | `--hiddensize 32`, `--num-particles 100`, `--lr 1e-4`, `--n_sequence 2` | Reference values |

### 2.2 Ported vs. adapted

**Ported faithfully:**

1. The **`RealNVP_cond` block algebra** — coupling structure, conditioning-by-concatenation, log-det
   sums, and the exact `forward`/`inverse` pair. This is the substance of the CNF-DPF contribution.
2. **`n_flows = 2`**, matching `DPF.n_sequence = 2`.
3. The **`FCNN`** s/t network shape (two hidden Tanh layers).
4. Near-identity initialization of the coupling nets.
5. **Exact-likelihood training** (`log p(y|c) = log N(f(y;c)) + log|det J_f|`) — the flow's signature
   property and the reason it is a distinct baseline from CFM/DDPM.
6. The ESS < N/2 resampling rule in the surrounding particle filter.

**Adapted:**

| Their design | Ours | Why |
|---|---|---|
| Conditioning vector = `[observation_encoding(32), particle_mean(2), particle_std(2)]` | Conditioning = our shared **transformer `ContextEncoder` embedding** (32-d) of the N_th=5-step measurement history | This is the **capacity-matched comparison**: every learned motion model (CFM, DDPM, GMM, NF) sees the *identical* context encoder, so the benchmark isolates the generative mechanism rather than the context representation. Their particle-mean/std conditioning is an alternative encoding of "where the particles are"; our history embedding is strictly richer for this task |
| `hidden_dim = 8` in the s/t nets (`RealNVP_cond` default) | `flow_hidden = 32` | Matches the hidden width of the CFM/DDPM/GMM heads, again for capacity parity |
| `init_var = 0.01` (as passed by `build_conditional_nf`) | `0.1` (the `zero_initialization` default) | Trained stably here; combined with scale clamping (below). A deviation, disclosed |
| No scale clamping | `S_CLAMP = 5.0` on the coupling log-scales | Guards `exp(s)` overflow. A numerical-stability addition, not a change of method |

**Omitted deliberately:**

- Their **learned measurement model** (`measurement_model_cnf` / `cos` / `NN` / `CGLOW`, `DPFs.py`
  L74–89) — these exist because their observations are *images* with no analytic likelihood. Our
  observation is a noisy position with a **known Gaussian likelihood**; learning a measurement model
  would be strictly worse and would not be what a practitioner would do.
- **Differentiable resampling** (`resamplers/resamplers.py`: OT / soft resampling) and **end-to-end
  training through the filter** (the pseudo-likelihood loss in `losses.py`). These enable gradient
  flow through resampling for *end-to-end* DPF training. We train the motion model on
  (history → velocity) pairs offline — the same protocol as CFM, so the comparison stays apples-to-apples.

> **Honest framing for the paper:** we port **the NF-DPF/CNF-DPF conditional-flow dynamic/proposal
> model** — the transferable component — and run it in a standard bootstrap PF. We do **not** claim to
> reproduce the full end-to-end differentiable NF-DPF training pipeline. If a reviewer wants the full
> system, the missing pieces are the differentiable resampler and the pseudo-likelihood loss.

---

## 3. Network structure comparison

All three learn a *conditional distribution*, but **at different levels of the filter** — this is the
single most important structural distinction and should be stated explicitly in the paper.

| | **CFM (ours)** | **NF (NF-DPF)** | **DiffPF** |
|---|---|---|---|
| **What it models** | $p(v_{k+1} \mid c_k)$ — next **velocity** | $p(v_{k+1} \mid c_k)$ — next **velocity** | $p(x_k \mid z_k, \{x^{(i)}_{k|k-1}\})$ — the **posterior position** |
| **Where it sits** | Motion model *inside* a bootstrap PF | Motion model *inside* a bootstrap PF | **Replaces** the PF's update + resample step |
| **PF weights / resampling?** | Yes (Gaussian likelihood, systematic resampling on ESS < N/2) | Yes (identical PF) | **None** — there is no importance weight anywhere |
| **Conditioning** | Shared `ContextEncoder` (32-d) | Shared `ContextEncoder` (32-d) | `fusion(meas_enc(x,y,vis) ‖ particle_enc(20 particles))` → 64-d |
| **Generative head** | `VelocityHead`: MLP(32+2+1 → 64 → 64 → 2), ReLU | 2 × `_CondRealNVPBlock`, each = 4 × `_FlowFCNN`(1+32 → 32 → 32 → 1), Tanh | `noise_head`: MLP(2+32+64 → 128 → 128 → 2), ReLU |
| **Latent → sample** | ODE: $x_0 = v_{\text{anchor}} + \sigma\epsilon$, Euler-integrate $v_\theta$ for **N_FE = 10** steps | **1 inverse pass**: $z\sim N(0,I)$, $y = f^{-1}(z; c)$ | Ancestral DDPM: $y_T \sim N(0,I)$, **T = 10** denoising steps |
| **Base / prior** | **Anchored**: $x_0 \sim N(v_{\text{anchor}}, 0.3^2 I)$, where $v_{\text{anchor}} = (p_k - p_{k-1})/\Delta t$ | Standard $N(0, I)$ (unanchored) | Standard $N(0, I)$ (unanchored) |
| **Training objective** | Flow-matching MSE: $\lVert v_\theta(x_\tau,\tau,c) - (x_1 - x_0) \rVert^2$ | **Exact NLL**: $-\log N(f(y;c)) - \log\lvert\det J_f\rvert$ | ε-MSE: $\lVert \epsilon_\theta(y_t,t,c) - \epsilon \rVert^2$ |
| **Exact likelihood?** | No (needs ODE trace) | **Yes** (its selling point) | No |
| **Network fn-evals / proposal** | 10 (ODE steps) | **1** | 10 (denoising steps) |
| **Parameters** | **57,490** (ctx 50,896 + head 6,594) | **68,312** (ctx 50,896 + flows 17,416) | **37,154** (no shared ctx encoder) |
| **Measured cost** | 8.5 ms / 500 particles | **7.1 ms** / 500 particles | 5.8 ms / filter step |

Shared across CFM / NF / GMM / Diffusion: the **identical** `ContextEncoder`
(transformer, `n_embed=32`, `n_head=8`, `n_layer=2`, `N_th=5`, causal mask, last-token readout,
50,896 params). DiffPF is the exception — it does not use a history encoder at all, because its
conditioning is *the current observation plus the current particle set*, which is what its method
prescribes.

### 3.1 The structural difference that drives the results

**The anchor.** CFM's base distribution is centred on the constant-velocity finite-difference estimate
$v_{\text{anchor}} = (p_k - p_{k-1})/\Delta t$. NF and DiffPF both start from a standard normal. During
a long occlusion, the CFM particles all receive proposals anchored to *their own* recent motion, so the
cloud translates as a **coherent flock**: diversity collapses, the filter drifts confidently in one
direction, and after reacquisition it takes ~7.5 steps to recover. The NF's unanchored, higher-spread
proposals keep particles scattered, so when the target reappears some particle is already near it and a
single resample snaps the estimate back (0-step recovery). This is a *mechanistic* explanation of the
filter-level numbers, and it is testable: **the anchoring ablation (CFM with a pure $N(0,I)$ base) is
the experiment that isolates it.**

> **Status (2026-07-17): confirmed and fixed.** Retraining with `anchor_sigma = 1.0` (checkpoint
> `cfm_motion_model_anchor1.0.pth`) recovered sample spread and eliminated the flock-drift failure
> (recovery 7.5 → ~0 steps). The occlusion-adaptive sigma schedule (§7) then closed the remaining
> occluded-RMSE gap to NF. The numbers earlier in this section describe the *original* σ=0.3 model.

**Weights vs. no weights.** DiffPF's flat error profile (visible 0.67 m, occluded 0.50 m — nearly the
*same*) is the signature of having no importance-weighting step: it cannot sharpen onto a good
measurement the way a PF can, but it also cannot diverge, because every step resamples the posterior
from scratch conditioned on the observation. PF+NF is the opposite (visible 0.02 m, occluded 0.72 m).

---

## 4. Where each file lives

| Ours | Role | Reimplemented from |
|---|---|---|
| `mml_network/velocity_network.py` | `ContextEncoder` (shared) + `VelocityHead` (CFM), `NoisePredictionHead` (DDPM), `GMMHead`, `_CondRealNVPBlock` / `_FlowFCNN` / `NFVelocityNetwork` | NF parts ← `Normalizing-Flows-DPFs/nf/flows.py`, `nf/models.py` |
| `mml_network/nf_motion_model.py` | NF motion model: exact-MLE training, `propose()`, `log_prob()` | ← `Normalizing-Flows-DPFs/model/models.py`, `DPFs.py` |
| `mml_network/train_nf.py` | Training script | our convention (mirrors `train_cfm.py`) |
| `mml_network/diffpf_tracker.py` | `DiffPFNetwork` + `DiffPFTracker` (full filter) | ← `DiffPF/.../models/diffpf/diffpf.py`, `training/train_step2.py`, `train.py`, `config/nav01_step1.yaml` |
| `mml_network/train_diffpf.py` | Teacher-forced dataset builder + training | ← `DiffPF/.../training/train_step2.py` (training recipe) |
| `mml_network/compare_motion_models.py` | 5-way motion-model benchmark (ConstVel / GMM / NF / CFM / Diffusion) | ours |
| `mml_network/benchmark_diffpf_vs_cfm.py` | 3-way filter-level benchmark (PF+CFM / PF+NF / DiffPF) | PF loop follows `DPFs.py` ESS rule |

Checkpoints: `models/{cfm,diffusion,gmm,nf}_motion_model.pth`, `models/diffpf_tracker.pth`.

---

## 5. Suggested disclosure paragraph for the paper

> **Baselines.** We compare against two recent generative particle-filtering methods. **DiffPF**
> [ref] replaces the filter's update and resampling steps with a conditional diffusion model that
> samples the posterior particle set directly. We reimplement its mechanism — an ε-parameterized DDPM
> with $T=10$ cosine-schedule steps, conditioned on the encoded observation concatenated with 20
> flattened predicted particles, with min–max state normalization — following the authors' released
> code. Because their observation is an RGB image and their prediction step consumes robot odometry,
> neither of which exists in our setting, we replace the CNN observation encoder with an MLP over
> $(x, y, \text{visible})$ (using a null token under occlusion) and the odometry-based prediction with
> constant-velocity propagation; the conditional-diffusion posterior sampler itself is unchanged.
> **NF-DPF** [ref, ref] learns the filter's dynamic/proposal model with conditional normalizing flows.
> We port the conditional RealNVP block (two coupling sub-layers per block, two stacked blocks, Tanh
> scale/translation networks, near-identity initialization) and train it by exact maximum likelihood,
> conditioning it on the same context encoder used by all our learned motion models so the comparison
> isolates the generative mechanism. We do not reproduce their learned measurement model or
> differentiable resampling, both of which exist to handle image observations; our measurement
> likelihood is known and Gaussian.

---

## 6. Known gaps to close before submission

1. ~~**Run-to-run variance.**~~ **Done (2026-07-17).** Filters are now fully seeded
   (`np.random.seed` / `torch.manual_seed` per run in `benchmark_diffpf_vs_cfm.py`) and results are
   reported over 20 seeded runs with per-run std — see §7.
2. **DiffPF capacity.** 37k params vs 57–68k. Either scale its noise head up or state the gap.
3. ~~**Anchoring ablation.**~~ **Done.** anchor σ ∈ {0.3, 1.0, 2.0} sweep: σ=0.3 collapses spread
   (best-of-8 MAE stuck at ~0.95 at every NFE); σ=1.0 is the interior optimum; σ=2.0 adds nothing.
   Head-capacity ablation also done: `vel_hidden` 64→128 (head 6.6k → 21k params, larger than NF's
   17.4k flow stack) is slightly *worse* at every NFE — capacity is not the differentiator, the base
   distribution's spread is.
4. **DiffPF EMA** — cheap to add, and it is in their recipe.
5. ~~**Paired significance test.**~~ **Done for the reported 100-run suite.** Identical
   trajectories/seeds make paired per-run tests the appropriate statistic. The added-baseline runner
   emits paired t and Wilcoxon reports for PF+CFM-AS versus PF+CV/PF+DMMN; the full results and the
   remaining ablation plan are recorded in `ABLATION_AND_BENCHMARK_PLAN.md`.

---

## 7. Filter-level results — seeded, 100 runs × 2000 steps (2026-07-24)

CFM checkpoint: `cfm_motion_model_anchor1.0.pth` (anchor σ=1.0). **PF+CFM-AS** is the same model and
filter with an *occlusion-adaptive* anchor sigma — σ_t = min(2.5, σ₀·(1 + 0.05·steps_since_measurement)),
reset to σ₀ on each measurement. This is inference-time only (the anchored base is an explicit input to
the CFM sampler), requires no retraining, and has no counterpart in a RealNVP, whose sample spread is
frozen into its weights. Mean ± run-to-run std over 100 seeded runs; every tracker sees identical
trajectories and measurement streams (paired). Per-run values in `models/diffpf_vs_cfm_per_run.csv`.

| Tracker | RMSE all (m) | RMSE visible | RMSE occluded | Recovery (steps) | ms/step |
|---|---|---|---|---|---|
| PF+CFM (σ=1.0 fixed) | 0.578 ± 0.196 | 0.030 ± 0.018 | 0.816 ± 0.188 | 0.19 ± 0.77 | 11.5 |
| **PF+CFM-AS (adaptive σ)** | **0.461 ± 0.187** | 0.024 ± 0.005 | 0.643 ± 0.183 | **0.02 ± 0.12** | 11.9 |
| PF+NF | 0.461 ± 0.295 | 0.029 ± 0.019 | **0.624 ± 0.325** | 0.16 ± 0.57 | 11.2 |
| DiffPF | 0.626 ± 0.190 | 0.621 ± 0.217 | 0.622 ± 0.252 | 6.92 ± 14.4 | 7.6 |
| **PF+CV** | **0.260 ± 0.123** | 0.030 ± 0.005 | **0.365 ± 0.124** | 0.22 ± 1.32 | **0.24** |
| **PF+DMMN (offline ScratchTransformer)** | 1.055 ± 0.260 | 0.531 ± 0.209 | 1.380 ± 0.240 | 89.33 ± 107.52 | 9.76 |

**Added benchmark baselines (2026-08-12):**

- **PF+CV** is the same bootstrap PF with the clipped finite-difference
  constant-velocity proposal `v = (x_k - x_{k-1}) / dt`, Gaussian process
  noise, Gaussian measurement weighting, and ESS-triggered systematic
  resampling. It is a strong hand-coded motion-prior benchmark, and it is the
  best method on all-step and occluded RMSE in this synthetic setting.
- **PF+DMMN** means the original **offline** ScratchTransformer velocity model,
  not the online adaptive `MotionModel` selected by
  `prediction_method="DMMN"`. It loads
  `mml_network/models/best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth`
  using the original architecture (`input_dim=2`, `block_size=5`, `n_embed=20`,
  `n_head=8`, `n_layer=2`, `hidden_dim=20`). Its deterministic velocity output
  is injected into the same bootstrap PF; process noise supplies particle
  diversity. CFM-AS beats this historical learned baseline on every reported
  accuracy and recovery metric.

The runner is `mml_network/benchmark_cv_dmmn.py`; it appends only these two
trackers to the existing per-run CSV and preserves the completed four tracker
rows. `ABLATION_AND_BENCHMARK_PLAN.md` records their paired tests and the
remaining ablation suite.

**Paired significance (per-run, n=100), CFM-AS vs the field:**

| Comparison | Metric | mean diff (CFM-AS − other) | CFM-AS better in | paired-t p | Wilcoxon p | verdict |
|---|---|---|---|---|---|---|
| vs **NF-DPF** | RMSE all | +0.0004 | 36/100 | 0.98 | 0.27 | **tie** |
| vs **NF-DPF** | RMSE occluded | +0.019 | 36/100 | 0.39 | 0.11 | **tie** (NF slightly ahead, n.s.) |
| vs **NF-DPF** | RMSE visible | −0.005 | 20/100 | 0.018 | 0.001 | NF better (rank test) |
| vs **DiffPF** | RMSE all | −0.165 | 75/100 | 2e-10 | 6e-9 | **CFM-AS wins** |
| vs **DiffPF** | RMSE visible | −0.597 | 100/100 | 3e-48 | 4e-18 | **CFM-AS wins (all runs)** |
| vs **fixed-σ CFM** | RMSE occluded | −0.172 | 96/100 | 2e-32 | 1e-17 | **adaptive σ wins** |

**Honest reading (supersedes the 20-run numbers, which were noise-inflated):**
- **CFM-AS ties NF-DPF** on overall and occluded RMSE — the 20-run "beats NF on occluded" did **not**
  survive to 100 runs. CFM-AS's advantages over NF are *recovery* (0.02 vs 0.16 steps) and
  *consistency* (occluded std 0.18 vs 0.33, i.e. ~1.8× tighter), not lower mean error.
- **CFM-AS beats DiffPF** decisively (visible in 100/100 runs; overall in 75/100).
- **Adaptive σ is a robust, highly significant improvement over fixed σ** (96/100 runs) — the
  cleanest positive ablation result we have.
- DiffPF's flat profile (visible ≈ occluded ≈ 0.62) with 6.9-step recovery is the no-weighting
  signature of §3.1.
