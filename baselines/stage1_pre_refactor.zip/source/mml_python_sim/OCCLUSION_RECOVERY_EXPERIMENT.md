# Occlusion Recovery Experiment

Compares two trajectory-forecasting motion models — **Conditional Flow Matching (CFM)**
and the **ScratchTransformer** — on their ability to predict which direction a target
will exit an occlusion zone.

---

## What the experiment measures

When a target disappears behind an occluder, the tracker has to commit to a search
direction before the target reappears.  This experiment asks: **does the motion model's
trajectory forecast point the drone in the right direction?**

Two scores are computed per occlusion event:

| Score | Description | Applies to |
|---|---|---|
| **Modal-side recovery rate** | Fraction of events where the majority of forecast samples predicted the correct exit side (above / below the occluder centre). Binary — right or wrong per event. | Both models equally |
| **Mean probability score** | Mean fraction of probability mass the model placed on the *correct* exit side. CFM gives a genuine distribution; Transformer is deterministic so this is always 0 or 1. | CFM calibration analysis |

The probability score lets you check whether CFM is **calibrated** — i.e. when 70 % of
its samples say "above", does the target actually exit above ~70 % of the time?

---

## File structure

```
mml_python_sim/
│
├── config.yaml                              # simulation parameters (steps, dt, env size)
│
├── scripts/
│   ├── info_mml_main.py                     # main simulation entry point
│   ├── metrics.py                           # MetricsTracker + OcclusionRecoveryTracker
│   ├── run_recovery_experiment.sh           # batch runner: 10 runs × 2 methods
│   └── aggregate_recovery_results.py        # aggregation, tables, and plots
│
├── src/mml_guidance/
│   ├── models/
│   │   └── cfm_motion_model.pth             # CFM checkpoint
│   └── mml_guidance/
│       └── mml_network/
│           └── (ScratchTransformer weights loaded from project root)
│
├── best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth   # Transformer checkpoint
│
└── tracking_results/
    ├── CFM_MultiPFInfo_occlusion_recovery_CFM_<timestamp>.csv       # per-run raw events
    ├── MultiPFTra_MultiPFInfo_occlusion_recovery_MultiPFTra_<timestamp>.csv
    └── recovery_summary/
        ├── recovery_summary_<timestamp>.csv                         # aggregated stats
        ├── occlusion_recovery_comparison.png                        # bar chart
        └── calibration_reliability_diagram.png                      # reliability diagram
```

---

## Key parameters

### Simulation (`config.yaml`)

| Parameter | Default | Effect |
|---|---|---|
| `number_sim_steps` | 5000 | Steps per episode (overridden by `--num_steps`) |
| `dt` | 0.05 s | Physics timestep |
| `number_targets` | 2 | Number of targets tracked simultaneously |
| `target_lin_scale` | 0.5 | Target speed relative to agent max speed |

### Occlusion zones (`info_mml_main.py` line ~504)

```python
occlusion_centers = [1.8, 0.0,   1.2, 0.8,   -0.6, -0.5]   # [x0,y0, x1,y1, x2,y2] metres
occlusion_widths  = [1.0,         1.0,          1.5]
```

Three rectangular occluders.  The exit-side split for each event uses the y-coordinate
of the nearest occluder centre as the boundary (above / below).

### Experiment CLI flags (`info_mml_main.py`)

| Flag | Type | Default | Description |
|---|---|---|---|
| `--prediction_method` | choice | `MultiPFTra` | `CFM` or `MultiPFTra` (Transformer) |
| `--guidance_mode` | choice | `MultiPFInfo` | Agent guidance strategy |
| `--num_steps` | int | from config | Steps per run |
| `--recovery_metric` | flag | off | Enable OcclusionRecoveryTracker |
| `--no_fan` | flag | off | Skip trajectory fan render (faster); recovery uses velocity fallback |
| `--fan_samples` | int | 40 | Trajectory fan samples (used by recovery scorer when fan is active) |
| `--fan_steps` | int | 10 | Rollout horizon for each fan sample |
| `--run_number` | int | 0 | Labels the run in logs |

> **Important:** `--no_fan` disables the visual fan but the recovery tracker falls back
> to single-step velocity extrapolation for the directional prediction.  To use the full
> particle-fan scoring (more informative for CFM), omit `--no_fan`.

### Aggregator (`aggregate_recovery_results.py`)

| Flag | Default | Description |
|---|---|---|
| `--folder` | `tracking_results` | Directory to scan for `occlusion_recovery_*.csv` files |

---

## Step-by-step: running the comparison

### Prerequisites

Activate the conda environment that has pygame, pymunk, scipy, and scikit-learn:

```bash
conda activate tracking_ppo   # or whichever env has the full deps
cd /home/user/mml_python_sim
```

### Option A — Automated batch (recommended)

```bash
bash scripts/run_recovery_experiment.sh 10 2000
# args: <runs_per_method> <steps_per_run>
```

This runs CFM × 10 then Transformer × 10 and prints live progress.
Results land in `tracking_results/` automatically.

### Option B — Manual, one method at a time

**CFM — 10 runs:**
```bash
for i in $(seq 1 10); do
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    python scripts/info_mml_main.py \
        --prediction_method CFM \
        --guidance_mode MultiPFInfo \
        --num_steps 2000 \
        --recovery_metric \
        --no_fan \
        --run_number $i
done
```

**Transformer — 10 runs:**
```bash
for i in $(seq 1 10); do
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy \
    python scripts/info_mml_main.py \
        --prediction_method MultiPFTra \
        --guidance_mode MultiPFInfo \
        --num_steps 2000 \
        --recovery_metric \
        --no_fan \
        --run_number $i
done
```

> `SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy` runs pygame without a display
> (headless / server mode).  Drop these if you have a screen and want to watch the sim.

### Step 3 — Aggregate and compare

```bash
python scripts/aggregate_recovery_results.py --folder tracking_results
```

Outputs:
- Full per-model summary printed to terminal
- Head-to-head comparison table
- `tracking_results/recovery_summary/recovery_summary_<timestamp>.csv`
- `tracking_results/recovery_summary/occlusion_recovery_comparison.png`
- `tracking_results/recovery_summary/calibration_reliability_diagram.png`

---

## Inline output during a run

Each visibility transition prints a one-line event log:

```
[step 340]  Target 0 LOST  — GMM cache built (87 obs)
[step 412]  Target 0 FOUND — predicted=above  actual=above  modal=✓  prob=1.00
[step 890]  Target 0 LOST  — GMM cache built (134 obs)
[step 951]  Target 0 FOUND — predicted=above  actual=below  modal=✗  prob=0.00
```

And a per-run summary at the end:

```
============================================================
OCCLUSION RECOVERY SUMMARY  [CFM]
============================================================
Total occlusion events scored : 10
Modal-side recovery rate      : 80.0%  (8/10)
Mean probability score        : 0.800  (chance = 0.500)
Occlusion duration  mean/max  : 100.2 / 452 steps

Calibration (predicted prob → observed accuracy):
  [0.00]     0%  n=2  ##
  [0.70]   100%  n=6  ######
  [0.90]   100%  n=2  ##
============================================================
```

---

## Results (10 runs × 2000 steps, velocity-fallback scoring)

| Metric | CFM | Transformer |
|---|---|---|
| **Modal recovery rate — mean** | **87.7%** | 75.0% |
| **Modal recovery rate — std** | ±8.8% | ±20.7% |
| Mean probability score — mean | **0.862** | 0.750 |
| Mean probability score — std | ±0.102 | ±0.207 |
| Total occlusion events | 73 (9 runs) | 115 (10 runs) |
| Recovery rate delta | **+12.7 pp** in favour of CFM | |

**Key findings:**

1. **CFM achieves 12.7 percentage-point higher recovery rate** than the Transformer,
   correctly predicting exit direction in 87.7 % of occluded crossings vs 75.0 %.

2. **CFM is far more consistent**: std of 8.8 % vs 20.7 % for Transformer.
   The Transformer had runs ranging from 37.5 % to 100 %, showing high variance in
   whether the deterministic prediction happens to be correct.

3. **Calibration**: CFM's probability score (0.862) shows that when its samples are
   concentrated on one side, it is almost always correct.  The Transformer's binary
   score (0 or 1 per event, mean 0.750) confirms it matches CFM's recovery rate only
   when the target follows the most probable Markovian next step — it cannot represent
   ambiguity at trajectory bifurcations.

---

## How the scoring works (technical detail)

```
On ACTIVE → LOST (target enters occlusion)
   1. Build trajectory fan: sample N_particles from PF weighted by PF weights,
      roll each forward fan_steps using the motion model.
      For CFM: each sample draws fresh noise → genuinely different trajectories.
      For Transformer: deterministic output + cosmetic noise (not real uncertainty).
   2. Compute prob_above = weighted fraction of fan samples whose final y
      lies above occ_center_y.
   3. predicted_side = "above" if prob_above >= 0.5 else "below".

On LOST → ACTIVE (target reappears)
   4. actual_side = "above" if exit_pos[y] > occ_center_y else "below".
   5. modal_correct  = int(predicted_side == actual_side)    # 1 or 0
   6. prob_correct   = prob_above if actual=="above" else 1-prob_above
```

When `--no_fan` is set, step 1 is skipped and the prediction uses a single-step
velocity extrapolation from the last known position and velocity instead.

---

## Why the fan is required — and what `--no_fan` actually measures

This is a critical distinction. The trajectory fan is **not** just a visualization aid —
it is the only mechanism through which CFM's learned distribution is actually sampled
at inference time.

### How CFM works at inference time

CFM learns a vector field that transforms random noise into a velocity prediction.
Every call to `propose()` draws fresh Gaussian noise `x_0 ~ N(0, I)` and integrates
it forward through the learned vector field conditioned on the particle's position
history.  Because `x_0` differs each time, 40 fan samples produce 40 **genuinely
different** trajectory predictions.  This is what `propose_sequence` does inside
`build_motion_model_trajectory_fan`.

### How the Transformer works at inference time

The Transformer maps the same input history to the same output every time — it is a
deterministic function.  The fan adds `transformer_visual_noise = 0.03` purely so the
visualisation looks like a spread of lines, but the code comment makes this explicit:

```python
# For Transformer, the base model is deterministic, so small optional
# visualization noise is added only to show local spread. This does NOT make
# the Transformer truly multi-modal.
```

### What `--no_fan` actually does to the recovery scoring

When `--no_fan` is passed, the tracker receives `fan=None` and falls through to the
velocity fallback in `_score_fan`:

```python
predicted_y = last_known_pos[1] + last_known_vel[1]
```

This is ground-truth velocity extrapolation from the simulator state `z_[i, 3:5]`.
**Neither CFM nor the Transformer is consulted.**  Both methods therefore score
identically — which is exactly what the `--no_fan` batch showed (93.3 % vs 93.7 %,
essentially the same number).

### Summary of the three cases

| Mode | What generates the prediction | CFM behaviour | Transformer behaviour |
|---|---|---|---|
| **With fan** | Motion model rollout via the learned model | 40 genuinely different samples from the flow distribution | 40 near-identical samples (deterministic + cosmetic noise) |
| **`--no_fan`** | Ground-truth velocity extrapolation | Model not used at all | Model not used at all |
| **Visualisation only** | Same fan, drawn on screen | Same samples rendered as coloured lines | Same samples rendered as coloured lines |

### What the fan comparison actually proves

With the fan active, CFM's **87.7 % vs 75.0 %** recovery rate (from the earlier
fan-based batch) measures the actual learned models head to head:

- CFM's learned distribution covers the real exit direction more reliably because it
  can place samples on multiple modes simultaneously.
- The Transformer's single deterministic prediction gets it wrong more often at
  trajectory bifurcations — it commits to one mode even when the situation is
  genuinely ambiguous.

**The fan is the only way to expose CFM's advantage.**  Without it, you are testing
how well ground-truth velocity predicts exit direction, which is identical for both
methods and tells you nothing about the quality of the learned motion models.

---

## Metric computation logic and rationale

This section walks through every number the `OcclusionRecoveryTracker` produces,
showing the exact formula, the code that computes it, and why that particular metric
was chosen.

---

### Step 1 — Detect an occlusion entry event

Every simulation step the main loop checks whether each target is visible:

```python
in_fov = guidance.is_in_FOV(target_pos, guidance.FOV)
in_occ = guidance.occlusions.in_occlusion(target_pos)
visible = bool(in_fov and not in_occ)
```

When `_was_visible[i]` flips from `True` → `False` (ACTIVE → LOST), an entry event
is recorded.  At that exact moment the trajectory fan is built from the current
particle filter state and passed to `record_entry`.

**Why at entry, not during occlusion?**
The model only has information up to the last visible frame.  Scoring the prediction
at entry — before the target disappears — is the only honest test of what the model
knew at decision time.  Scoring later would allow information that arrived after the
target was lost to leak into the prediction.

---

### Step 2 — Score the fan at entry (`_score_fan`)

The fan has shape `(N, T, 2)`: N trajectory samples, each T steps long, each step a
2D position in metres.  The scoring uses only the **final predicted position** of each
sample — i.e. where does the model think the target will be after T steps?

```python
final_y = fan[:, -1, 1]          # y-coordinate of the last step, shape (N,)
```

Each sample carries a weight `w_i` inherited from the particle filter (high-weight
particles contribute more).  The weights are normalised so they sum to 1:

```python
weights /= weights.sum()
```

The key quantity is **prob_above**: the total probability mass predicting the target
will exit above the occlusion centre's y-coordinate `y_c`:

```
prob_above = Σ  w_i  ·  𝟙[ final_y_i > y_c ]
             i
```

In code:

```python
prob_above = float(weights[final_y > occ_center_y].sum())
```

The **modal prediction** is then just a majority vote:

```python
predicted_side = "above" if prob_above >= 0.5 else "below"
```

**Why `final_y` and not mean y across all steps?**
The exit direction is determined by where the target ends up after crossing the
occluder, not by its path through it.  Using the final position focuses the metric
on the outcome the drone actually needs to predict.

**Why the occlusion centre y as the split boundary?**
The three occluders are roughly symmetric boxes.  A target entering any one of them
must exit either above or below its centre line.  The centre y-coordinate is the
natural decision boundary.  Using it makes the split unambiguous and consistent across
all three occluder zones.

---

### Step 3 — Detect an occlusion exit event

When `_was_visible[i]` flips from `False` → `True` (LOST → ACTIVE), `record_exit`
is called with the target's first re-observed position `exit_pos`.

The **actual exit side** is determined the same way as the prediction:

```python
actual_side = "above" if exit_pos[1] > occ_center_y else "below"
```

---

### Metric 1 — Modal-side score (per event)

```
modal_correct = 1   if predicted_side == actual_side
              = 0   otherwise
```

In code:

```python
modal_correct = int(predicted_side == actual_side)
```

This is a **binary outcome per occlusion event**.  It directly answers: did the
model's majority prediction point the drone in the right direction?

**Why binary and not continuous?**
The drone has to commit to a search direction — it cannot hedge.  A binary score
mirrors the actual downstream decision.  It is also directly comparable between CFM
(which produces a real distribution) and the Transformer (which is deterministic),
because both are reduced to a single directional commitment before scoring.

---

### Metric 2 — Probability score (per event)

The probability score is the fraction of mass the model placed on the **correct**
side:

```
prob_correct = prob_above        if actual_side == "above"
             = 1 − prob_above    if actual_side == "below"
```

In code:

```python
if actual_side == "above":
    prob_correct = prob_above
else:
    prob_correct = 1.0 - prob_above
```

`prob_correct` is always in [0, 1].  A value of 1.0 means all samples predicted the
correct side.  A value of 0.5 means the model was maximally uncertain.  A value of
0.0 means all samples predicted the wrong side.

**Why keep this separate from the modal score?**
The modal score treats a 51 % majority the same as a 99 % majority — both score 1.
The probability score preserves that difference.  For CFM, which genuinely spreads
samples across modes, this reveals whether the model is **calibrated**: when it says
"70 % above", does the target actually exit above ~70 % of the time?  For the
Transformer, `prob_correct` is always 0 or 1 (deterministic), so it collapses back
to the modal score and the calibration analysis is not meaningful.

---

### Metric 3 — Modal-side recovery rate (across all events in a run)

```
                    number of events where modal_correct = 1
Recovery Rate  =  ──────────────────────────────────────────
                         total scored events
```

In code (`modal_recovery_rate` method):

```python
scored = [e["modal_correct"] for e in self.events if e["modal_correct"] is not None]
return float(np.mean(scored))          # mean of 0s and 1s = fraction correct
```

This is the **primary headline number** reported in the comparison table.

**Why average across events rather than across runs?**
Events within a run are independent occlusion crossings.  Averaging across events
weights each crossing equally regardless of how long it lasted.  The per-run mean
(reported as mean ± std across 10 runs) then gives both the typical performance and
the run-to-run variance, which reveals consistency.

---

### Metric 4 — Mean probability score (calibration metric)

```
                   1    N
Mean Prob Score = ─── · Σ  prob_correct_i
                   N   i=1
```

In code (`mean_prob_correct` method):

```python
scored = [e["prob_correct"] for e in self.events if e["prob_correct"] is not None]
return float(np.mean(scored))
```

The **chance baseline is 0.5** (random directional guessing is correct 50 % of the
time).  A perfect model that always places all mass on the correct side scores 1.0.

**Why use this in addition to recovery rate?**
Recovery rate only counts wins and losses.  Mean probability score rewards
**confident correct predictions** and penalises **confident wrong predictions**
more than uncertain ones.  For a paper contribution, showing that CFM's mean
probability score exceeds the Transformer's is evidence that CFM's uncertainty
estimate is meaningful — not just that it happens to pick the right mode more often.

---

### Metric 5 — Calibration table (reliability diagram)

Events are binned by `prob_correct` into 5 equal-width bins from 0 to 1.  For each
bin, the observed accuracy (fraction of events in that bin where `modal_correct = 1`)
is computed:

```python
bins = np.linspace(0.0, 1.0, n_bins + 1)
for lo, hi in zip(bins[:-1], bins[1:]):
    mask = (prob_correct >= lo) & (prob_correct < hi)
    accuracy = modal_correct[mask].mean()
```

A **perfectly calibrated** model would show observed accuracy ≈ bin centre for every
bin — i.e. when it says 0.7, it is right 70 % of the time.

**Why include this?**
This is the secondary paper contribution.  A high recovery rate alone could be
achieved by a model that is always overconfident.  The calibration table distinguishes
a model that genuinely knows when it is uncertain (CFM, which spreads samples across
both modes at real bifurcations) from one that happens to be right for the wrong
reason.  For the Transformer, all events fall in the [0.0, 0.2) or [0.8, 1.0) bins
because its prob_correct is always 0 or 1 — there is no middle ground to calibrate.

---

### Complete per-event data saved to CSV

Each row in the output CSV corresponds to one scored occlusion crossing:

| Column | Type | Description |
|---|---|---|
| `target_id` | int | Which target (0 or 1) |
| `entry_step` | int | Simulation step when target entered occlusion |
| `exit_step` | int | Simulation step when target reappeared |
| `duration_steps` | int | `exit_step − entry_step` |
| `occ_center_y` | float | y-coordinate of the nearest occluder centre [m] |
| `predicted_side` | str | `"above"` or `"below"` — modal fan prediction |
| `actual_side` | str | `"above"` or `"below"` — observed exit direction |
| `modal_correct` | int | 1 if prediction matched, 0 otherwise |
| `prob_correct` | float | Fraction of fan mass on the correct side [0, 1] |
