# DETAILED STEP-BY-STEP IMPLEMENTATION GUIDE

> This guide explains **exactly** how to implement every component below.
> It is written against the actual source files — every line number reference
> is to the unmodified code as it exists right now.
> Follow phases in order. Each phase is independently testable.

---

## DATA FLOW OVERVIEW

```
┌─────────────────────────────────────────────────────────────────────────┐
│  EVERY env.step(action) call                                            │
│                                                                         │
│  1. pygame env runs physics, returns next_state (truth)                 │
│     next_state[0]   = agent  [x, y, θ, vx, vy, ω]                     │
│     next_state[1+i] = target [x, y, θ, vx, vy, ω]                     │
│                                                                         │
│  2. FOR EACH TARGET i:                                                  │
│     a. Visibility check (PHASE 1)                                       │
│        dist = ||true_target_pos - agent_pos||                          │
│        in_fov     = dist ≤ env.fov_size_meters                         │
│        in_occ     = target inside any occlusion box                    │
│        visible    = in_fov AND NOT in_occ                              │
│                                                                         │
│     b. Particle filter update (PHASE 1, gated)                         │
│        if visible:  pf.is_update = True  → predict + correct          │
│        if not:      pf.is_update = False → predict only               │
│        estimate = pf.weighted_mean  ← best guess regardless           │
│        confidence = neff / (0.7·N) if visible else 0.0                │
│                                                                         │
│     c. History buffer append (PHASE 2)                                  │
│        if visible: history[i].append({pos, vel, t, episode})           │
│                                                                         │
│     d. Track status update (PHASE 4)                                   │
│        ACTIVE → LOST: just lost, apply track-loss penalty             │
│        LOST → ACTIVE: just reacquired, apply reacquisition bonus      │
│                                                                         │
│  3. Build observation (PHASE 1 + PHASE 3)                              │
│     For each target i:                                                  │
│       if confidence > 0: obs_i = [rel_x, rel_y, rel_vx, rel_vy, conf] │
│       if confidence = 0: obs_i = [0,    0,    0,    0,    0   ]       │
│                          ← LSTM hidden state carries last trajectory   │
│       if LOST (PHASE 3): append search_prior = GMM top-3 means        │
│                                                                         │
│  4. Compute reward (PHASE 4, always from TRUE state)                   │
│     = OSPA reward + info-gain + track-loss penalty + reacq bonus       │
│                                                                         │
│  5. LSTM policy                                                         │
│     obs_t, h_{t-1}  →  LSTM  →  h_t, action                          │
│     h_t encodes "last known trajectory" when obs_i = [0,0,0,0,0]     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## CODE CHANGE EXPLANATION — WHAT CHANGED, WHY, AND HOW IT WORKS

This section explains every change made across the three modified files.
Each subsection starts with a flowchart, then walks through the code logic.

---

### 3-File Relationship Diagram

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                         SYSTEM ARCHITECTURE                                  │
│                                                                              │
│  gym_pursuit_env.py          observation_history.py     attention_policy.py  │
│  ─────────────────           ────────────────────────   ──────────────────── │
│  step() loop                 deque(maxlen=1000)          AttentionFeatureExtractor│
│    │                          per target                   │                 │
│    ├─ _is_in_fov()            │                           ├─ agent_encoder   │
│    ├─ _is_occluded()          │ add(pos,vel,t,ep)         │   4 → 64         │
│    ├─ pf.is_update = visible ←┘  (Phase 2)               ├─ target_encoder  │
│    ├─ confidence = neff/0.7N                              │   5 → 64  ←────── obs space shape│
│    ├─ track_status ACTIVE↔LOST                           ├─ transformer     │
│    ├─ history_manager.add()  ──────────────────────────→ │   64→64 per token│
│    ├─ construct_search_prior()  ←─ get_positions()        ├─ search_encoder  │
│    │   fit GMM on history                                 │   N*6 → 32       │
│    └─ build obs dict          ─────────────────────────→ └─ output_layer    │
│         agent(4)                                              160 → 128      │
│         targets(N,5) — zeroed when lost                                      │
│         mask(N)                                                              │
│         search_prior(N*6) — GMM hints when lost                             │
│                                  ↓                                           │
│                         LSTM policy receives obs                             │
│                         h_{t-1} + obs_t → h_t + action                     │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

### FILE 1 — `attention_policy.py` — What Changed and Why

#### What It Does

The `AttentionFeatureExtractor` converts a dictionary observation into a fixed
128-D feature vector for the LSTM policy.  The dictionary has four keys:
`agent`, `targets`, `mask`, `search_prior`.

#### Before vs After (Network Architecture)

```
BEFORE (old code):
──────────────────
 agent [B,4]  ──→ Linear(4→64) → ReLU × 2 ──────────────────────────┐
 targets[B,N,4]──→ Linear(4→64)                                       │
                   + PositionalEncoding                                 ├─→ Linear(128→128) → 128
                   + Transformer(d=64,heads=4,layers=2)               │
                   + MaskedMeanPool ──→ [B,64] ─────────────────────→ ┘
                                            ↑ only 128 dims in concat

AFTER (new code):
──────────────────
 agent  [B,4]  ──→ Linear(4→64) → ReLU × 2 ────────────────────────────┐
 targets[B,N,5]──→ Linear(5→64)  ← reads shape[-1] from obs space      │
                   + PositionalEncoding                                   │
                   + Transformer(d=64,heads=4,layers=2)                 ├─→ Linear(160→128) → 128
                   + MaskedMeanPool ──→ [B,64] ────────────────────────→│
 search_prior[B,N*6]─→ Linear(N*6→64)→ReLU→Linear(64→32)→ReLU → [B,32]┘
                                               ↑ 160 = 64+64+32
```

#### Why Each Change Was Made

**1. `target_encoder` input: hardcoded `4` → reads from obs space `shape[-1]`**

```python
# OLD — hardcoded, crashes when obs dim changes
self.target_encoder = nn.Linear(4, 64)

# NEW — reads whatever the obs space says (currently 5)
target_feature_dim = observation_space['targets'].shape[-1]   # 5
self.target_encoder = nn.Linear(target_feature_dim, 64)
```

- **Why**: Phase 1 added a 5th dimension (tracking confidence) to each target
  slot. If the input layer stays at 4, PyTorch throws a shape mismatch at
  runtime.  Reading the dim from the obs space makes the network self-adapt
  whenever the obs schema changes again (e.g., adding a heading dim in the
  future).

**2. New `search_encoder` branch**

```python
# NEW — processes the GMM search hints for lost targets
search_prior_dim = observation_space['search_prior'].shape[0]  # max_targets * 6
self.search_encoder = nn.Sequential(
    nn.Linear(search_prior_dim, 64),
    nn.ReLU(),
    nn.Linear(64, 32),
    nn.ReLU(),
)
```

- **Why**: When a target is lost, the `search_prior` vector carries the top-3
  GMM means (agent-relative).  The LSTM policy needs a dedicated encoder branch
  to compress this spatial hint from `N*6` dims down to 32 dims.  If we had
  just padded the targets tensor, the Transformer's attention weights would
  need to learn to re-route to a ghost entry, which is much harder to train.
  A separate encoder is cleaner and converges faster.

**3. `output_layer` input: 128 → 160**

```python
# OLD
self.output_layer = nn.Sequential(nn.Linear(128, 128), nn.ReLU())

# NEW — adds 32 extra dims from search_encoder
self.output_layer = nn.Sequential(nn.Linear(64 + 64 + 32, 128), nn.ReLU())
```

- **Why**: The forward pass now concatenates three branch outputs: agent(64) +
  targets(64) + search(32) = 160.  The output stays at 128 (the downstream
  LSTM expects a fixed input size), so only the input side changes.

#### Forward Pass Flowchart

```
forward(observations):
│
├─ agent_encoder(observations['agent'])          → agent_features [B, 64]
│
├─ target_encoder(observations['targets'])        → [B, N, 64]
│   + positional_encoding
│   + transformer (with src_key_padding_mask)    → [B, N, 64]
│   + masked mean pool over valid (mask=1) slots → target_pooled [B, 64]
│
├─ search_encoder(observations['search_prior'])   → search_features [B, 32]
│
└─ output_layer(cat([agent_features,             → features [B, 128]
                     target_pooled,
                     search_features]))
```

---

### FILE 2 — `environments/gym_pursuit_env.py` — What Changed and Why

This is the central file.  All four implementation phases live here.
The changes are grouped by phase.

---

#### Phase 1 — Visibility Gating + Confidence

**Problem being solved**: `pf.is_update` was `True` unconditionally every step.
The particle filter always received a measurement, even when the target was
outside the FOV or inside an occlusion box.  The agent had no way to know it
had lost track.

##### Phase 1 Flowchart

```
EVERY step(), FOR EACH target i:
│
├─ true_target_pos = next_state[1+i, :2]
│
├─ VISIBILITY GATE ──────────────────────────────────────────────────────
│   dist = ||true_target_pos - agent_pos||
│   in_fov  = (dist ≤ env.fov_size_meters)           ← _is_in_fov()
│   in_occ  = target inside any occlusion box         ← _is_occluded()
│   visible = in_fov AND NOT in_occ
│
├─ PARTICLE FILTER (gated) ─────────────────────────────────────────────
│   pf.is_update = visible   ← KEY CHANGE: was always True
│   pf.pf_loop(noisy_measurement, t)
│     if is_update=True:  predict + correct   (measurement used)
│     if is_update=False: predict only        (particles spread)
│   estimate   = pf.weighted_mean             ← best guess either way
│   neff       = pf.neff                      ← drops when particles spread
│
├─ CONFIDENCE ──────────────────────────────────────────────────────────
│   if visible:  confidence = min(1.0, neff / (0.7 * N))
│   else:        confidence = 0.0
│
├─ TRACK STATUS ────────────────────────────────────────────────────────
│   if visible:
│       track_status[i] = ACTIVE
│       last_seen_pos   = true_target_pos
│   else if was ACTIVE:
│       track_status[i] = LOST
│       lost_time       = current_time
│
└─ OBSERVATION ─────────────────────────────────────────────────────────
    if confidence > 0: obs slot = [rel_x, rel_y, rel_vx, rel_vy, conf]
    if confidence = 0: obs slot = [0, 0, 0, 0, 0]
                        ↑ LSTM hidden state h_t carries last trajectory
```

**Why zero out the slot instead of using the stale estimate?**

The particle filter's `weighted_mean` when `is_update=False` is a momentum
extrapolation — it follows the last velocity.  If we fed that to the policy,
the policy can't distinguish "I see the target at (2, 1)" from "I am guessing
it's at (2, 1) based on inertia."  By zeroing the slot and setting
`confidence=0`, we force the LSTM hidden state to be the sole carrier of
past information.  The LSTM then learns: "zeroed slot + h_t says it was moving
north → go north to search."

**How `_is_occluded()` works (no ray tracing)**

```python
def _is_occluded(self, target_pos) -> bool:
    for (cx, cy), w in zip(self._occ_centers_m, self._occ_widths_m):
        # Axis-aligned bounding box test:
        if (abs(target_pos[0] - cx) < w / 2 and
                abs(target_pos[1] - cy) < w / 2):
            return True
    return False
```

Each occlusion zone is a square.  A target is occluded if its (x, y) falls
inside that square — no ray tracing needed.  The occlusion squares are physical
obstacles, so if the target is *inside* the box, we have no line of sight.
`_occ_centers_m` and `_occ_widths_m` are captured in `reset()` from the
return values of `env.randomize_occlusions()` / `env.set_fixed_occlusions()`.

---

#### Phase 2 — Observation History Buffer

**Problem being solved**: The GMM search prior (Phase 3) needs to know where
this target has historically travelled.  No such record existed.

##### Phase 2 Flowchart

```
step() — inside the per-target loop, AFTER visibility gate:
│
├─ if visible AND use_particle_filter:
│       history_manager.add(
│           target_id = i,
│           position  = true_target_pos,   ← true pos, not PF estimate
│           velocity  = next_state[1+i, 3:5],
│           timestamp = current_time,
│           episode   = episode_count,
│       )
│
reset() — at the very start:
│
└─ history_manager.save()    ← persists to disk if save_to_file=True
                                no-op if in-memory mode (default)
```

**Why true position, not PF estimate?**

The history is used to model where a target physically goes (its spatial
density over the map).  If we stored the PF estimate, we would be recording
PF drift (especially when the PF is uncertain), which would corrupt the GMM.
The ground truth is available to the training env (we have `next_state`), so
we use it.

**Why only visible observations?**

Storing invisible observations would record where we *think* the target is
during occlusion — PF extrapolation, not real data.  The GMM learns the
true reachable space, which is what we want for "where should I look?"

---

#### Phase 3 — GMM Search Prior

**Problem being solved**: When a target is lost, the agent gets a zeroed obs
slot.  It can use the LSTM hidden state to remember the last trajectory, but
it has no map-level "hot spots" for where the target tends to be.  The GMM
provides this.

##### Phase 3 Flowchart

```
step() — inside the per-target loop, AFTER track status update:
│
├─ if track_status[i] == LOST and prev_track_status[i] == ACTIVE:
│       (just became lost this step)
│       means, _ = construct_search_prior(i)
│       _search_prior_cache[i] = means    ← cache: only rebuild on transition
│
└─ search_priors.append(_search_prior_cache[i])
        ↑ None for ACTIVE targets


construct_search_prior(target_id):
│
├─ hist_pos = history_manager.get_positions(target_id)   → (N, 2) array
│
├─ road_nodes = 8 hardcoded map nodes (from pygame env road graph)
│
├─ if len(hist_pos) >= 5:
│       positions = vstack([hist_pos, road_nodes])
│   else:
│       positions = road_nodes     ← fallback when buffer is thin
│
├─ k = min(3, len(positions))
├─ GaussianMixture(n_components=k).fit(positions)
└─ return means sorted by weight descending   → (k, 2) in meters


_get_observation() — use_attention branch:
│
└─ for each target slot i:
       if conf == 0.0 and search_priors[i] is not None:
           rel_means = search_priors[i] - agent_pos    ← agent-relative!
           search_prior_vec[i*6 : i*6+6] = rel_means.flatten()[:6]
```

**Why only rebuild GMM on ACTIVE→LOST transition (not every step)?**

Fitting a GMM with sklearn on 1000 observations takes ~1–5 ms.  Doing this
every step would add ~100 ms per episode.  Since the search prior doesn't
change after the target is lost (we don't have new data), caching it and
only rebuilding on the ACTIVE→LOST edge is both correct and efficient.

**Why agent-relative coordinates in the observation?**

The LSTM policy needs to know "the target is probably 3 m to my northeast."
Absolute map coordinates would require the policy to first subtract its own
position — an extra computation the network must learn.  Agent-relative is
directly actionable: large positive x → move east.

**Why road nodes as pseudo-observations?**

When the buffer is thin (< 5 real observations, early in training), the GMM
has nothing to fit.  Road network nodes are the only places the target can
realistically be (the env uses a Markov chain over 8 nodes).  Adding them as
pseudo-observations ensures the prior is always sensible, even in episode 1.

---

#### Phase 4 — Reward Engineering

**Problem being solved**: The base OSPA/distance reward does not distinguish
"I tracked the target perfectly" from "I tracked it for 5 seconds then lost
it forever."  Both get similar cumulative reward.  The agent needs a signal
that explicitly penalises track loss and rewards recovery.

##### Phase 4 Flowchart

```
reset() — ramp weights by curriculum:
│
└─ if episode_count > 1000:
       ramp = min(1.0, (episode_count - 1000) / 4000.0)   ← 0→1 over 4000 eps
       w_track_continuity = 0.5 * ramp
       w_reacquisition    = 1.0 * ramp


step() — AFTER the per-target loop:
│
├─ track_penalty = 0.0
│   for i in range(num_targets):
│       if cur=LOST and prev=ACTIVE:
│           track_penalty -= 2.0     ← one-time spike: just lost track
│       if cur=LOST:
│           time_lost = current_time - track_status[i]['lost_time']
│           track_penalty -= 0.05 * min(time_lost, 20.0)  ← continuous drain
│
├─ reacq_bonus = 0.0
│   for i in range(num_targets):
│       if cur=ACTIVE and prev=LOST:
│           reacq_bonus += 5.0       ← large spike: just recovered track
│
└─ reward = base_reward
           + w_track_continuity * track_penalty
           + w_reacquisition    * reacq_bonus
```

**Why curriculum ramp (start at episode 1000)?**

If track-loss penalties are active from episode 0, the agent is punished before
it has learned what "tracking" means.  This destabilises early training: the
policy gradient sees large negative rewards for states it doesn't yet know how
to avoid.  Starting at episode 1000 gives the agent time to learn basic pursuit
before the harder signal is introduced.

**Why a one-time spike + continuous drain (two-part penalty)?**

- The **one-time spike** (`-2.0`) signals that the track loss event itself is
  bad.  Without this, the agent might accept a brief occlusion without penalty.
- The **continuous drain** (`-0.05 * time_lost`) creates gradient pressure to
  re-acquire quickly.  The `min(time_lost, 20.0)` cap prevents the penalty
  from dominating the reward after a very long loss.

**Why a large re-acquisition bonus (`+5.0`)?**

Re-acquiring a target requires purposeful search: the agent must move toward
a predicted location.  A large sparse bonus creates a clear gradient signal
for this behaviour even though it happens infrequently.  Without the bonus,
the OSPA reward gain from re-acquisition is small (the PF was wrong for many
steps), so the policy has no specific incentive to search.

---

### FILE 3 — `environments/observation_history.py` — What Was Added and Why

This is a new file.  It did not exist before.

#### Why a Separate File?

The history buffer is used by Phase 3 (GMM) but is logically independent of
the env step loop.  Keeping it in its own module makes it testable in
isolation, importable by other environments, and avoids making
`gym_pursuit_env.py` even longer.

#### Structure

```
ObservationHistoryManager:
│
├─ self.history : list[deque]     ← one deque per target, maxlen=max_size
│
├─ add(target_id, position, velocity, timestamp, episode)
│       Appends one dict to history[target_id].
│       Caller (step()) is responsible for checking visibility
│       before calling this — only visible observations should be stored.
│
├─ get_positions(target_id, last_n=None)
│       Returns np.ndarray of shape (N, 2).
│       Used by construct_search_prior() to get the position cloud.
│       last_n allows requesting only recent observations
│       (e.g., last 50 steps) for a more local prior.
│
├─ save()     ← pickle.dump(self.history, f)   no-op if save_to_file=False
└─ _load()    ← pickle.load on startup          if save_to_file=True
```

#### In-Memory vs File Persistence (default: in-memory)

```
In-memory (save_to_file=False):
  Episode 1 start: buffer empty
  Episode 1 step 1..T: deque fills
  Episode 2 start: deque continues filling (rolls over at 1000)
  Program restart: buffer gone → start fresh

File persistence (save_to_file=True):
  Episode 1 start: try load obs_history.pkl → if exists, restore deques
  Episode 1 end: pickle.dump → save to disk
  Program restart: load pkl → deques restored with N past episodes
  Risk: stale data from old map layout → clear pkl between experiments
```

#### Data Flow Into the Buffer

```
step() → for each target i:
  │
  ├─ in_fov  = _is_in_fov(true_target_pos, agent_pos)
  ├─ in_occ  = _is_occluded(true_target_pos)
  ├─ visible = in_fov and not in_occ
  │
  └─ if visible and use_particle_filter:
         history_manager.add(
             target_id = i,
             position  = true_target_pos,      ← ground truth x, y
             velocity  = next_state[1+i, 3:5], ← ground truth vx, vy
             timestamp = current_time,
             episode   = episode_count,
         )
         ↓
         history[i].appendleft({...})   (deque auto-drops oldest if full)
```

---

### Complete Per-Step Data Flow (All Phases Combined)

```
env.step(action)
│
├─ 1. pygame env physics → next_state (ground truth)
│
├─ 2. FOR EACH target i:
│       a. [Phase 1]  Visibility gate
│              dist   = ||next_state[1+i,:2] - agent_pos||
│              in_fov = dist ≤ fov_size_meters
│              in_occ = target inside any occ box (point-in-AABB)
│              visible = in_fov AND NOT in_occ
│
│       b. [Phase 1]  Particle filter (gated)
│              pf.is_update = visible
│              pf.pf_loop()
│                if visible: predict + correct  → particles tighten
│                else:       predict only       → particles spread
│              confidence = neff/(0.7·N) if visible else 0.0
│
│       c. [Phase 1]  Track status
│              visible → ACTIVE  (record last_seen_pos)
│              invisible, was ACTIVE → LOST (record lost_time)
│
│       d. [Phase 2]  History buffer
│              if visible: history_manager.add(true_pos, true_vel, t, ep)
│
│       e. [Phase 3]  GMM search prior
│              if just became LOST (ACTIVE→LOST this step):
│                  means = construct_search_prior(i)
│                  _search_prior_cache[i] = means    ← cached
│              search_priors[i] = _search_prior_cache[i]
│
├─ 3. Build observation dict [Phase 1 + 3]
│       agent(4)             = [x, y, vx, vy]
│       targets(N, 5)        slot i:
│                                 conf>0: [rel_x, rel_y, rel_vx, rel_vy, conf]
│                                 conf=0: [0, 0, 0, 0, 0]  ← LSTM uses h_t
│       mask(N)              = 1 for each occupied slot
│       search_prior(N*6)    slot i*6..i*6+6:
│                                 LOST:   [rel_mean1_x, rel_mean1_y,
│                                          rel_mean2_x, rel_mean2_y,
│                                          rel_mean3_x, rel_mean3_y]
│                                 ACTIVE: [0, 0, 0, 0, 0, 0]
│
├─ 4. Compute reward [Phase 4]
│       base   = _compute_reward(next_state)   ← OSPA or distance
│       penalty = 0
│         LOST targets: -2.0 (one-time) + -0.05*time_lost (continuous)
│       bonus  = 0
│         ACTIVE, was LOST: +5.0
│       reward = base + w_continuity*penalty + w_reacquisition*bonus
│
└─ 5. Return obs, reward, terminated, truncated, info
        info includes: target_visible, target_confidences,
                       n_lost, track_penalty, reacq_bonus
```

---

### LSTM Hidden State as Implicit Memory

The reason this design works is that the LSTM hidden state `h_t` is already a
compressed history of all past observations.  We don't need a separate "recall"
mechanism.  The zeroing of lost-target slots is the key:

```
t=0..10  target visible:
    obs_t = [rel_x, rel_y, rel_vx, rel_vy, conf=0.9]
    LSTM: h_t encodes "target 2 m east, moving north at 0.5 m/s"

t=11  target enters occlusion:
    obs_t = [0, 0, 0, 0, 0]    ← zeroed
    LSTM: h_11 ← f(h_10, [0,0,0,0,0])
           h_11 still carries trajectory from h_10

t=12..15  still lost:
    obs_t = [0, 0, 0, 0, 0] each step
    LSTM policy: action = "move north" (from h_t trajectory)
    search_prior  = GMM means (additional map hint)

t=16  target exits occlusion:
    obs_t = [rel_x, rel_y, rel_vx, rel_vy, conf=0.8]
    LSTM: h_16 ← f(h_15, obs_t)   ← new measurement integrated
```

The agent does not need explicit "past history traversal" — the LSTM hidden
state *is* the past history.  Phase 1 (zeroing) makes the boundary between
"I see the target" and "I lost it" explicit, which is the signal the LSTM
needs to learn correct search behaviour.

---

## HISTORY STORAGE DECISION

**Question: Do we save the observation history to a file, or keep it only in memory?**

### Option A — In-memory only (DEFAULT, recommended)

```
Program starts → history buffer is empty
  Episode 1  → buffer fills with ~100-500 observations
  Episode 2  → buffer continues filling (deque rolls over at max_size=1000)
  ...
  Episode N  → GMM fits ~1000 real observations + road-node pseudo-obs
Program restarts → buffer is empty again (starts fresh)
```

**Why this is the right default:**
- Simple — no I/O, no stale-data risk from old training runs
- Sufficient — within a single training run, the buffer fills after ~10 episodes
- The LSTM already handles within-episode temporal memory
- The GMM only needs ~50 good observations to be useful; 1000 steps ≈ 100 seconds

**How to enable:** `GymPursuitEnv(history_save_to_file=False)` (default)

---

### Option B — File persistence (opt-in)

```
Program starts → loads history from obs_history.pkl if it exists
  Episode 1  → appends to buffer, saves pkl at episode end
  Episode 2  → same
  ...
Program restarts → reloads pkl, buffer already has N past observations
```

**When to use:**
- You want the GMM to benefit from observations across multiple training runs
- You are doing analysis/debugging and want to inspect historical trajectories
- You resume training from a checkpoint and want the old search prior

**Risk:** If the environment changes (different occlusion layout, different road network),
stale observations can mislead the GMM. Clear `obs_history.pkl` before each new experiment.

**How to enable:** `GymPursuitEnv(history_save_to_file=True, history_save_path='obs_history.pkl')`

---

### Summary table

| | In-memory (default) | File persistence |
|---|---|---|
| Survives program restart | No | Yes |
| Risk of stale data | None | Yes (clear pkl between experiments) |
| I/O overhead | None | ~1 ms per episode (pickle write) |
| Recommended for | Training | Debugging / cross-run analysis |

---

## PHASE 1 — Visibility Gating + Confidence Observation

**Goal**: Gate the particle filter update on actual visibility; add a
confidence dimension to the observation so the LSTM knows when it lost track.

**Files touched**: `environments/gym_pursuit_env.py`, `attention_policy.py`

---

### Step 1.1 — Save occlusion centers in meters inside `reset()`

The `reset()` method (line 507-518) already calls either
`env.randomize_occlusions()` or `env.set_fixed_occlusions()` and gets back
`(occ_centers, occ_widths)` in **meters**. We just need to store them as
instance variables so `step()` can access them.

**Where to add** — in `reset()`, right after line 518 (`occ_widths = ...`):

```python
# Store current episode's occlusion geometry in meters for visibility checks
# occ_centers format: flat list [x1, y1, x2, y2, ...]
# occ_widths format:  flat list [w1, w2, ...]
if occ_centers is not None:
    self._occ_centers_m = np.array(occ_centers).reshape(-1, 2)  # shape (N, 2)
    self._occ_widths_m  = np.array(occ_widths)                  # shape (N,)
else:
    self._occ_centers_m = np.empty((0, 2))
    self._occ_widths_m  = np.empty((0,))
```

Also initialise to empty in `__init__()` (before the particle filter block,
after line 53):

```python
self._occ_centers_m = np.empty((0, 2))   # populated each reset()
self._occ_widths_m  = np.empty((0,))
```

---

### Step 1.2 — Add `track_status` list to `__init__()`

Add after the `_occ_centers_m` lines above:

```python
# Track status per target: ACTIVE = currently tracked, LOST = no measurement
self.track_status = [
    {'status': 'ACTIVE', 'last_seen_time': 0.0, 'last_seen_pos': None,
     'lost_time': None}
    for _ in range(self.num_targets)
]
self.prev_track_status = [s.copy() for s in self.track_status]
```

Reset them in `reset()` (after the particle filter reset block, ~line 533):

```python
for s in self.track_status:
    s['status'] = 'ACTIVE'
    s['last_seen_time'] = 0.0
    s['last_seen_pos'] = None
    s['lost_time'] = None
self.prev_track_status = [s.copy() for s in self.track_status]
```

---

### Step 1.3 — Add `_is_in_fov()` method

Add as a new method after `_get_observation()` (after line ~210):

```python
def _is_in_fov(self, target_pos, agent_pos):
    """True if target_pos is within the agent's current FOV radius."""
    return np.linalg.norm(target_pos - agent_pos) <= self.env.fov_size_meters
```

`self.env.fov_size_meters` is updated each episode by `env.randomize_fov()`
(pygame_large_env.py line 281). It ranges from `fov_min` to `fov_max` meters.

---

### Step 1.4 — Add `_is_occluded()` method

Add right after `_is_in_fov()`:

```python
def _is_occluded(self, target_pos):
    """True if target_pos lies inside any occlusion zone (square check)."""
    for (cx, cy), w in zip(self._occ_centers_m, self._occ_widths_m):
        if abs(target_pos[0] - cx) < w / 2 and abs(target_pos[1] - cy) < w / 2:
            return True
    return False
```

The check mirrors the `Occlusions.in_occlusion()` logic already in
`guidance.py`. We replicate it here to avoid importing from the guidance module.

---

### Step 1.5 — Modify `step()` to gate `pf.is_update`

**Current code** (lines 567-588):
```python
# Update particle filters with noisy measurements
target_estimates = []
for i in range(self.num_targets):
    true_target_pos = next_state[1 + i, :2]
    if self.use_particle_filter:
        noisy_measurement = self._add_measurement_noise(true_target_pos)
        pf = self.particle_filters[i]
        pf.is_update = True              # ← always True (the bug)
        pf.pf_loop(noisy_measurement=noisy_measurement, t=self.current_time)
        estimate = pf.weighted_mean.copy()
        target_estimates.append(estimate)
    else:
        ...
```

**Replace the entire `target_estimates` loop** with:

```python
agent_pos = next_state[0, :2]
target_estimates = []
confidences      = []          # one float per target, 0 = lost
visibility_flags = []          # one bool per target (for history + status)

self.prev_track_status = [s.copy() for s in self.track_status]

for i in range(self.num_targets):
    true_target_pos = next_state[1 + i, :2]

    # ── Visibility gate ──────────────────────────────────────────────────
    in_fov  = self._is_in_fov(true_target_pos, agent_pos)
    in_occ  = self._is_occluded(true_target_pos)
    visible = in_fov and not in_occ
    visibility_flags.append(visible)

    # ── Particle filter update ───────────────────────────────────────────
    if self.use_particle_filter:
        noisy_measurement = self._add_measurement_noise(true_target_pos)
        pf = self.particle_filters[i]
        pf.is_update = visible          # ← gated: only update if visible
        pf.pf_loop(noisy_measurement=noisy_measurement, t=self.current_time)
        estimate   = pf.weighted_mean.copy()
        # confidence: PF health [0,1] when visible, 0.0 when lost
        confidence = min(1.0, pf.neff / (0.7 * pf.N)) if visible else 0.0
    else:
        target_state = next_state[1 + i]
        estimate     = np.array([target_state[0], target_state[1],
                                 target_state[3], target_state[4]])
        confidence   = 1.0 if visible else 0.0

    target_estimates.append(estimate)
    confidences.append(confidence)

    # ── Track status transitions ─────────────────────────────────────────
    s = self.track_status[i]
    if visible:
        s['status']         = 'ACTIVE'
        s['last_seen_time'] = self.current_time
        s['last_seen_pos']  = true_target_pos.copy()
    else:
        if s['status'] == 'ACTIVE':       # just lost
            s['status']    = 'LOST'
            s['lost_time'] = self.current_time
```

Then change the observation call (line ~591) to pass confidences:

```python
obs = self._get_observation(next_state[0], target_estimates, confidences)
```

---

### Step 1.6 — Extend observation space (4 → 5 dims per target)

In `__init__()`, change the three observation space definitions:

| Mode | Before | After |
|------|--------|-------|
| `use_attention` | `targets shape=(max_tracked_targets, 4)` | `shape=(max_tracked_targets, 5)` |
| `track_nearest_only` | `obs_dim = 4 + 4` | `obs_dim = 4 + 5` |
| default (all targets) | `obs_dim = 4 + num_targets * 4` | `obs_dim = 4 + num_targets * 5` |

The 5th value per target is the tracking confidence ∈ [0, 1].

---

### Step 1.7 — Modify `_get_observation()` to accept `confidences`

Change the signature:
```python
def _get_observation(self, agent_state, target_estimates, confidences=None):
```

Add at the top of the method body:
```python
if confidences is None:
    confidences = [1.0] * len(target_estimates)
```

**In the `use_attention` branch** — change targets array init and fill loop:
```python
targets_obs = np.zeros((self.max_tracked_targets, 5), dtype=np.float32)

# (keep the sort-by-distance step, but carry confidence in the tuple)
target_data = []
for estimate, conf in zip(target_estimates, confidences):
    distance = np.linalg.norm(estimate[:2] - agent_pos)
    target_data.append((distance, estimate, conf))
target_data.sort(key=lambda x: x[0])

for i, (_, estimate, conf) in enumerate(target_data[:self.max_tracked_targets]):
    if conf > 0.0:
        rel_pos = estimate[:2] - agent_pos
        rel_vel = (estimate[2:4] if len(estimate) >= 4 else np.zeros(2)) - agent_vel
        targets_obs[i] = [rel_pos[0], rel_pos[1], rel_vel[0], rel_vel[1], conf]
    else:
        targets_obs[i] = [0.0, 0.0, 0.0, 0.0, 0.0]   # LSTM uses h_t instead
    mask[i] = 1.0
```

**In the `track_nearest_only` branch**:
```python
# find nearest, keep its confidence
nearest_conf = confidences[self.nearest_target_idx]
if nearest_conf > 0.0:
    rel_pos = nearest_estimate[:2] - agent_pos
    rel_vel = ...
    obs.extend([rel_pos[0], rel_pos[1], rel_vel[0], rel_vel[1], nearest_conf])
else:
    obs.extend([0.0, 0.0, 0.0, 0.0, 0.0])
```

**In the default all-targets branch**:
```python
for estimate, conf in zip(target_estimates, confidences):
    if conf > 0.0:
        rel_pos = estimate[:2] - agent_pos
        rel_vel = ...
        obs.extend([rel_pos[0], rel_pos[1], rel_vel[0], rel_vel[1], conf])
    else:
        obs.extend([0.0, 0.0, 0.0, 0.0, 0.0])
```

---

### Step 1.8 — Fix `AttentionFeatureExtractor` (`attention_policy.py` line 48)

The target encoder is currently hardcoded to 4 inputs:
```python
self.target_encoder = nn.Linear(4, 64)   # ← hardcoded
```

Replace with:
```python
target_feature_dim = observation_space['targets'].shape[-1]  # reads 5 automatically
self.target_encoder = nn.Linear(target_feature_dim, 64)
```

**Test Phase 1**: Instantiate `GymPursuitEnv`, run 100 steps, print
`info['target_visible']` and `info['target_confidences']`. Confirm they flip
to `[False]` / `[0.0]` when you manually place the target outside the FOV
radius or inside an occlusion box.

---

## PHASE 2 — Observation History Buffer

**Goal**: Record every valid observation (visible target) into a circular
buffer that persists across episodes. Phase 3 (GMM) reads from this buffer.

**Files touched**:
- `environments/observation_history.py` ← **new file**
- `environments/gym_pursuit_env.py`

---

### Step 2.1 — Create `environments/observation_history.py`

```python
"""
Cross-episode observation history buffer.
Stores per-target observations in a circular buffer (deque).
Used by the GMM search prior to construct a search distribution
when a target is lost.
"""
import os
import pickle
import numpy as np
from collections import deque


class ObservationHistoryManager:
    """
    Circular buffer of observations per target.

    Each entry stores:
        position  : np.array([x, y])  in meters
        velocity  : np.array([vx, vy]) in m/s
        timestamp : float             within-episode time (seconds)
        episode   : int               episode index (for cross-episode age)

    Persists to disk via pickle so the buffer survives between training runs.
    """

    def __init__(self, num_targets, max_size=1000,
                 save_path='obs_history.pkl'):
        self.num_targets = num_targets
        self.max_size    = max_size
        self.save_path   = save_path
        self.history     = [deque(maxlen=max_size) for _ in range(num_targets)]
        self.load()

    # ── write ────────────────────────────────────────────────────────────

    def add(self, target_id, position, velocity, timestamp, episode):
        """Append one valid observation for target_id."""
        self.history[target_id].append({
            'position':  np.array(position,  dtype=np.float32),
            'velocity':  np.array(velocity,  dtype=np.float32),
            'timestamp': float(timestamp),
            'episode':   int(episode),
        })

    # ── read ─────────────────────────────────────────────────────────────

    def get_positions(self, target_id, last_n=None):
        """
        Return (N, 2) array of recorded positions for target_id.
        Optionally restrict to the most recent `last_n` entries.
        Returns empty array if no observations exist.
        """
        buf = self.history[target_id]
        if last_n is not None:
            buf = list(buf)[-last_n:]
        if len(buf) == 0:
            return np.empty((0, 2), dtype=np.float32)
        return np.array([e['position'] for e in buf], dtype=np.float32)

    def count(self, target_id):
        return len(self.history[target_id])

    # ── persistence ──────────────────────────────────────────────────────

    def save(self):
        with open(self.save_path, 'wb') as f:
            pickle.dump(self.history, f)

    def load(self):
        if os.path.exists(self.save_path):
            try:
                with open(self.save_path, 'rb') as f:
                    loaded = pickle.load(f)
                # Resize deques if num_targets changed
                if len(loaded) == self.num_targets:
                    self.history = [
                        deque(list(d)[-self.max_size:], maxlen=self.max_size)
                        for d in loaded
                    ]
            except Exception:
                pass   # corrupted file → start fresh
```

---

### Step 2.2 — Instantiate in `gym_pursuit_env.__init__()`

Add after the particle filter block (~line 78):

```python
from environments.observation_history import ObservationHistoryManager

self.history_manager = ObservationHistoryManager(
    num_targets=self.num_targets,
    max_size=1000,          # ~100 seconds at dt=0.1
    save_path='obs_history.pkl',
)
```

---

### Step 2.3 — Feed observations inside the `step()` loop

At the end of the per-target `for i in range(self.num_targets)` loop (after
the track status block added in Phase 1), add:

```python
    if visible and self.use_particle_filter:
        true_target_vel = next_state[1 + i, 3:5]
        self.history_manager.add(
            target_id = i,
            position  = true_target_pos,
            velocity  = true_target_vel,
            timestamp = self.current_time,
            episode   = self.episode_count,
        )
```

We record the **true** position (not the noisy estimate) because the history
is used to build a search prior — we want ground truth density, not PF drift.

---

### Step 2.4 — Save history at episode end in `reset()`

In `reset()`, add at the very top (before `self.current_step = 0`):

```python
# Persist history to disk at the start of each episode (= end of previous)
if hasattr(self, 'history_manager'):
    self.history_manager.save()
```

**Test Phase 2**: After running 10 episodes, inspect
`self.history_manager.get_positions(0)`. It should contain ~100–500 rows of
x/y positions clustered around where target 0 actually travelled.

---

## PHASE 3 — GMM Search Prior in Observation

**Goal**: When a target is LOST, construct a Gaussian Mixture Model from its
historical positions and encode the top-3 GMM means as extra entries in the
observation. This gives the agent a learned "where to look" signal.

**Files touched**: `environments/gym_pursuit_env.py`, `attention_policy.py`

---

### Step 3.1 — Add `construct_search_prior()` to `GymPursuitEnv`

```python
def construct_search_prior(self, target_id, n_components=3):
    """
    Fit a GMM to the historical observations of target_id.

    Returns:
        means : (n_components, 2) array of GMM component means, or None
        weights : (n_components,) mixing weights (for ordering)

    Uses road-network nodes as pseudo-observations so the prior
    is sensible even when the buffer is thin.
    """
    from sklearn.mixture import GaussianMixture

    # Historical positions from buffer
    hist_pos = self.history_manager.get_positions(target_id)

    # Road network nodes as pseudo-observations (8 nodes, from pygame env)
    road_nodes = np.array([
        [-1.5,  1.0], [0.0,  1.0], [2.1,  1.0],
        [-1.5, -1.0], [0.0, -1.0], [0.3,  0.0],
        [ 1.7,  0.0], [2.1, -1.0],
    ], dtype=np.float32)

    if len(hist_pos) < 5:
        # Not enough real data → use road nodes only
        positions = road_nodes
    else:
        # Blend: real observations + road nodes (down-weighted)
        # Repeat road nodes once to give them a baseline prior
        positions = np.vstack([hist_pos, road_nodes])

    # Need at least n_components rows
    k = min(n_components, len(positions))
    if k < 1:
        return None, None

    gmm = GaussianMixture(n_components=k, covariance_type='full',
                          max_iter=50, n_init=1)
    try:
        gmm.fit(positions)
    except Exception:
        return None, None

    # Sort components by weight (highest probability first)
    order  = np.argsort(gmm.weights_)[::-1]
    means  = gmm.means_[order]           # (k, 2) in meters
    weights = gmm.weights_[order]
    return means, weights
```

---

### Step 3.2 — Extend the `use_attention` observation space with `search_prior`

In `__init__()`, change the dict observation space:

```python
self.observation_space = spaces.Dict({
    'agent': spaces.Box(low=-np.inf, high=np.inf, shape=(4,), dtype=np.float32),
    'targets': spaces.Box(low=-np.inf, high=np.inf,
                          shape=(max_tracked_targets, 5), dtype=np.float32),
    'mask': spaces.Box(low=0, high=1, shape=(max_tracked_targets,), dtype=np.float32),
    # NEW: relative position of top-3 GMM search hints, flat [rel_x1,rel_y1, ...]
    # Zeros when all targets are tracked (no search needed)
    'search_prior': spaces.Box(low=-np.inf, high=np.inf,
                               shape=(max_tracked_targets * 3 * 2,), dtype=np.float32),
})
```

The shape `(max_tracked_targets * 3 * 2,)` = for each target slot, 3 GMM
means × 2 coordinates. Flat layout: `[t0_m1_x, t0_m1_y, t0_m2_x, ...]`.

---

### Step 3.3 — Fill `search_prior` in `_get_observation()`

In the `use_attention` branch, after building `targets_obs` and `mask`, add:

```python
# Build search prior vector (only meaningful for LOST targets)
search_prior = np.zeros(self.max_tracked_targets * 3 * 2, dtype=np.float32)

for i, (_, estimate, conf) in enumerate(target_data[:self.max_tracked_targets]):
    if conf == 0.0:   # target is LOST
        # Find which target this is (by matching estimate to target_estimates)
        target_idx = target_estimates.index(estimate) \
                     if estimate in target_estimates else None
        if target_idx is not None:
            means, _ = self.construct_search_prior(target_idx, n_components=3)
            if means is not None:
                # Convert to agent-relative coordinates
                rel_means = means - agent_pos   # (k, 2)
                flat = rel_means.flatten()      # (k*2,)
                start = i * 6
                search_prior[start:start + len(flat)] = flat[:6]  # pad/trim to 6

return {
    'agent':        agent_obs,
    'targets':      targets_obs,
    'mask':         mask,
    'search_prior': search_prior,
}
```

For the non-attention modes (flat obs), append the search prior directly to
the vector after the target features:

```python
# Flat obs: append search hints for lost targets
search_flat = []
for i, (estimate, conf) in enumerate(zip(target_estimates, confidences)):
    if conf == 0.0:
        means, _ = self.construct_search_prior(i, n_components=3)
        if means is not None:
            search_flat.extend((means - agent_pos).flatten()[:6])
        else:
            search_flat.extend([0.0] * 6)
    else:
        search_flat.extend([0.0] * 6)   # zeros when tracking is good
obs.extend(search_flat)
```

Update the flat obs_dim in `__init__()`:
```python
# track_nearest_only:  4 + 5 + 6  = 15
# all targets:         4 + num_targets*(5+6) = 4 + num_targets*11
```

---

### Step 3.4 — Update `AttentionFeatureExtractor` for `search_prior`

In `attention_policy.py`, add a `search_encoder` module and process
`observations['search_prior']`:

```python
# In __init__:
search_dim = observation_space['search_prior'].shape[0]   # max_targets*6
self.search_encoder = nn.Sequential(
    nn.Linear(search_dim, 64),
    nn.ReLU(),
    nn.Linear(64, 32),
    nn.ReLU(),
)

# Change output_layer input: 64 (agent) + 64 (targets) + 32 (search) = 160
self.output_layer = nn.Sequential(
    nn.Linear(160, 128),
    nn.ReLU(),
)

# In forward():
search_features = self.search_encoder(observations['search_prior'])  # [B, 32]
combined = torch.cat([agent_features, target_pooled, search_features], dim=-1)
features = self.output_layer(combined)
```

**Test Phase 3**: After running with a deliberately tiny FOV (1.5 m) for 20
episodes, call `env.construct_search_prior(0)`. Plot the returned means on
the road network — they should cluster near road nodes.

---

## PHASE 4 — Reward Engineering

**Goal**: Prevent reward hacking by adding:
1. A penalty whenever a track is lost
2. A bonus when a lost track is re-acquired
3. A curriculum schedule that gradually turns these on

**Files touched**: `environments/gym_pursuit_env.py`

---

### Step 4.1 — Add new reward weights to `__init__()`

After the existing weight block (~line 63):

```python
# Phase 4 reward weights (start at 0, ramp up via curriculum)
self.w_track_continuity = 0.0   # penalty for losing a track
self.w_reacquisition    = 0.0   # bonus for re-acquiring a lost track
```

---

### Step 4.2 — Add curriculum weight update inside `reset()`

After the curriculum_progress computation (~line 489):

```python
# Ramp in Phase-4 reward terms after the agent can track at all
if self.episode_count > 1000:
    ramp = min(1.0, (self.episode_count - 1000) / 4000.0)
    self.w_track_continuity = 0.5 * ramp
    self.w_reacquisition    = 1.0 * ramp
```

Start at episode 1000 (not 0) so the agent first learns basic tracking before
being penalised for losing targets.

---

### Step 4.3 — Add track-status reward terms in `step()`

After the target loop and before the `_compute_reward()` call, add:

```python
# ── Track continuity penalty ──────────────────────────────────────────
track_penalty = 0.0
for i in range(self.num_targets):
    if (self.track_status[i]['status'] == 'LOST' and
            self.prev_track_status[i]['status'] == 'ACTIVE'):
        track_penalty -= 2.0       # one-time penalty: just lost a track
    if self.track_status[i]['status'] == 'LOST':
        time_lost = self.current_time - self.track_status[i]['lost_time']
        track_penalty -= 0.05 * min(time_lost, 20.0)  # continuous penalty

# ── Re-acquisition bonus ──────────────────────────────────────────────
reacq_bonus = 0.0
for i in range(self.num_targets):
    if (self.track_status[i]['status'] == 'ACTIVE' and
            self.prev_track_status[i]['status'] == 'LOST'):
        reacq_bonus += 5.0         # large bonus: just re-acquired a target

# ── Base reward from existing _compute_reward() ───────────────────────
base_reward = self._compute_reward(next_state)

reward = (base_reward
          + self.w_track_continuity * track_penalty
          + self.w_reacquisition    * reacq_bonus)
```

Remove (or skip) the direct `reward = self._compute_reward(next_state)` line
that was there before.

---

### Step 4.4 — Reward monitoring metrics in `info`

Extend the `info` dict in `step()`:

```python
info = {
    ...existing keys...,
    'target_visible':     visibility_flags,
    'target_confidences': confidences,
    'track_penalty':      track_penalty,
    'reacq_bonus':        reacq_bonus,
    'n_lost':             sum(1 for s in self.track_status if s['status']=='LOST'),
}
```

Log `info['n_lost']` during training. If it grows without decreasing, the
agent is not learning to re-acquire — increase `w_reacquisition`.

---

## PHASE 5 — Visualisation

**Goal**: Render green/red indicators on each target (tracked vs lost) and
draw GMM ellipses as search hints.

**Files touched**: `environments/gym_pursuit_env.py` → `render()`,
`environments/pygame_large_env.py`

---

### Step 5.1 — Add `render_tracking_overlay()` to `PygameEnvironment`

In `pygame_large_env.py`, add a new method (can go after `render()`):

```python
def render_tracking_overlay(self, track_status, gmm_means_list,
                             pixels_per_meter, meters_to_pixels_fn):
    """
    Overlay tracking status on the rendered frame.

    Args:
        track_status     : list of dicts from GymPursuitEnv.track_status
        gmm_means_list   : list of (k,2) arrays or None, one per target
        pixels_per_meter : float
        meters_to_pixels_fn : callable(x_m, y_m) → (x_px, y_px)
    """
    import pygame
    for i, status in enumerate(track_status):
        color = (0, 220, 0) if status['status'] == 'ACTIVE' else (220, 0, 0)
        if status['last_seen_pos'] is not None:
            px, py = meters_to_pixels_fn(*status['last_seen_pos'])
            pygame.draw.circle(self.main_surface, color,
                               (int(px), int(py)), 8, width=3)

    # Draw GMM search means for LOST targets
    for i, (status, means) in enumerate(zip(track_status, gmm_means_list)):
        if status['status'] == 'LOST' and means is not None:
            for mean in means:
                px, py = meters_to_pixels_fn(mean[0], mean[1])
                pygame.draw.circle(self.main_surface, (255, 200, 0),
                                   (int(px), int(py)), 5)
```

### Step 5.2 — Call overlay from `GymPursuitEnv.render()`

```python
def render(self):
    if self.render_mode == "human":
        self.env.render()
        # Build GMM means list for overlay
        gmm_means_list = []
        for i in range(self.num_targets):
            if self.track_status[i]['status'] == 'LOST':
                means, _ = self.construct_search_prior(i, n_components=3)
                gmm_means_list.append(means)
            else:
                gmm_means_list.append(None)
        self.env.render_tracking_overlay(
            track_status      = self.track_status,
            gmm_means_list    = gmm_means_list,
            pixels_per_meter  = self.env.pixels_per_meter,
            meters_to_pixels_fn = self.env.meters_to_pixels,
        )
```

---

## IMPLEMENTATION ORDER & TESTING CHECKPOINTS

```
Phase 1 (2 days)
  ├─ Implement Steps 1.1–1.8
  ├─ Test: visibility flags flip correctly
  ├─ Test: obs shape = (max_targets, 5) or 4+num*5
  └─ Test: attention_policy.py instantiates without error

Phase 2 (1 day)
  ├─ Implement Steps 2.1–2.4
  ├─ Test: history_manager.count(0) grows per step
  └─ Test: history persists across python restarts

Phase 3 (2 days)
  ├─ Implement Steps 3.1–3.4
  ├─ Test: construct_search_prior returns sensible means
  └─ Test: obs space includes 'search_prior' key

Phase 4 (1 day)
  ├─ Implement Steps 4.1–4.4
  ├─ Test: info['track_penalty'] is non-zero when n_lost > 0
  └─ Test: info['reacq_bonus'] spikes when track re-acquired

Phase 5 (0.5 day)
  ├─ Implement Steps 5.1–5.2
  └─ Visually verify: green = tracked, red = lost, yellow = GMM hints
```

---

# Visibility-Aware Multi-Target Tracking Implementation Plan

## Executive Summary

Based on your code analysis, I've identified that **NO visibility checking currently exists** in your system. This document provides a detailed implementation plan for visibility-aware particle filtering with multi-hypothesis tracking and cross-episode memory.

---

## 1. CURRENT STATE ANALYSIS

### What Works
✅ Particle filter updates with noisy measurements (line 574 in gym_pursuit_env.py)  
✅ FOV visualization (rendered as blue square, line 506-512 pygame_large_env.py)  
✅ Occlusion randomization (line 270-302 pygame_large_env.py)  
✅ Road network with Markov chain transitions (8 nodes with connectivity mask)

### Critical Gap
❌ **NO VISIBILITY CHECKING EXISTS**  
- Line 568 in gym_pursuit_env.py: `noisy_measurement = self._add_measurement_noise(true_target_pos)`
- **Every target ALWAYS gets a measurement**, even if:
  - Target is outside FOV range
  - Target is occluded by obstacles
  - Target is behind walls

❌ **Particle filters don't know when measurements are invalid**
- Line 572: `pf.is_update = True` is ALWAYS set (hardcoded)
- Should be: `pf.is_update = is_visible`

---

## 2. PROPOSED ARCHITECTURE

### Core Components

```
┌─────────────────────────────────────────────────────┐
│ VISIBILITY CHECKING MODULE (NEW)                    │
│                                                      │
│  check_visibility(agent_pos, target_pos):           │
│    ├─ FOV Check: ||target - agent|| ≤ fov_radius    │
│    ├─ Occlusion Check: ray_cast through obstacles   │
│    └─ return is_visible: bool                       │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ CONDITIONAL PARTICLE FILTER (MODIFIED)              │
│                                                      │
│  if is_visible:                                      │
│    ├─ Update WITH measurement                       │
│    ├─ pf.is_update = True                           │
│    └─ track_status[i] = ACTIVE                      │
│  else:                                               │
│    ├─ Prediction ONLY (no correction)               │
│    ├─ pf.is_update = False                          │
│    └─ track_status[i] = LOST                        │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ OBSERVATION HISTORY BUFFER (NEW)                    │
│                                                      │
│  For each target i:                                  │
│    history[i] = CircularBuffer(max_size=1000)       │
│    ├─ Store: {pos, vel, timestamp, is_valid}        │
│    ├─ Persist across episodes                       │
│    └─ Used for: search prior construction           │
└─────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────┐
│ MULTI-HYPOTHESIS TRACKING (NEW)                     │
│                                                      │
│  When track is LOST:                                 │
│    ├─ Query history buffer for past observations    │
│    ├─ Fit GMM/RBF to historical positions           │
│    ├─ Generate search prior distribution            │
│    └─ Feed to agent as exploration guidance         │
└─────────────────────────────────────────────────────┘
```

---

## 3. IMPLEMENTATION DETAILS

### 3.1 Visibility Checking Module


**Integration Point**: Modify `gym_pursuit_env.py` step() method:

```python
def step(self, action):
    # ... existing code ...
    
    # Update particle filters with conditional visibility
    target_estimates = []
    for i in range(self.num_targets):
        true_target_pos = next_state[1 + i, :2]
        agent_pos = next_state[0, :2]
        
        # NEW: Check visibility
        is_visible = self.env.check_visibility(agent_pos, true_target_pos)
        
        if self.use_particle_filter:
            pf = self.particle_filters[i]
            
            if is_visible:
                # Target is visible: normal update WITH measurement
                noisy_measurement = self._add_measurement_noise(true_target_pos)
                pf.is_update = True
                pf.pf_loop(noisy_measurement=noisy_measurement, t=self.current_time)
                
                # Update track status
                self.track_status[i]['status'] = 'ACTIVE'
                self.track_status[i]['last_seen_time'] = self.current_time
                self.track_status[i]['last_seen_pos'] = true_target_pos.copy()
            else:
                # Target is NOT visible: prediction only (no measurement)
                pf.is_update = False
                pf.pf_loop(noisy_measurement=None, t=self.current_time)
                
                # Update track status
                if self.track_status[i]['status'] == 'ACTIVE':
                    # Just lost track
                    self.track_status[i]['status'] = 'LOST'
                    self.track_status[i]['lost_time'] = self.current_time
                    self.track_status[i]['lost_pos'] = pf.weighted_mean[:2].copy()
            
            estimate = pf.weighted_mean.copy()
            target_estimates.append(estimate)
    
    # ... rest of existing code ...
```

---

### 3.2 Observation History Buffer

**Key Design Decisions**:

1. **Buffer Size**: 1000 steps (as you suggested)
   - At 10 Hz (dt=0.1s), this covers 100 seconds of history
   - Sufficient for most tracking scenarios

2. **What to Store**:
   ```python
   observation = {
       'position': [x, y],           # Target position in meters
       'velocity': [vx, vy],         # Estimated velocity
       'timestamp': t,               # Global timestamp
       'is_valid': bool,             # Was measurement valid?
       'episode_id': episode_num,    # Which episode?
       'agent_pos': [ax, ay],        # Where was agent when observed?
   }
   ```

3. **Persistence**: Store in pickle file, load on startup

**Implementation**:

```python
class ObservationHistoryManager:
    """
    Manages observation history across episodes.
    Stores last N observations per target for search prior construction.
    """
    def __init__(self, num_targets, max_size=1000, save_path='observation_history.pkl'):
        self.num_targets = num_targets
        self.max_size = max_size
        self.save_path = save_path
        
        # Circular buffer per target
        self.history = [deque(maxlen=max_size) for _ in range(num_targets)]
        
        # Load existing history if available
        self.load_history()
    
    def add_observation(self, target_id, position, velocity, timestamp, 
                       is_valid, episode_id, agent_pos):
        """Add observation to history buffer."""
        obs = {
            'position': np.array(position),
            'velocity': np.array(velocity),
            'timestamp': timestamp,
            'is_valid': is_valid,
            'episode_id': episode_id,
            'agent_pos': np.array(agent_pos),
        }
        self.history[target_id].append(obs)
    
    def get_valid_observations(self, target_id, max_age=None):
        """Get all valid observations for a target."""
        valid_obs = [obs for obs in self.history[target_id] if obs['is_valid']]
        
        if max_age is not None:
            current_time = time.time()
            valid_obs = [obs for obs in valid_obs 
                        if current_time - obs['timestamp'] < max_age]
        
        return valid_obs
    
    def save_history(self):
        """Save history to disk."""
        with open(self.save_path, 'wb') as f:
            pickle.dump(self.history, f)
    
    def load_history(self):
        """Load history from disk."""
        if os.path.exists(self.save_path):
            with open(self.save_path, 'rb') as f:
                self.history = pickle.load(f)
```

**Integration**: Add to `gym_pursuit_env.py`:

```python
def __init__(self, ...):
    # ... existing code ...
    
    # NEW: History manager
    self.history_manager = ObservationHistoryManager(
        num_targets=self.num_targets,
        max_size=1000,
        save_path='obs_history.pkl'
    )
    
    # Track status per target
    self.track_status = [
        {
            'status': 'ACTIVE',  # ACTIVE | LOST
            'last_seen_time': 0.0,
            'last_seen_pos': None,
            'lost_time': None,
            'lost_pos': None,
        } 
        for _ in range(self.num_targets)
    ]

def step(self, action):
    # ... after updating particle filters ...
    
    # Add observations to history
    for i in range(self.num_targets):
        true_target_pos = next_state[1 + i, :2]
        true_target_vel = next_state[1 + i, 3:5]
        agent_pos = next_state[0, :2]
        is_valid = (self.track_status[i]['status'] == 'ACTIVE')
        
        self.history_manager.add_observation(
            target_id=i,
            position=true_target_pos,
            velocity=true_target_vel,
            timestamp=self.current_time,
            is_valid=is_valid,
            episode_id=self.episode_count,
            agent_pos=agent_pos
        )
```

---

### 3.3 Search Prior Construction (GMM/RBF)

**Your Proposal**: "Feed history buffer into GMM or RBF to construct searching prior"

**Implementation Options**:

#### Option A: Gaussian Mixture Model (GMM)

```python
from sklearn.mixture import GaussianMixture

def construct_search_prior_gmm(self, target_id, n_components=5):
    """
    Construct search prior using GMM fitted to historical observations.
    
    Args:
        target_id: Which target to construct prior for
        n_components: Number of Gaussian components
    
    Returns:
        gmm: Fitted GMM model
        high_prob_regions: List of (center, covariance) tuples
    """
    # Get valid historical observations
    valid_obs = self.history_manager.get_valid_observations(target_id)
    
    if len(valid_obs) < 10:
        return None, []  # Not enough data
    
    # Extract positions
    positions = np.array([obs['position'] for obs in valid_obs])
    
    # Fit GMM
    gmm = GaussianMixture(n_components=n_components, covariance_type='full')
    gmm.fit(positions)
    
    # Extract high-probability regions (means and covariances)
    high_prob_regions = [
        (gmm.means_[i], gmm.covariances_[i])
        for i in range(n_components)
    ]
    
    return gmm, high_prob_regions
```

**Feeding to Agent**: Add to observation space

```python
def _get_observation_with_search_prior(self, agent_state, target_estimates):
    """
    Enhanced observation with search prior for lost targets.
    """
    obs = self._get_observation(agent_state, target_estimates)  # Base observation
    
    # Add search guidance for lost targets
    search_guidance = []
    for i in range(self.num_targets):
        if self.track_status[i]['status'] == 'LOST':
            # Construct search prior
            gmm, regions = self.construct_search_prior_gmm(i, n_components=3)
            
            if gmm is not None:
                # Sample from GMM to get search locations
                search_samples = gmm.sample(5)[0]  # 5 search locations
                
                # Compute relative positions to agent
                agent_pos = agent_state[:2]
                rel_search = search_samples - agent_pos
                
                search_guidance.append({
                    'target_id': i,
                    'search_locations': rel_search,
                    'uncertainty': np.mean([np.trace(cov) for _, cov in regions])
                })
    
    # Option 1: Concatenate to observation vector
    if len(search_guidance) > 0:
        # Flatten and add to obs
        pass
    
    # Option 2: Use separate observation key (for dict obs space)
    obs['search_prior'] = search_guidance
    
    return obs
```

#### Option B: Radial Basis Function (RBF) Network

```python
class RBFSearchPrior:
    """
    RBF-based search prior that learns density of historical observations.
    """
    def __init__(self, centers=None, widths=None):
        self.centers = centers  # RBF centers
        self.widths = widths    # RBF widths
    
    def fit(self, positions, n_centers=10):
        """
        Fit RBF network to historical positions using k-means clustering.
        
        Args:
            positions: (N, 2) array of historical positions
            n_centers: Number of RBF centers
        """
        from sklearn.cluster import KMeans
        
        # Use k-means to find RBF centers
        kmeans = KMeans(n_clusters=n_centers)
        kmeans.fit(positions)
        
        self.centers = kmeans.cluster_centers_
        
        # Compute widths based on nearest neighbor distances
        from sklearn.neighbors import NearestNeighbors
        nbrs = NearestNeighbors(n_neighbors=2).fit(self.centers)
        distances, _ = nbrs.kneighbors(self.centers)
        self.widths = distances[:, 1]  # Distance to nearest center
    
    def evaluate(self, positions):
        """
        Evaluate search prior at given positions.
        
        Returns:
            scores: (N,) array of prior probabilities
        """
        positions = np.atleast_2d(positions)
        
        # Compute RBF activations
        scores = np.zeros(len(positions))
        for center, width in zip(self.centers, self.widths):
            dist = np.linalg.norm(positions - center, axis=1)
            scores += np.exp(-(dist**2) / (2 * width**2))
        
        # Normalize
        scores = scores / np.sum(scores)
        return scores
    
    def sample(self, n_samples):
        """Sample search locations from RBF prior."""
        # Sample from centers with noise
        samples = []
        for _ in range(n_samples):
            # Pick random center
            idx = np.random.randint(len(self.centers))
            center = self.centers[idx]
            width = self.widths[idx]
            
            # Add Gaussian noise
            sample = center + np.random.randn(2) * width
            samples.append(sample)
        
        return np.array(samples)
```

**Recommendation**: **Use GMM** for search prior
- More interpretable (explicit Gaussian components)
- Better handles multi-modal distributions (targets on road network)
- Easier to visualize and debug
- RBF is better for continuous density estimation, but GMM is sufficient here

---

## 4. REWARD HACKING CONCERNS

### Current Reward Structure

From your code (line 59-65):
```python
self.reward_mode = reward_mode  # 'distance', 'ospa', 'ospa_info'
self.ospa_cutoff = ospa_cutoff
self.ospa_order = ospa_order
self.w_localization = 1.0   # Weight for localization error
self.w_cardinality = 0.5    # Weight for cardinality error
self.w_info = 0.5           # Weight for information gain
```

### Potential Reward Hacking Scenarios

#### Scenario 1: "Sensor Peek-a-Boo"
**Problem**: Agent learns to:
1. Move close to target (get measurement, low OSPA error)
2. Move away slightly to let target escape FOV
3. Repeat Step 1

**Why it happens**: 
- Agent gets reward for "tracking" even if track is frequently lost
- No penalty for losing track, only for poor localization when visible

**Fix**:
```python
# Add track continuity reward
track_continuity_bonus = 0.0
for i in range(self.num_targets):
    if self.track_status[i]['status'] == 'ACTIVE':
        time_tracked = self.current_time - self.track_status[i].get('last_lost_time', 0)
        track_continuity_bonus += 0.1 * min(time_tracked, 10.0)  # Cap at 10 seconds

reward += track_continuity_bonus
```

#### Scenario 2: "Nearest Target Only"
**Problem**: Agent focuses on 1-2 nearest targets, ignores others

**Fix**: Use OSPA with proper cardinality weighting
```python
# Already in your code, but ensure w_cardinality is high enough
self.w_cardinality = 1.0  # Increase from 0.5 to 1.0
```

#### Scenario 3: "Static Camping"
**Problem**: Agent finds "sweet spot" where it can see multiple targets and doesn't move

**Why it happens**:
- OSPA rewards good localization, not tracking quality
- No incentive to reduce uncertainty when already tracking

**Fix**: Add exploration/uncertainty reduction bonus
```python
# Already in your code (line 429-460): information gain reward
# But strengthen it:
self.w_info = 1.0  # Increase from 0.5
```

#### Scenario 4: "Lost Track Ignore"
**Problem**: When target is lost, agent gives up and focuses on visible targets

**Fix**: Add re-acquisition reward
```python
# Reward for re-acquiring lost tracks
reacquisition_bonus = 0.0
for i in range(self.num_targets):
    if (self.track_status[i]['status'] == 'ACTIVE' and 
        self.prev_track_status[i]['status'] == 'LOST'):
        # Just re-acquired a lost target!
        reacquisition_bonus += 5.0  # Large bonus

reward += reacquisition_bonus
```

### Recommended Reward Structure

```python
def _compute_reward(self, state):
    """
    Comprehensive reward function that prevents reward hacking.
    
    Components:
    1. OSPA: Localization + cardinality error
    2. Information gain: Reduce uncertainty
    3. Track continuity: Penalize losing tracks
    4. Re-acquisition: Reward finding lost targets
    5. Search efficiency: Penalize excessive movement when searching
    """
    reward = 0.0
    
    # 1. Base OSPA (existing code, lines 215-287)
    ospa_reward = self._compute_ospa_reward(state)
    reward += self.w_localization * ospa_reward
    
    # 2. Information gain (existing code, lines 429-460)
    info_gain = self._compute_information_gain(state)
    reward += self.w_info * info_gain
    
    # 3. Track continuity penalty (NEW)
    track_loss_penalty = 0.0
    for i in range(self.num_targets):
        if (self.track_status[i]['status'] == 'LOST' and 
            self.prev_track_status[i]['status'] == 'ACTIVE'):
            # Just lost a track
            track_loss_penalty -= 2.0
        
        # Continuous penalty for having lost tracks
        if self.track_status[i]['status'] == 'LOST':
            time_lost = self.current_time - self.track_status[i]['lost_time']
            track_loss_penalty -= 0.1 * min(time_lost, 20.0)
    
    reward += track_loss_penalty
    
    # 4. Re-acquisition bonus (NEW)
    reacquisition_bonus = 0.0
    for i in range(self.num_targets):
        if (self.track_status[i]['status'] == 'ACTIVE' and 
            self.prev_track_status[i]['status'] == 'LOST'):
            reacquisition_bonus += 5.0  # Large bonus for re-acquiring
    
    reward += reacquisition_bonus
    
    # 5. Search efficiency (NEW) - penalize wasted movement when searching
    if any(status['status'] == 'LOST' for status in self.track_status):
        # Agent is searching for lost targets
        # Penalize movement that doesn't increase coverage of search prior
        movement_cost = -0.01 * np.linalg.norm(state[0, 3:5])  # Velocity magnitude
        reward += movement_cost
    
    return reward
```

### Balancing Weights

**Initial Recommendations**:
```python
self.w_localization = 1.0    # Base tracking performance
self.w_cardinality = 1.0     # Increase to prevent ignoring targets
self.w_info = 0.8            # Encourage uncertainty reduction
self.w_track_continuity = 0.5  # Penalize losing tracks
self.w_reacquisition = 1.0   # Strong incentive to find lost targets
self.w_search_efficiency = 0.2  # Weak penalty, just to prevent thrashing
```

**Curriculum Schedule**:
```python
# Early training: Focus on basic tracking
if self.episode_count < 1000:
    self.w_localization = 1.0
    self.w_info = 0.3
    self.w_track_continuity = 0.2

# Mid training: Add track continuity
elif self.episode_count < 5000:
    self.w_localization = 1.0
    self.w_info = 0.6
    self.w_track_continuity = 0.5

# Late training: Full complexity
else:
    self.w_localization = 1.0
    self.w_info = 0.8
    self.w_track_continuity = 0.8
    self.w_reacquisition = 1.0
```

---

## 5. INTEGRATION ROADMAP

### Phase 1: Visibility Checking (1-2 days)
- [ ] Implement `check_visibility()` in `pygame_large_env.py`
- [ ] Implement `_line_intersects_circle()` helper
- [ ] Modify `gym_pursuit_env.step()` to use visibility
- [ ] Test: Verify measurements are blocked when occluded/out-of-FOV
- [ ] Visualize: Add red/green indicators for visible/invisible targets

### Phase 2: Conditional Particle Filter (1 day)
- [ ] Add `track_status` data structure to `gym_pursuit_env`
- [ ] Modify particle filter update to check `pf.is_update` flag
- [ ] Verify: Particle clouds spread out when track is lost
- [ ] Test: Track covariance increases over time when no measurement

### Phase 3: Observation History (2-3 days)
- [ ] Implement `ObservationHistoryManager` class
- [ ] Integrate into `gym_pursuit_env`
- [ ] Add save/load functionality
- [ ] Test: Verify history persists across episodes
- [ ] Verify: 1000 observations = ~100 seconds of history

### Phase 4: Search Prior (3-4 days)
- [ ] Implement GMM-based search prior
- [ ] Add search prior to observation space
- [ ] Modify policy network to accept search guidance
- [ ] Test: Verify GMM captures road network structure
- [ ] Visualize: Plot GMM components on road network

### Phase 5: Reward Engineering (2-3 days)
- [ ] Add track continuity penalty
- [ ] Add re-acquisition bonus
- [ ] Add search efficiency penalty
- [ ] Tune reward weights
- [ ] Run ablation studies

### Phase 6: Training & Evaluation (ongoing)
- [ ] Train with curriculum learning
- [ ] Monitor for reward hacking behaviors
- [ ] Evaluate on held-out scenarios (new occlusions, FOVs)
- [ ] Compare vs baselines (no history, no search prior)

---

## 6. ADDRESSING YOUR SPECIFIC QUESTIONS

### Q1: "Store past observations and feed to agent - will this cause agent to search around road network?"

**Answer**: YES, but with caveats.

**Why it works**:
- Road network has ~8 nodes (from your code, line 140-149)
- Targets follow Markov chain on this network
- Historical observations will cluster around these nodes
- GMM will learn multi-modal distribution with peaks at nodes
- Agent receives "hints" about where targets tend to be

**Why it might not work perfectly**:
- If agent only sees targets at random nodes, GMM might not capture full network structure
- Need sufficient exploration to observe all nodes
- Targets can be anywhere between nodes (not just at nodes)

**Solution**: Augment observation history with **road network topology**
```python
# Load road network structure
self.road_network_nodes = np.array([
    [-1.5, 1], [0, 1], [2.1, 1], [-1.5, -1],
    [0, -1], [0.3, 0], [1.7, 0], [2.1, -1]
])

# When constructing search prior, blend historical obs + network nodes
def construct_hybrid_search_prior(self, target_id):
    # Historical observations
    valid_obs = self.history_manager.get_valid_observations(target_id)
    positions = np.array([obs['position'] for obs in valid_obs])
    
    # Add road network nodes as "pseudo-observations"
    positions = np.vstack([positions, self.road_network_nodes])
    
    # Fit GMM
    gmm = GaussianMixture(n_components=8)  # One per node
    gmm.fit(positions)
    
    return gmm
```

### Q2: "Should we talk more about reward hacking?"

**Answer**: See Section 4 above. Key anti-hacking strategies:

1. **Track loss penalty**: -2.0 per lost track + continuous -0.1/sec
2. **Re-acquisition bonus**: +5.0 for finding lost target
3. **Search efficiency**: Penalize wasted movement when searching
4. **Curriculum weights**: Gradually increase complexity

**Monitoring for reward hacking**:
```python
# Log these metrics during training
metrics = {
    'avg_track_duration': [],  # How long tracks last before loss
    'reacquisition_rate': [],  # How often lost tracks are re-acquired
    'search_time': [],         # Time spent searching vs tracking
    'coverage': [],            # What fraction of environment is explored
}

# Red flags:
# - avg_track_duration decreases over training (peek-a-boo)
# - reacquisition_rate near 0 (ignoring lost targets)
# - coverage < 50% of environment (not exploring)
```

### Q3: "Max observation history length = 1000 steps?"

**Answer**: 1000 is reasonable, but consider:

**Storage cost**:
```python
# Per observation: ~100 bytes (position, velocity, timestamp, etc.)
# Per target: 1000 obs × 100 bytes = 100 KB
# For 10 targets: 1 MB
# Across episodes: can grow large
```

**Recommendation**:
- Start with 1000 steps (100 seconds at dt=0.1)
- If memory is an issue, reduce to 500 steps (50 seconds)
- If you want longer memory, increase to 2000 steps (200 seconds)

**Alternative**: **Adaptive buffer size**
```python
# Keep last N observations OR last T seconds, whichever is larger
max_observations = 1000
max_time_window = 120.0  # seconds

def should_keep_observation(obs, current_time):
    time_since = current_time - obs['timestamp']
    return (time_since < max_time_window) or (len(history) < max_observations)
```

---

## 7. EXPECTED BEHAVIOR AFTER IMPLEMENTATION

### Before (Current State)
```
Agent → Target goes out of FOV → Still gets "measurement" (noise) 
     → Particle filter thinks it knows where target is
     → Agent doesn't search (no incentive)
     → Track diverges from reality
```

### After (With Visibility + History + Search Prior)
```
Agent → Target goes out of FOV → No measurement received
     → Particle filter: prediction only, uncertainty increases
     → Agent: "Lost track, consult history for likely locations"
     → Search prior: "Target was often seen at nodes [1, 4, 5]"
     → Agent moves toward high-probability search regions
     → Re-acquires target → Large reward bonus
```

### Visualization Example
```
[After 100 episodes of training]

Road Network:
   0 ─── 1 ─── 2
   │     │     │
   3 ─── 4 ─── 7
         │
         5 ─── 6

Historical Observations (Heatmap):
   ●●●   ●●●   ●●
   ●     ●●    ●
   ●●●   ●●●●  ●●
         ●●●
         ●●●   ●●

GMM Components (Search Prior):
   [μ₁]  [μ₂]  [μ₃]
   [μ₄]  [μ₅]  [μ₇]
         [μ₆]
         [μ₈]

→ Agent learns: "When I lose a target, search around these nodes first"
```

---

## 8. TESTING CHECKLIST

### Unit Tests
- [ ] `check_visibility()`: Test FOV distance cutoff
- [ ] `check_visibility()`: Test occlusion blocking
- [ ] `_line_intersects_circle()`: Test edge cases (tangent, miss, hit)
- [ ] `ObservationHistoryManager`: Test buffer overflow
- [ ] `ObservationHistoryManager`: Test save/load
- [ ] GMM search prior: Test fitting with <10 observations
- [ ] GMM search prior: Test sampling

### Integration Tests
- [ ] Particle filter: Verify covariance grows when `is_update=False`
- [ ] Particle filter: Verify convergence when `is_update=True`
- [ ] Track status: Verify ACTIVE ↔ LOST transitions
- [ ] Search prior: Verify GMM components align with road network
- [ ] Reward: Verify no degenerate policies (peek-a-boo, camping)

### End-to-End Tests
- [ ] Train for 1000 episodes with visibility disabled → baseline performance
- [ ] Train for 1000 episodes with visibility enabled → improved performance?
- [ ] Evaluate on scenarios with:
  - [ ] Targets always visible (should match baseline)
  - [ ] Targets frequently occluded (should outperform baseline)
  - [ ] Multiple targets lost simultaneously (stress test)

---

## 9. COMMON PITFALLS & SOLUTIONS

### Pitfall 1: "GMM doesn't capture road network"
**Cause**: Not enough observations, or observations too noisy  
**Solution**: Add road network nodes as "pseudo-observations" (see Q1 above)

### Pitfall 2: "Agent ignores search prior"
**Cause**: Search prior not salient in observation space  
**Solution**: Normalize search prior positions, add attention mechanism

### Pitfall 3: "Particle filter diverges when track is lost"
**Cause**: Process noise too low, particles don't spread enough  
**Solution**: Increase `proc_vel_std` in ParticleFilter.py (line 105)

### Pitfall 4: "Agent thrashes when searching"
**Cause**: Search locations change every step  
**Solution**: Commit to search location for T steps before re-planning

### Pitfall 5: "Training collapses after adding new reward terms"
**Cause**: Reward scales are mismatched  
**Solution**: Use reward normalization:
```python
reward_components = {
    'ospa': ospa_reward,
    'info_gain': info_gain,
    'track_loss': track_loss_penalty,
    'reacquisition': reacquisition_bonus,
}

# Normalize each component to [-1, 1] range
normalized_reward = sum(
    w * np.clip(r, -1, 1) 
    for (r, w) in zip(reward_components.values(), weights)
)
```

---

## 10. NEXT STEPS

1. **Start with Phase 1** (Visibility Checking)
   - This is the critical foundation
   - Test extensively before moving on

2. **Validate with simple scenarios first**
   - Single target, no occlusions → should match baseline
   - Single target, with occlusions → should show improvement

3. **Gradually add complexity**
   - Phase 2 (Conditional PF) → Phase 3 (History) → Phase 4 (Search Prior)
   - Train after each phase to verify no regressions

4. **Monitor metrics throughout**
   - Track loss frequency
   - Re-acquisition success rate
   - Search efficiency
   - Coverage of environment

5. **Iterate on reward weights**
   - Start conservative (small penalties/bonuses)
   - Increase gradually based on observed behaviors

---

## APPENDIX A: Code Structure After Implementation

```
gym_pursuit_env.py
├─ __init__()
│  ├─ Initialize particle filters
│  ├─ Initialize history manager ← NEW
│  └─ Initialize track status ← NEW
│
├─ step()
│  ├─ Execute action
│  ├─ Check visibility for each target ← NEW
│  ├─ Conditional PF update (vis-dependent) ← MODIFIED
│  ├─ Update track status ← NEW
│  ├─ Add to observation history ← NEW
│  ├─ Compute reward (with new terms) ← MODIFIED
│  └─ Return observation + search prior ← MODIFIED
│
├─ _compute_reward() ← MODIFIED
│  ├─ OSPA localization
│  ├─ Information gain
│  ├─ Track continuity penalty ← NEW
│  ├─ Re-acquisition bonus ← NEW
│  └─ Search efficiency ← NEW
│
├─ _get_observation() ← MODIFIED
│  ├─ Base observation
│  └─ Add search prior for lost targets ← NEW
│
└─ construct_search_prior_gmm() ← NEW
   ├─ Query history manager
   ├─ Fit GMM to observations + road network
   └─ Return search locations

pygame_large_env.py
├─ check_visibility() ← NEW
│  ├─ FOV distance check
│  └─ Occlusion ray-casting
│
└─ _line_intersects_circle() ← NEW

observation_history.py ← NEW FILE
└─ ObservationHistoryManager
   ├─ add_observation()
   ├─ get_valid_observations()
   ├─ save_history()
   └─ load_history()
```

---

## APPENDIX B: Visualization Recommendations

Add to `render()` method in `pygame_large_env.py`:

```python
def render_tracking_status(self, track_status, search_priors=None):
    """
    Visualize tracking status and search priors.
    
    Args:
        track_status: List of track status dicts
        search_priors: List of GMM search prior objects
    """
    for i, status in enumerate(track_status):
        target_pos_pixels = self.meters_to_pixels(
            self.targets[i].body.position[0], 
            self.targets[i].body.position[1]
        )
        
        # Draw status indicator
        if status['status'] == 'ACTIVE':
            color = (0, 255, 0)  # Green = tracked
        else:
            color = (255, 0, 0)  # Red = lost
        
        pygame.draw.circle(
            self.main_surface, 
            color, 
            (int(target_pos_pixels[0]), int(target_pos_pixels[1])), 
            5
        )
        
        # Draw search prior if available
        if search_priors is not None and status['status'] == 'LOST':
            gmm = search_priors[i]
            if gmm is not None:
                # Draw GMM components as ellipses
                for j in range(gmm.n_components):
                    mean = gmm.means_[j]
                    cov = gmm.covariances_[j]
                    
                    mean_pixels = self.meters_to_pixels(mean[0], mean[1])
                    
                    # Eigenvalues for ellipse size
                    eigenvalues, eigenvectors = np.linalg.eig(cov)
                    angle = np.arctan2(eigenvectors[1, 0], eigenvectors[0, 0])
                    
                    # Draw semi-transparent ellipse
                    width = int(2 * np.sqrt(eigenvalues[0]) * self.pixels_per_meter)
                    height = int(2 * np.sqrt(eigenvalues[1]) * self.pixels_per_meter)
                    
                    pygame.draw.ellipse(
                        self.main_surface,
                        (255, 255, 0, 100),  # Yellow with alpha
                        pygame.Rect(
                            int(mean_pixels[0] - width/2),
                            int(mean_pixels[1] - height/2),
                            width, height
                        ),
                        width=2
                    )
```

---

## FINAL THOUGHTS

Your proposed approach is **sound and well-motivated**:

✅ **Visibility checking**: Essential for realistic tracking  
✅ **Cross-episode history**: Leverages road network structure  
✅ **GMM search prior**: Good choice for multi-modal distributions  
✅ **1000-step buffer**: Reasonable balance of memory and coverage

**Key success factors**:
1. Implement incrementally (phases 1-6)
2. Test each component in isolation
3. Monitor for reward hacking (Section 4)
4. Visualize search priors to verify they capture road network
5. Use curriculum learning to gradually increase difficulty

**Biggest risk**: Reward hacking via "peek-a-boo" or "camping"  
**Mitigation**: Track continuity penalties + re-acquisition bonuses

Good luck with implementation! Let me know if you have questions on any specific component.