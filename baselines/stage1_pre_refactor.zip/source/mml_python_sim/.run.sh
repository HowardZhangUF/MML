#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

N_RUNS="${1:-100}"
N_STEPS="${2:-2000}"
TIMESTAMP="$(date +"%Y%m%d_%H%M%S")"
OUTPUT_DIR="${3:-$ROOT_DIR/benchmark_results_${TIMESTAMP}}"
PYTHON_BIN="${PYTHON_BIN:-python}"
GUIDANCE_MODE="MultiPFInfo"
INITIAL_TARGET_MODE="visible"
METHODS=("MultiPFVel" "MultiPFTra")
BASE_SEED=1000
TRANSFORMER_CHECKPOINT="$ROOT_DIR/src/mml_guidance/mml_guidance/mml_network/models/best_noisy_5_v2_velocities_occlusions_ScratchTransformer.pth"

if [[ ! -f "$TRANSFORMER_CHECKPOINT" ]]; then
    echo "Transformer checkpoint not found: $TRANSFORMER_CHECKPOINT" >&2
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
OUTPUT_DIR="$(cd "$OUTPUT_DIR" && pwd)"

# Batch execution must not depend on a desktop session. CPU-only execution is
# intentional on this workstation and makes runtime measurements reproducible.
export SDL_VIDEODRIVER=dummy
export SDL_AUDIODRIVER=dummy
export CUDA_VISIBLE_DEVICES=""
export PYTHONUNBUFFERED=1

echo "============================================================"
echo "Full-system PF baseline benchmark"
echo "Methods          : ${METHODS[*]}"
echo "Guidance mode    : $GUIDANCE_MODE"
echo "Initial targets  : $INITIAL_TARGET_MODE"
echo "Runs per method  : $N_RUNS"
echo "Steps per run    : $N_STEPS"
echo "Seed schedule    : ${BASE_SEED}..$((BASE_SEED + N_RUNS - 1))"
echo "Checkpoint       : $TRANSFORMER_CHECKPOINT"
echo "Python           : $PYTHON_BIN"
echo "Output directory : $OUTPUT_DIR"
echo "============================================================"

for method in "${METHODS[@]}"; do
    method_dir="$OUTPUT_DIR/$method"
    mkdir -p "$method_dir"

    echo
    echo "--- Method: $method ---"
    for ((run=0; run<N_RUNS; run++)); do
        run_number=$((run + 1))
        seed=$((BASE_SEED + run))
        log_path="$method_dir/${method}_run$(printf '%03d' "$run")_seed${seed}.log"

        command=(
            "$PYTHON_BIN" scripts/info_mml_main.py
            --guidance_mode "$GUIDANCE_MODE"
            --prediction_method "$method"
            --run_number "$run"
            --seed "$seed"
            --num_steps "$N_STEPS"
            --benchmark_metrics
            --no_fan
            --headless
            --initial_target_mode "$INITIAL_TARGET_MODE"
            --output_dir "$method_dir"
        )
        if [[ "$method" == "MultiPFTra" ]]; then
            command+=(--model_path "$TRANSFORMER_CHECKPOINT")
        fi

        printf "Run %3d/%d  seed=%d ... " "$run_number" "$N_RUNS" "$seed"
        if "${command[@]}" >"$log_path" 2>&1; then
            echo "done"
        else
            echo "FAILED"
            tail -n 80 "$log_path" >&2
            exit 1
        fi
    done
done

"$PYTHON_BIN" scripts/aggregate_full_system_benchmark.py \
    --input "$OUTPUT_DIR" \
    --expected-runs "$N_RUNS"

echo
echo "============================================================"
echo "Benchmark complete"
echo "Results: $OUTPUT_DIR"
echo "============================================================"
