# Four-experiment paper suite

This suite keeps the evidence levels separate:

1. `run_experiment1_distribution.py` evaluates motion distributions without a PF.
2. `run_experiment2_occlusion.py` uses one common bootstrap PF and scheduled measurement blackouts.
3. `run_experiment3_runtime.py` measures quality and TRR at different sampling budgets.
4. `run_experiment4_active.py` invokes the full `info_mml_main.py` multi-target simulation.

The first three experiments use the same adapters for PF+CV, offline PF+DMMN,
PF+Diffusion, PF+NF, PF+CFM-fixed, and PF+CFM-adaptive. Adaptive CFM is excluded
from Experiment 1 because measurement age is undefined outside a tracker.

## Environment

```bash
conda activate tracking_ppo
cd ~/mml_python_sim
```

## Experiment 1

```bash
python scripts/run_experiment1_distribution.py \
  --contexts-per-scenario 120 \
  --samples 1000 \
  --horizon 40 \
  --output-dir experiment_results/experiment1_distribution
```

Outputs include `per_context_metrics.csv`, `metric_table.csv`,
`metric_table.tex`, and `branch_probability_plots.png`.

Branch JSD includes off-road mass as an additional category. Energy Distance is
computed on flattened future trajectories rather than endpoints alone.
Deterministic CV and DMMN predictions are repeated exactly 1,000 times, as
required by the protocol.

## Experiment 2

```bash
python scripts/run_experiment2_occlusion.py \
  --road-types straight two_way three_way \
  --gap-lengths 0,10,20,40,60 \
  --episodes-per-cell 40 \
  --particles 250 \
  --output-dir experiment_results/experiment2_occlusion
```

This creates 600 paired episodes. For each nonzero gap, the measurement is
removed for exactly the scheduled updates while target motion continues. The
same stored truth, sensor path, noisy observations, and mask are used by every
method. They are saved in `prerecorded_trajectories.csv`.

`TRR` is successful events divided by scheduled nonzero-gap events. A success
requires error below 0.30 m for three consecutive updates, with streak onset no
later than 20 updates after reappearance. Failures receive latency score 21.
Zero-gap controls are excluded from TRR, MORT, and recovery latency.

## Experiment 3

```bash
python scripts/run_experiment3_runtime.py \
  --cfm-nfe 1,2,5,10,20,50 \
  --diffusion-steps 1,2,5,10,20 \
  --particles 250 \
  --output-dir experiment_results/experiment3_runtime
```

Outputs include `quality_runtime_table.csv`, its LaTeX form, and
`quality_runtime_tradeoff.png`. Timing uses warm-up calls and device
synchronization. The diffusion sweep uses reduced-step DDIM and does not alter
the checkpoint's trained noise schedule.

## Experiment 4

All six motion methods under both predefined and information guidance (12
configurations):

```bash
python scripts/run_experiment4_active.py \
  --runs 100 \
  --steps 2000 \
  --output-dir experiment_results/experiment4_active
```

The compact six-configuration table from the original plan is:

```bash
python scripts/run_experiment4_active.py \
  --runs 100 \
  --steps 2000 \
  --methods PF+CV PF+CFM-fixed PF+CFM-adaptive \
  --output-dir experiment_results/experiment4_active_compact
```

`Predefined` is a fixed lawnmower sensor path that never reacts to detections.
`information` maps to `MultiPFInfo`. The primary output is OSPA with cutoff
`c=1.5` m and order `p=2`; supporting outputs include cardinality error,
track-loss rate, localization RMSE, and tracking Hz.

Resume an interrupted full-system run with `--skip-existing`.

## Run all four

Paper settings:

```bash
./scripts/run_all_four_experiments.sh experiment_results/paper_suite paper
```

Fast end-to-end validation:

```bash
./scripts/run_all_four_experiments.sh /tmp/mml_suite_smoke smoke
```

Set a specific interpreter when needed:

```bash
PYTHON_BIN="$CONDA_PREFIX/bin/python" \
  ./scripts/run_all_four_experiments.sh experiment_results/paper_suite paper
```

## Analyze existing Experiments 1-3

This command uses the existing raw CSV files and does not rerun a model,
tracker, or simulator:

```bash
python scripts/analyze_experiments_1_to_3.py \
  --input-root experiment_results/paper_suite \
  --output-dir experiment_results/paper_suite/analysis_existing
```

It produces paired statistical comparisons, bootstrap/Wilson confidence
intervals, adaptive-sigma effects, global and learned-only Pareto frontiers,
figures, LaTeX tables, a data audit, and `EVALUATION_REPORT.md`.

Every experiment writes `PROTOCOL.md` beside its results. Paper claims should
be based on the paired raw CSV files, `paired_tests_*.csv`, and 95% confidence
intervals, not only the aggregate means. Controlled experiments reset each
method to the same episode seed and reuse the same measurements. To call
generated contexts strictly held out, archive the training-data manifest and
verify that its trajectory/topology identifiers do not occur in the test
manifest.
