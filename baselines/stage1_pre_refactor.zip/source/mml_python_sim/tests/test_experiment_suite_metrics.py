from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from experiment_suite_common import jensen_shannon, recovery_from_errors
from metrics import optimal_subpattern_assignment_distance


class ExperimentSuiteMetricTests(unittest.TestCase):
    def test_jsd_identity_and_disjoint_support(self):
        self.assertAlmostEqual(jensen_shannon([0.5, 0.5], [0.5, 0.5]), 0.0)
        self.assertAlmostEqual(jensen_shannon([1.0, 0.0], [0.0, 1.0]), 1.0)

    def test_recovery_success_and_failure_cap(self):
        errors = np.array([1.0, 0.2, 0.1, 0.1, 0.9])
        success, mort, capped = recovery_from_errors(
            errors, reappearance=1, threshold=0.3, streak=3, deadline=2
        )
        self.assertTrue(success)
        self.assertEqual(mort, 0.0)
        self.assertEqual(capped, 0.0)

        success, mort, capped = recovery_from_errors(
            np.ones(8), reappearance=1, threshold=0.3, streak=3, deadline=2
        )
        self.assertFalse(success)
        self.assertTrue(np.isnan(mort))
        self.assertEqual(capped, 3.0)

    def test_standard_ospa_localization_and_cardinality(self):
        truth = np.array([[0.0, 0.0], [1.0, 0.0]])
        exact = truth.copy()
        self.assertAlmostEqual(
            optimal_subpattern_assignment_distance(truth, exact), 0.0
        )
        self.assertAlmostEqual(
            optimal_subpattern_assignment_distance(truth, np.empty((0, 2))),
            1.5,
        )
        expected = np.sqrt((0.0 + 1.5**2) / 2.0)
        self.assertAlmostEqual(
            optimal_subpattern_assignment_distance(truth, truth[:1]), expected
        )


if __name__ == "__main__":
    unittest.main()
