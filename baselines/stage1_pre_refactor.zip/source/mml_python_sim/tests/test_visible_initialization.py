from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.experiment_initialization import (
    sample_visible_initial_target_positions,
)


class VisibleInitializationTests(unittest.TestCase):
    agent_position = np.array([1.5, -0.5])
    fov_dims = np.array([1.5, 1.5])
    occlusion_centers = np.array([1.8, 0.0, 1.2, 0.8]).reshape(-1, 2)
    occlusion_widths = np.array([1.0, 1.0])

    @staticmethod
    def initialization_rng(seed):
        return np.random.default_rng(
            np.random.SeedSequence([seed, 0x4954464F])
        )

    def test_all_benchmark_seeds_produce_two_visible_targets(self):
        for seed in range(1000, 1100):
            with self.subTest(seed=seed):
                positions = sample_visible_initial_target_positions(
                    agent_position=self.agent_position,
                    fov_dims=self.fov_dims,
                    number_targets=2,
                    occlusion_centers=self.occlusion_centers,
                    occlusion_widths=self.occlusion_widths,
                    rng=self.initialization_rng(seed),
                )

                self.assertTrue(
                    np.all(positions > self.agent_position - self.fov_dims / 2.0)
                )
                self.assertTrue(
                    np.all(positions < self.agent_position + self.fov_dims / 2.0)
                )
                self.assertGreaterEqual(
                    np.linalg.norm(positions[0] - positions[1]),
                    0.35,
                )

                for position in positions:
                    self.assertGreaterEqual(
                        np.linalg.norm(position - self.agent_position),
                        0.35,
                    )
                    self.assertFalse(
                        any(
                            np.all(
                                np.abs(position - center)
                                <= width / 2.0 + 0.05
                            )
                            for center, width in zip(
                                self.occlusion_centers,
                                self.occlusion_widths,
                            )
                        )
                    )

    def test_positions_are_deterministic_for_a_run_seed(self):
        first = sample_visible_initial_target_positions(
            self.agent_position,
            self.fov_dims,
            2,
            self.occlusion_centers,
            self.occlusion_widths,
            self.initialization_rng(1007),
        )
        second = sample_visible_initial_target_positions(
            self.agent_position,
            self.fov_dims,
            2,
            self.occlusion_centers,
            self.occlusion_widths,
            self.initialization_rng(1007),
        )
        np.testing.assert_array_equal(first, second)


if __name__ == "__main__":
    unittest.main()
