"""Verify that recording the shared MML loop leaves its dynamics unchanged."""
import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
from scripts import info_mml_main as runner


class MMLFrameCallbackTests(unittest.TestCase):
    def test_recording_preserves_seeded_run_and_update_cadence(self):
        with tempfile.TemporaryDirectory() as directory:
            args = runner.build_parser().parse_args([
                '--prediction_method', 'MultiPFVel', '--guidance_mode', 'MultiPFInfo',
                '--num_steps', '8', '--seed', '123', '--no_fan', '--headless',
                '--output_dir', directory])
            captured = []
            def record(**frame):
                captured.append(dict(step=frame['step'], t=frame['t'],
                                     state=frame['state'].copy(), action=np.array(frame['action']),
                                     updated=frame['filter_updated'], last=frame['last_frame']))
            previous = Path.cwd()
            try:
                os.chdir(ROOT)
                with contextlib.redirect_stdout(io.StringIO()):
                    baseline = runner.run_simulation(args)
                    observed = runner.run_simulation(args, frame_callback=record)
            finally:
                os.chdir(previous)
            np.testing.assert_array_equal(baseline['state'], observed['state'])
            self.assertEqual([f['step'] for f in captured], list(range(8)))
            self.assertEqual([f['updated'] for f in captured], [True, False] * 4)
            self.assertEqual([f['last'] for f in captured], [False] * 7 + [True])
            np.testing.assert_allclose([f['t'] for f in captured], np.arange(8) * observed['dt'])
            self.assertTrue(all(np.isfinite(f['action']).all() for f in captured))
            self.assertTrue(list(Path(directory).glob('*tracking_metrics*.csv')))


if __name__ == '__main__':
    unittest.main()
