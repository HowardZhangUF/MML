from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "mml_guidance"))

from mml_guidance.ParticleFilter import ParticleFilter
from mml_guidance.particle_filter_gnn_associator import (
    ParticleFilterGNNAssociator,
)


MODEL_DIR = ROOT / "src" / "mml_guidance" / "models"
METHOD_CHECKPOINTS = {
    "PF+CFM": MODEL_DIR / "cfm_motion_model_anchor1.0.pth",
    "PF+CFM-AS": MODEL_DIR / "cfm_motion_model_anchor1.0.pth",
    "PF+NF": MODEL_DIR / "nf_motion_model.pth",
    "PF+Diffusion": MODEL_DIR / "diffusion_motion_model.pth",
    "DiffPF": MODEL_DIR / "diffpf_tracker.pth",
}


class FullSystemPredictionMethodTests(unittest.TestCase):
    def test_multi_target_track_lifecycle(self):
        internal_methods = {
            "PF+CFM": "CFM",
            "PF+CFM-AS": "CFM-AS",
            "PF+NF": "NF",
            "PF+Diffusion": "Diffusion",
            "DiffPF": "DiffPF",
        }

        for method, checkpoint in METHOD_CHECKPOINTS.items():
            with self.subTest(method=method):
                np.random.seed(123)
                associator = ParticleFilterGNNAssociator(
                    num_particles=16,
                    prediction_method=method,
                    model_path=str(checkpoint),
                    initial_time=0.0,
                )
                associator.FOV = None
                associator.is_in_FOV = lambda particles, _fov: np.ones(
                    len(particles), dtype=bool
                )
                associator.in_occlusion = lambda particles: np.zeros(
                    len(particles), dtype=bool
                )

                associator.process_detections(
                    np.array([[0.0, -1.0]], dtype=np.float32),
                    current_time=0.0,
                )
                associator.update_time(0.1)
                associator.process_detections(
                    np.array([[0.02, -0.98]], dtype=np.float32),
                    current_time=0.1,
                )
                associator.update_time(0.2)
                associator.process_detections(
                    np.empty((0, 2), dtype=np.float32),
                    current_time=0.2,
                )

                self.assertEqual(len(associator.tracks), 1)
                track = associator.tracks[0]
                self.assertEqual(
                    track.pf.prediction_method,
                    internal_methods[method],
                )
                self.assertEqual(track.hits, 2)
                self.assertEqual(track.missed_detections, 1)
                self.assertTrue(np.isfinite(track.weighted_mean[:2]).all())

    def test_particle_contracts(self):
        for method, checkpoint in METHOD_CHECKPOINTS.items():
            with self.subTest(method=method):
                np.random.seed(123)
                particle_filter = ParticleFilter(
                    num_particles=16,
                    prediction_method=method,
                    model_path=str(checkpoint),
                    initial_time=0.0,
                    initial_detection=np.array([0.0, -1.0], dtype=np.float32),
                )

                particle_filter.is_update = True
                particle_filter.pf_loop(
                    np.array([0.02, -0.98], dtype=np.float32),
                    0.1,
                )
                particle_filter.is_update = False
                particle_filter.pf_loop(np.zeros(2, dtype=np.float32), 0.2)

                self.assertEqual(particle_filter.particles.ndim, 3)
                self.assertEqual(particle_filter.particles.shape[1:], (16, 2))
                self.assertTrue(np.isfinite(particle_filter.particles).all())
                self.assertTrue(np.isfinite(particle_filter.weights).all())
                self.assertTrue(np.isclose(particle_filter.weights.sum(), 1.0))
                self.assertTrue(
                    np.isfinite(particle_filter.weighted_mean[:2]).all()
                )

    def test_adaptive_cfm_sigma_uses_missing_measurement_steps(self):
        np.random.seed(123)
        particle_filter = ParticleFilter(
            num_particles=16,
            prediction_method="PF+CFM-AS",
            model_path=str(METHOD_CHECKPOINTS["PF+CFM-AS"]),
            initial_time=0.0,
            initial_detection=np.array([0.0, -1.0], dtype=np.float32),
        )

        particle_filter.is_update = False
        particle_filter.pf_loop(np.zeros(2, dtype=np.float32), 0.1)
        particle_filter.pf_loop(np.zeros(2, dtype=np.float32), 0.2)

        self.assertEqual(particle_filter.steps_since_measurement, 2)
        self.assertAlmostEqual(
            particle_filter.motion_model._cfm.anchor_sigma,
            1.05,
        )


if __name__ == "__main__":
    unittest.main()
