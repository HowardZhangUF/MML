"""
pygame_large_env.py
===================
Pygame / Pymunk environment for the MML target-tracking simulation.

Key additions for the CFM / Transformer trajectory visualization:
  1. step(..., trajectory_fan=None, trajectory_weights=None)
  2. draw_trajectory_fan(...)
  3. robust metre-to-pixel conversion for trajectory samples
  4. safer defaults: no mutable list defaults in step()

Place at:
    /home/user/mml_python_sim/environments/pygame_large_env.py
"""

from __future__ import annotations

import copy
from typing import Optional, Sequence, Tuple

import numpy as np
import pygame
import pymunk
import yaml
from pymunk import Space
from pymunk.pygame_util import DrawOptions

from simulation_utils.player import Player
from simulation_utils.obstacle import Obstacle


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

def load_config(file_path: str):
    with open(file_path) as f:
        return yaml.safe_load(f)


class PygameEnvironment:
    def __init__(self, seed=None, render_enabled=True):
        pygame.init()
        if seed is None:
            np.random.seed()
        else:
            np.random.seed(int(seed))
        self.rng = np.random.default_rng(seed)
        self.render_enabled = bool(render_enabled)

        # ── Hyper-params from config.yaml ────────────────────────────────────
        config_params = load_config("config.yaml")

        self.number_agents = config_params["number_agents"]
        self.number_obstacles = config_params["number_obstacles"]
        self.number_targets = config_params["number_targets"]
        self.dt = config_params["dt"]
        self.eta_init = config_params["eta"]
        self.z_init = config_params["z"]

        # Metre coordinate system setup.
        # Environment spans -3 m to +3 m in both x and y.
        self.env_size = config_params["env_size"]
        self.meters_span = 6.0
        self.pixels_per_meter = self.env_size / self.meters_span
        self.env_center_pixels = self.env_size / 2.0
        self.num_reset_steps = config_params["number_sim_steps"]

        self.eta_init_pixels = [
            self.eta_init[0] * self.pixels_per_meter + self.env_center_pixels,
            -self.eta_init[1] * self.pixels_per_meter + self.env_center_pixels,
        ]
        self.z_init_pixels = [
            self.z_init[0] * self.pixels_per_meter + self.env_center_pixels,
            -self.z_init[1] * self.pixels_per_meter + self.env_center_pixels,
        ]

        use_initial_conditions = config_params["use_initial_conditions"]

        self.reset_step = 0
        self.screen = None
        self.screen_options = None
        self.space = Space()

        self.main_surface = pygame.Surface((self.env_size, self.env_size))
        self.surface_background = pygame.Color((169, 169, 169))
        self.main_surface.fill(self.surface_background)
        self.main_surface_options = DrawOptions(self.main_surface)
        self.clock = pygame.time.Clock()

        # Occlusion boxes stored internally in PIXELS.
        self.occ_centers = None
        self.occ_widths = None

        max_lin_velx = config_params["max_lin_velx"] * self.pixels_per_meter
        max_lin_vely = config_params["max_lin_vely"] * self.pixels_per_meter
        self.target_lin_scale = config_params["target_lin_scale"]
        self.max_speed = (max_lin_velx**2 + max_lin_vely**2) ** 0.5
        self.max_dist = (self.env_size**2 + self.env_size**2) ** 0.5
        self.max_ang_vel = config_params["max_ang_vel"]

        self.done = False
        self.last_state = None

        # ── Agents ───────────────────────────────────────────────────────────
        self.agents = []
        for ii in range(self.number_agents):
            agent_spacing_pixels = ii * 1.3 * self.pixels_per_meter
            self.agents.append(
                Player(
                    space=self.space,
                    position=np.array(self.eta_init_pixels) + np.array([agent_spacing_pixels, 0]),
                    positionRadius=25,
                    max_lin_velx=max_lin_velx,
                    max_lin_vely=max_lin_vely,
                    max_ang_vel=self.max_ang_vel,
                    collision_type=2,
                    use_initial_conditions=use_initial_conditions,
                )
            )
            agent_pos_m = self.pixels_to_meters(
                self.agents[ii].body.position[0],
                self.agents[ii].body.position[1],
            )
            print(f"Agent {ii} position [m]: ", agent_pos_m)

        # ── Obstacles ────────────────────────────────────────────────────────
        self.obstacles = []
        self.closest_obstacles = []
        for _ in range(self.number_obstacles):
            self.obstacles.append(
                Obstacle(
                    window_size=self.env_size,
                    space=self.space,
                    base_position=(self.env_center_pixels, self.env_center_pixels),
                    baseRadius=50,
                    collision_type=0,
                )
            )
        self.inReset = False

        # ── Targets ──────────────────────────────────────────────────────────
        self.targets = []
        for ii in range(self.number_targets):
            target_spacing_pixels = ii * 1.3 * self.pixels_per_meter
            self.targets.append(
                Player(
                    space=self.space,
                    position=np.array(self.z_init_pixels) + np.array([target_spacing_pixels, 0]),
                    positionRadius=25,
                    max_lin_velx=max_lin_velx * self.target_lin_scale,
                    max_lin_vely=max_lin_vely * self.target_lin_scale,
                    max_ang_vel=self.max_ang_vel,
                    is_target=True,
                    collision_type=3,
                    use_initial_conditions=use_initial_conditions,
                )
            )
            target_pos_m = self.pixels_to_meters(
                self.targets[ii].body.position[0],
                self.targets[ii].body.position[1],
            )
            print(f"Target {ii} position [m]: ", target_pos_m)

        self.prev_goal_in = [0] * self.number_targets
        self.prev_mult = 0

        # ── Road network: same as markov_goal_pose.py road_network_V2() ──────
        self.goal_list = []
        node_positions = [
            (-1.5,  1.0, 180),
            ( 0.0,  1.0, 180),
            ( 2.1,  1.0,  90),
            (-1.5, -1.0, 270),
            ( 0.0, -1.0,  90),
            ( 0.3,  0.0,   0),
            ( 1.7,  0.0,   0),
            ( 2.1, -1.0, 270),
        ]

        for node, pos in enumerate(node_positions):
            gx, gy = self.meters_to_pixels(pos[0], pos[1])
            self.goal_list.append({"curr_goal": node, "x": gx, "y": gy})

        self.n_states = len(self.goal_list)

        self.base_trans_matrix = np.array(
            [
                [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
                [0.5, 0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0],
                [0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0],
                [0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.5],
                [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            ],
            dtype=float,
        )
        self.connectivity_mask = self.base_trans_matrix > 0
        self.trans_matrix = np.copy(self.base_trans_matrix)

        self.waitToStart = True
        self.timeFromStart = 0.0
        self.firstNewImageDrawn = False

        # PD controller params.
        self.kp = 2.0
        self.kd = 6.0
        self.previous_error = np.zeros(2, dtype=float)

        tolerance_radius_m = 0.15
        self.tolerance_radius = self.meters_to_pixels_distance(tolerance_radius_m)
        self.fov_size_pixels = self.meters_to_pixels_distance(2.0)
        self.fov_size_meters = 2.0

    # ────────────────────────────────────────────────────────────────────────
    # Coordinate conversion
    # ────────────────────────────────────────────────────────────────────────

    def meters_to_pixels(self, x_meters, y_meters) -> Tuple[float, float]:
        """Convert metre coordinates, origin at centre, to pixel coordinates."""
        x_pixels = x_meters * self.pixels_per_meter + self.env_center_pixels
        y_pixels = -y_meters * self.pixels_per_meter + self.env_center_pixels
        return x_pixels, y_pixels

    def pixels_to_meters(self, x_pixels, y_pixels) -> Tuple[float, float]:
        """Convert pixel coordinates to metre coordinates, origin at centre."""
        x_meters = (x_pixels - self.env_center_pixels) / self.pixels_per_meter
        y_meters = -(y_pixels - self.env_center_pixels) / self.pixels_per_meter
        return x_meters, y_meters

    def meters_to_pixels_distance(self, distance_meters):
        """Convert a distance from metres to pixels."""
        return distance_meters * self.pixels_per_meter

    # ────────────────────────────────────────────────────────────────────────
    # Randomization helpers
    # ────────────────────────────────────────────────────────────────────────

    def randomize_transition_matrix(self, randomness=1.0):
        """
        Randomize the transition matrix while preserving connectivity.

        randomness:
            0 = use base matrix
            1 = full randomization with Uniform(0.1, 1.0)
        """
        if randomness <= 0:
            self.trans_matrix = np.copy(self.base_trans_matrix)
            return

        new_matrix = np.zeros_like(self.base_trans_matrix)

        for i in range(len(self.connectivity_mask)):
            valid_edges = self.connectivity_mask[i]
            if not np.any(valid_edges):
                continue

            base_probs = self.base_trans_matrix[i, valid_edges]
            random_probs = self.rng.uniform(0.1, 1.0, size=np.sum(valid_edges))
            blended_probs = (1 - randomness) * base_probs + randomness * random_probs
            blended_probs = blended_probs / np.sum(blended_probs)
            new_matrix[i, valid_edges] = blended_probs

        self.trans_matrix = new_matrix

    def randomize_fov(self, fov_min=1.5, fov_max=3.0, curriculum_progress=0.0):
        """Randomize the FOV size in metres."""
        effective_min = fov_max - curriculum_progress * (fov_max - fov_min)
        self.fov_size_meters = self.rng.uniform(effective_min, fov_max)
        self.fov_size_pixels = self.meters_to_pixels_distance(self.fov_size_meters)

    def randomize_occlusions(self, num_occlusions=2, width_min=0.8, width_max=1.5):
        """Randomize occlusion positions and sizes."""
        occ_centers_m = []
        occ_widths_m = []

        for _ in range(num_occlusions):
            x = self.rng.uniform(-2.0, 2.0)
            y = self.rng.uniform(-2.0, 2.0)
            occ_centers_m.extend([x, y])
            occ_widths_m.append(self.rng.uniform(width_min, width_max))

        occ_centers_px = []
        for i in range(0, len(occ_centers_m), 2):
            px, py = self.meters_to_pixels(occ_centers_m[i], occ_centers_m[i + 1])
            occ_centers_px.extend([px, py])

        self.occ_centers = [occ_centers_px[i * 2:(i + 1) * 2] for i in range(num_occlusions)]
        self.occ_widths = [w * self.pixels_per_meter for w in occ_widths_m]

        return occ_centers_m, occ_widths_m

    def set_fixed_occlusions(self, occ_centers_meters=None, occ_widths_meters=None):
        """Set fixed occlusion positions and sizes in metre coordinates."""
        if occ_centers_meters is None:
            occ_centers_meters = [-1.0, 0.0, 1.0, 0.0]
        if occ_widths_meters is None:
            occ_widths_meters = [1.0, 1.0]

        if isinstance(occ_centers_meters, list) and occ_centers_meters:
            if isinstance(occ_centers_meters[0], (list, tuple)):
                flat = []
                for center in occ_centers_meters:
                    flat.extend(center)
                occ_centers_meters = flat

        num_occlusions = len(occ_widths_meters)

        occ_centers_px = []
        for i in range(0, len(occ_centers_meters), 2):
            px, py = self.meters_to_pixels(occ_centers_meters[i], occ_centers_meters[i + 1])
            occ_centers_px.extend([px, py])

        self.occ_centers = [occ_centers_px[i * 2:(i + 1) * 2] for i in range(num_occlusions)]
        self.occ_widths = [w * self.pixels_per_meter for w in occ_widths_meters]

        return occ_centers_meters, occ_widths_meters

    # ────────────────────────────────────────────────────────────────────────
    # Rendering lifecycle
    # ────────────────────────────────────────────────────────────────────────

    def render_init(self, occ_centers: Optional[Sequence[float]] = None,
                    occ_widths: Optional[Sequence[float]] = None,
                    fov_size: float = 2.0):
        """
        Initialize the rendering window.

        occ_centers:
            flattened list of occlusion centres in metres:
            [x1, y1, x2, y2, ...]
        occ_widths:
            list of occlusion widths in metres.
        fov_size:
            FOV square side length in metres.
        """
        if self.render_enabled:
            pygame.display.set_caption("MultiAgentCoordination")
            self.screen = pygame.display.set_mode((self.env_size, self.env_size))
            self.screen_options = pymunk.pygame_util.DrawOptions(self.screen)

        if occ_centers is not None and occ_widths is not None:
            occ_centers_px = []
            for i in range(0, len(occ_centers), 2):
                px, py = self.meters_to_pixels(occ_centers[i], occ_centers[i + 1])
                occ_centers_px.extend([px, py])
            self.occ_centers = [occ_centers_px[i * 2:(i + 1) * 2] for i in range(len(occ_widths))]
            self.occ_widths = [width * self.pixels_per_meter for width in occ_widths]
        else:
            self.occ_centers = None
            self.occ_widths = None

        self.fov_size_pixels = fov_size * self.pixels_per_meter
        self.fov_size_meters = fov_size

    def render(self):
        if not self.render_enabled:
            return
        pygame.event.get()
        if self.screen is not None:
            self.screen.blit(self.main_surface, (0, 0))
            pygame.display.update()
        self.clock.tick(60)

    def render_close(self):
        pygame.display.quit()

    def close(self):
        for shape in list(self.space.shapes):
            self.space.remove(shape.body, shape)
        pygame.display.quit()
        pygame.quit()

    # ────────────────────────────────────────────────────────────────────────
    # Main simulation step
    # ────────────────────────────────────────────────────────────────────────

    def step(self,
             action,
             particle_tracks=None,
             tracks=None,
             goal_pos=None,
             detections=None,
             future_particles=None,
             trajectory_fan=None,
             trajectory_weights=None):
        """
        Step the physics simulation and redraw the environment.

        Parameters are in metre coordinates unless otherwise noted.

        trajectory_fan:
            Optional array with shape (n_samples, n_steps, 2), in metres.
            Drawn as a blue trajectory bundle plus a magenta weighted mean path.
        trajectory_weights:
            Optional array with shape (n_samples,). If None, uniform weights.
        """
        if particle_tracks is None:
            particle_tracks = []
        if detections is None:
            detections = []
        if future_particles is None:
            future_particles = []

        self.reset_step += 1
        if self.reset_step >= self.num_reset_steps:
            self.done = True

        if self.done:
            if self.last_state is None:
                self.last_state = copy.deepcopy(self.getState())
            return self.last_state, self.done

        action = np.asarray(action, dtype=float).flatten()
        if action.size < 2:
            action = np.array([0.0, 0.0, 0.0], dtype=float)
        elif action.size == 2:
            action = np.array([action[0], action[1], 0.0], dtype=float)
        else:
            action = np.array([action[0], action[1], action[2]], dtype=float)

        # ── Agent control: m/s -> px/s ───────────────────────────────────────
        for ii in range(self.number_agents):
            action_px = [
                action[0] * self.pixels_per_meter,
                -action[1] * self.pixels_per_meter,
                action[2],
            ]
            self.agents[ii].updateVelocity(action_px[0:2], action_px[2])

        # ── Target road-network dynamics ─────────────────────────────────────
        for ii in range(self.number_targets):
            curr_goal_in = int(np.copy(self.prev_goal_in[ii]))
            curr_goal_pose = self.goal_list[curr_goal_in]

            relative_position = (
                np.array([curr_goal_pose["x"], curr_goal_pose["y"]])
                - self.targets[ii].body.position
            )
            relative_distance = np.linalg.norm(relative_position)

            if relative_distance < self.tolerance_radius:
                curr_goal_in = self.rng.choice(
                    np.arange(self.n_states),
                    p=self.trans_matrix[self.prev_goal_in[ii], :],
                )
                self.prev_goal_in[ii] = int(curr_goal_in)
                curr_goal_pose = self.goal_list[curr_goal_in]
                relative_position = (
                    np.array([curr_goal_pose["x"], curr_goal_pose["y"]])
                    - self.targets[ii].body.position
                )
                relative_distance = np.linalg.norm(relative_position)

            relative_direction = relative_position / (relative_distance + 1e-5)
            target_direction = np.array([
                np.cos(self.targets[ii].body.angle),
                np.sin(self.targets[ii].body.angle),
            ])

            # Move along current heading while steering toward the road-network goal.
            target_vel = self.target_lin_scale * self.max_speed * target_direction

            cos_val = relative_direction[0] * target_direction[0] + relative_direction[1] * target_direction[1]
            sin_val = -relative_direction[1] * target_direction[0] + relative_direction[0] * target_direction[1]
            angle_error = np.arctan2(sin_val, cos_val)

            ang_vel = -self.targets[ii].max_ang_vel * np.sin(angle_error / 2.0)
            self.targets[ii].updateVelocity(target_vel, ang_vel)

        self.space.step(self.dt)

        # Keep agents and targets inside environment bounds.
        self._apply_boundary_constraints(boundary_min=-3.0, boundary_max=3.0)

        if self.render_enabled:
            self._redraw_scene(
                particle_tracks=particle_tracks,
                tracks=tracks,
                goal_pos=goal_pos,
                detections=detections,
                future_particles=future_particles,
                trajectory_fan=trajectory_fan,
                trajectory_weights=trajectory_weights,
            )

        self.last_state = copy.deepcopy(self.getState())
        return self.last_state, self.done

    # ────────────────────────────────────────────────────────────────────────
    # Drawing helpers
    # ────────────────────────────────────────────────────────────────────────

    def _apply_boundary_constraints(self, boundary_min=-3.0, boundary_max=3.0):
        """Clip all agents and targets to the square metre-domain bounds."""
        for entity in list(self.agents) + list(self.targets):
            px = entity.body.position.x
            py = entity.body.position.y
            x_m, y_m = self.pixels_to_meters(px, py)

            x_clip = np.clip(x_m, boundary_min, boundary_max)
            y_clip = np.clip(y_m, boundary_min, boundary_max)

            if x_clip != x_m or y_clip != y_m:
                new_px, new_py = self.meters_to_pixels(x_clip, y_clip)
                entity.body.position = (new_px, new_py)

                vx, vy = entity.body.velocity
                if x_clip != x_m:
                    vx = 0
                if y_clip != y_m:
                    vy = 0
                entity.body.velocity = (vx, vy)

    def _redraw_scene(self,
                      particle_tracks=None,
                      tracks=None,
                      goal_pos=None,
                      detections=None,
                      future_particles=None,
                      trajectory_fan=None,
                      trajectory_weights=None):
        """Draw the complete current frame onto self.main_surface."""
        particle_tracks = [] if particle_tracks is None else particle_tracks
        detections = [] if detections is None else detections
        future_particles = [] if future_particles is None else future_particles

        self.main_surface.fill(self.surface_background)
        self.space.debug_draw(self.main_surface_options)

        self._draw_occlusions()
        self._draw_agents()
        self._draw_targets()

        # Goal / agent search point.
        if goal_pos is not None:
            gx, gy = self.meters_to_pixels(goal_pos[0], goal_pos[1])
            pygame.draw.circle(
                self.main_surface,
                (100, 100, 255),
                (int(gx), int(gy)),
                6,
            )

        # Current particles: black.
        if len(particle_tracks) > 0:
            for particles in particle_tracks:
                particles = np.asarray(particles)
                if particles.ndim >= 3 and particles.shape[0] > 0:
                    self.draw_particles_and_mean(particles[-1, :25, :2])

        # Future particles: blue dots.
        if future_particles is not None and len(future_particles) > 0:
            for particles in future_particles:
                particles = np.asarray(particles)
                if particles.ndim >= 3 and particles.shape[0] > 0:
                    self.draw_particles_and_mean(
                        particles[-1, :25, :2],
                        particle_color=(100, 100, 255),
                    )

        # CFM / Transformer future trajectory fan: blue thin lines + magenta mean.
        if trajectory_fan is not None:
            self.draw_trajectory_fan(
                trajectory_fan,
                weights=trajectory_weights,
                fan_color=(80, 140, 255),
                mean_color=(255, 0, 200),
                mean_width=3,
            )

        # Measurements / detections: yellow.
        if len(detections) > 0:
            for det in detections:
                dx, dy = self.meters_to_pixels(det[0], det[1])
                pygame.draw.circle(self.main_surface, (255, 255, 0), (int(dx), int(dy)), 4)

        # Estimated tracks: green.
        if tracks is not None and len(tracks) > 0:
            self.draw_tracks(tracks)

    def _draw_occlusions(self):
        if self.occ_centers is None or self.occ_widths is None:
            return

        for center, width in zip(self.occ_centers, self.occ_widths):
            rect = pygame.Rect(
                center[0] - width / 2,
                center[1] - width / 2,
                width,
                width,
            )
            pygame.draw.rect(self.main_surface, (0, 0, 0), rect, width=2)

    def _draw_agents(self):
        for ii in range(self.number_agents):
            agent_x = int(self.agents[ii].body.position[0])
            agent_y = int(self.agents[ii].body.position[1])

            square_rect = pygame.Rect(
                agent_x - self.fov_size_pixels / 2,
                agent_y - self.fov_size_pixels / 2,
                self.fov_size_pixels,
                self.fov_size_pixels,
            )
            pygame.draw.rect(self.main_surface, (0, 0, 255), square_rect, width=2)

            if hasattr(self.agents[ii], "image_ghost"):
                img = pygame.transform.rotate(
                    self.agents[ii].image_ghost,
                    -self.agents[ii].body.angle * 180 / np.pi,
                )
                rect = img.get_rect(center=(
                    self.agents[ii].body.position[0],
                    self.agents[ii].body.position[1],
                ))
                self.main_surface.blit(img, rect)

    def _draw_targets(self):
        for ii in range(self.number_targets):
            # Target heading arrow.
            start = (
                self.targets[ii].body.position[0],
                self.targets[ii].body.position[1],
            )
            scale = 20
            angle = self.targets[ii].body.angle
            end = (
                start[0] + scale * np.cos(angle),
                start[1] + scale * np.sin(angle),
            )
            pygame.draw.line(self.main_surface, (255, 240, 0), start, end, 2)

            if hasattr(self.targets[ii], "image_ghost"):
                img = pygame.transform.rotate(
                    self.targets[ii].image_ghost,
                    -self.targets[ii].body.angle * 180 / np.pi,
                )
                rect = img.get_rect(center=(
                    self.targets[ii].body.position[0],
                    self.targets[ii].body.position[1],
                ))
                self.main_surface.blit(img, rect)

    def draw_tracks(self, tracks):
        """Draw estimated target tracks as green circles, optionally with heading."""
        if isinstance(tracks, list):
            tracks = np.array(tracks)
        tracks = np.asarray(tracks)

        if tracks.size == 0:
            return
        if tracks.ndim == 1:
            tracks = tracks.reshape(1, -1)

        track_color = (0, 255, 10)
        circle_radius = 5

        for pt in tracks:
            px, py = self.meters_to_pixels(pt[0], pt[1])
            pygame.draw.circle(self.main_surface, track_color, (int(px), int(py)), circle_radius)

        if tracks.shape[1] >= 3:
            arrow_color = (0, 255, 0)
            scale = 15
            for pt in tracks:
                mx, my = self.meters_to_pixels(pt[0], pt[1])
                angle = pt[2]
                start = (int(mx), int(my))
                end = (
                    int(mx + scale * np.cos(angle)),
                    int(my - scale * np.sin(angle)),
                )
                pygame.draw.line(self.main_surface, arrow_color, start, end, width=2)

    def draw_particles_and_mean(self, particles, particle_color=(0, 0, 0)):
        """Draw particles as small points. Input positions are in metres."""
        if particles is None:
            return

        particles = np.asarray(particles)
        if particles.size == 0:
            return
        if particles.ndim == 1:
            particles = particles.reshape(1, -1)

        particle_radius = 2
        for particle in particles:
            if len(particle) < 2:
                continue
            px, py = self.meters_to_pixels(particle[0], particle[1])
            px, py = int(px), int(py)
            if 0 <= px <= self.env_size and 0 <= py <= self.env_size:
                pygame.draw.circle(self.main_surface, particle_color, (px, py), particle_radius)

    def draw_trajectory_fan(self,
                            fan,
                            weights=None,
                            fan_color=(80, 140, 255),
                            mean_color=(255, 0, 200),
                            mean_width=3,
                            min_alpha=12,
                            max_alpha=120):
        """
        Draw a multi-step trajectory fan onto self.main_surface.

        fan:
            Array with shape (n_samples, n_steps, 2), in metres.
        weights:
            Optional array with shape (n_samples,). Used for alpha and mean path.
        fan_color:
            RGB colour for individual sample paths.
        mean_color:
            RGB colour for the weighted-mean path.
        """
        if fan is None:
            return

        fan = np.asarray(fan, dtype=np.float32)
        if fan.ndim != 3 or fan.shape[-1] < 2:
            return

        n_samples, n_steps, _ = fan.shape
        if n_samples == 0 or n_steps < 2:
            return

        if weights is None:
            weights = np.ones(n_samples, dtype=np.float32) / n_samples
        else:
            weights = np.asarray(weights, dtype=np.float32).reshape(-1)
            if len(weights) != n_samples or not np.all(np.isfinite(weights)) or weights.sum() <= 1e-12:
                weights = np.ones(n_samples, dtype=np.float32) / n_samples
            else:
                weights = weights / weights.sum()

        w_max = float(np.max(weights)) if len(weights) > 0 else 1.0
        if w_max <= 1e-12:
            w_norm = np.ones_like(weights)
        else:
            w_norm = weights / w_max

        fan_surf = pygame.Surface((self.env_size, self.env_size), pygame.SRCALPHA)
        r, g, b = fan_color

        for i in range(n_samples):
            alpha = int(min_alpha + (max_alpha - min_alpha) * float(w_norm[i]))
            alpha = int(np.clip(alpha, 0, 255))

            pts = []
            for h in range(n_steps):
                x_m, y_m = fan[i, h, 0], fan[i, h, 1]
                if not np.isfinite(x_m) or not np.isfinite(y_m):
                    continue
                px, py = self.meters_to_pixels(x_m, y_m)
                pts.append((int(px), int(py)))

            if len(pts) >= 2:
                pygame.draw.lines(fan_surf, (r, g, b, alpha), False, pts, 1)

        self.main_surface.blit(fan_surf, (0, 0))

        # Weighted mean path.
        mean_traj = (weights[:, None, None] * fan[:, :, :2]).sum(axis=0)
        mean_pts = []
        for h in range(n_steps):
            x_m, y_m = mean_traj[h, 0], mean_traj[h, 1]
            if not np.isfinite(x_m) or not np.isfinite(y_m):
                continue
            px, py = self.meters_to_pixels(x_m, y_m)
            mean_pts.append((int(px), int(py)))

        if len(mean_pts) >= 2:
            pygame.draw.lines(self.main_surface, mean_color, False, mean_pts, mean_width)

    # ────────────────────────────────────────────────────────────────────────
    # Reset / control / state
    # ────────────────────────────────────────────────────────────────────────

    def set_target_positions_meters(self, positions):
        """Set target positions before a run without changing their headings."""
        positions = np.asarray(positions, dtype=float)
        expected_shape = (self.number_targets, 2)
        if positions.shape != expected_shape:
            raise ValueError(
                f"Target positions must have shape {expected_shape}, "
                f"got {positions.shape}."
            )
        if not np.all(np.isfinite(positions)):
            raise ValueError("Target positions must be finite.")
        if np.any(positions < -3.0) or np.any(positions > 3.0):
            raise ValueError("Target positions must lie inside [-3, 3] metres.")

        for target, position in zip(self.targets, positions):
            position_pixels = self.meters_to_pixels(position[0], position[1])
            target.body.position = position_pixels
            target.body.velocity = (0.0, 0.0)
            target.body.angular_velocity = 0.0
            target.startPosition = target.body.position
            self.space.reindex_shapes_for_body(target.body)

        self.last_state = None
        return self.getState()

    def reset(self):
        for shape in list(self.space.shapes):
            self.space.remove(shape.body, shape)

        for obstacle in self.obstacles:
            obstacle.reset(
                self.space,
                base_position=(self.env_center_pixels, self.env_center_pixels),
                baseRadius=50,
            )

        self.pathReady = False

        for ii, agent in enumerate(self.agents):
            agent_spacing_m = ii * 2.3
            agent_pos_m = np.array(self.eta_init) + np.array([agent_spacing_m, 0])
            agent_pos_px = self.meters_to_pixels(agent_pos_m[0], agent_pos_m[1])
            agent.reset(self.space, position=agent_pos_px, positionRadius=25)

        for ii, target in enumerate(self.targets):
            target_spacing_m = ii * 2.3
            target_pos_m = np.array(self.z_init) + np.array([target_spacing_m, 0])
            target_pos_px = self.meters_to_pixels(target_pos_m[0], target_pos_m[1])
            target.reset(self.space, position=target_pos_px, positionRadius=25)

        self.waitToStart = True
        self.firstNewImageDrawn = False
        self.timeFromStart = 0.0
        self.discountSum = 0.0
        self.done = False
        self.last_state = None
        self.previous_error = np.zeros(2, dtype=float)

        self.main_surface.fill(self.surface_background)

        for ii in range(self.number_agents):
            if hasattr(self.agents[ii], "image_ghost"):
                img = pygame.transform.rotate(
                    self.agents[ii].image_ghost,
                    -self.agents[ii].body.angle * 180 / np.pi,
                )
                rect = img.get_rect(center=(
                    self.agents[ii].body.position[0],
                    self.agents[ii].body.position[1],
                ))
                self.main_surface.blit(img, rect)

        for ii in range(self.number_targets):
            if hasattr(self.targets[ii], "image_ghost"):
                img = pygame.transform.rotate(
                    self.targets[ii].image_ghost,
                    -self.targets[ii].body.angle * 180 / np.pi,
                )
                rect = img.get_rect(center=(
                    self.targets[ii].body.position[0],
                    self.targets[ii].body.position[1],
                ))
                self.main_surface.blit(img, rect)

        self.space.debug_draw(self.main_surface_options)
        self.reset_step = 0
        return self.getState(), {}

    def goal_position_to_velocity(self, goal_position, current_position):
        """
        Convert goal position to velocity vector with PD control.
        Returns [vx, vy, angular_velocity] in metre/s and rad/s.
        """
        error = np.asarray(goal_position[:2], dtype=float) - np.asarray(current_position[:2], dtype=float)
        proportional = error * self.kp
        derivative = (error - self.previous_error) * self.kd
        self.previous_error = error

        vel = proportional + derivative
        max_speed_m = self.max_speed / self.pixels_per_meter
        vel[:2] = np.clip(vel[:2], -max_speed_m, max_speed_m)
        return [float(vel[0]), float(vel[1]), 0.0]

    def getState(self):
        state = np.zeros((self.number_agents + self.number_targets, 6), dtype=np.float32)

        # Agent state.
        agent_pos_m = self.pixels_to_meters(
            self.agents[0].body.position[0],
            self.agents[0].body.position[1],
        )
        state[0, 0] = agent_pos_m[0]
        state[0, 1] = agent_pos_m[1]
        state[0, 2] = self.agents[0].body.angle
        state[0, 3] = self.agents[0].body.velocity[0] / self.pixels_per_meter
        state[0, 4] = -self.agents[0].body.velocity[1] / self.pixels_per_meter
        state[0, 5] = -self.agents[0].body.angular_velocity

        # Target states.
        for ii in range(self.number_targets):
            idx = ii + self.number_agents
            target_pos_m = self.pixels_to_meters(
                self.targets[ii].body.position[0],
                self.targets[ii].body.position[1],
            )
            state[idx, 0] = target_pos_m[0]
            state[idx, 1] = target_pos_m[1]
            state[idx, 2] = self.targets[ii].body.angle
            state[idx, 3] = self.targets[ii].body.velocity[0] / self.pixels_per_meter
            state[idx, 4] = -self.targets[ii].body.velocity[1] / self.pixels_per_meter
            state[idx, 5] = -self.targets[ii].body.angular_velocity

        return state
