﻿"""
Gym wrapper for SEARCH task (when particle filter loses all tracks).

Observation: Agent state + last known position + search coverage history
Reward: High reward for finding targets, penalty for time
NO current target positions in observation!
"""
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from environments.pygame_large_env import PygameEnvironment


class GymSearchEnv(gym.Env):
    """
    Environment for training search policy.
    Agent learns to find targets WITHOUT seeing their current positions.
    """
    
    def __init__(self, render_mode=None, max_steps=500):
        super().__init__()
        
        # TODO: Implement search environment
        # Observation space: [agent_pos(2), agent_vel(2), last_known_pos(2), 
        #                     time_lost(1), coverage_features(3)] = 10 dims
        # Action space: [vx, vy, omega]
        # Reward: +100 when target found, -0.1 per step
        
        pass
    
    def reset(self, seed=None, options=None):
        # TODO: Implement reset
        pass
    
    def step(self, action):
        # TODO: Implement step with blind observation and search rewards
        pass
    
    def _get_obs(self):
        # TODO: Build observation WITHOUT current target positions
        pass
    
    def render(self):
        pass
    
    def close(self):
        pass
