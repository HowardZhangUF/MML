import sys
import os
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)
src_dir = os.path.join(parent_dir, 'src', 'mml_guidance')
sys.path.insert(0, src_dir)
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from environments.pygame_large_env import PygameEnvironment
from mml_guidance.ParticleFilter import ParticleFilter
from environments.observation_history import ObservationHistoryManager
from mml_guidance.guidance import Occlusions


class GymPursuitEnv(gym.Env):
    """
    Gym wrapper for multi-target pursuit with:

    Phase 1 — Visibility gating + confidence observation
        - FOV check: box test  |dx| ≤ fov/2 AND |dy| ≤ fov/2
        - Occlusion check: Occlusions.in_occlusion() (shared with guidance.py)
        - pf.is_update gated by combined visible flag
        - Observation per target: [rel_x, rel_y, rel_vx, rel_vy, confidence]
        - confidence=0  → obs slot zeroed; LSTM h_t carries last trajectory

    Phase 2 — Observation history buffer (ObservationHistoryManager)
        - Records every visible observation per target across episodes
        - In-memory by default; optional file persistence
        - info_mml_main.py loads this at inference to build the GMM search prior

    Phase 4 — Reward engineering
        - Track-loss penalty (one-time + continuous)
        - Re-acquisition bonus
        - Curriculum ramp: weights start at 0, ramp in after episode 1000

    NOTE — Phase 3 (search_prior in observation) has been REMOVED.
    The RL policy is trained on {agent(4), targets(N,5), mask(N)} only.
    GMM-guided search is implemented as an algorithmic module in
    info_mml_main.py and runs only when tracked_states is empty.
    This separation keeps the RL training simple and the search logic
    transparent and tunable without retraining.
    """

    def __init__(self, render_mode='human', max_steps=1000,
                 use_particle_filter=True, num_particles=100,
                 prediction_method="Velocity",
                 track_nearest_only=False, use_attention=False,
                 max_tracked_targets=10, drone_height=1.0,
                 reward_mode='ospa',
                 ospa_cutoff=10.0, ospa_order=2,
                 use_curriculum=True, curriculum_episodes=10000,
                 randomize_every_n_episodes=1,
                 randomize_occlusions=True,
                 fov_min=1.5, fov_max=3.0,
                 history_max_size=1000,
                 history_save_to_file=False,
                 history_save_path='obs_history.pkl'):
        super().__init__()

        self.env = PygameEnvironment()
        self.max_steps             = max_steps
        self.current_step          = 0
        self.render_mode           = render_mode
        self.use_particle_filter   = use_particle_filter
        self.track_nearest_only    = track_nearest_only
        self.use_attention         = use_attention
        self.max_tracked_targets   = max_tracked_targets

        self.use_curriculum             = use_curriculum
        self.curriculum_episodes        = curriculum_episodes
        self.randomize_every_n_episodes = randomize_every_n_episodes
        self.randomize_occlusions       = randomize_occlusions
        self.fov_min                    = fov_min
        self.fov_max                    = fov_max
        self.episode_count              = 0

        # Shared Occlusions object — identical to guidance.py
        self.occlusions = Occlusions([], [])

        initial_state, _ = self.env.reset()
        self.num_agents  = self.env.number_agents
        self.num_targets = self.env.number_targets

        self.reward_mode    = reward_mode
        self.ospa_cutoff    = ospa_cutoff
        self.ospa_order     = ospa_order
        self.w_localization = 1.0
        self.w_cardinality  = 0.5
        self.w_info         = 0.5
        self.w_track_continuity = 0.0
        self.w_reacquisition    = 0.0

        def _default_status():
            return {'status': 'ACTIVE', 'last_seen_time': 0.0,
                    'last_seen_pos': None, 'lost_time': 0.0}
        self.track_status      = [_default_status() for _ in range(self.num_targets)]
        self.prev_track_status = [s.copy() for s in self.track_status]

        self.particle_filters = []
        if self.use_particle_filter:
            for i in range(self.num_targets):
                pf = ParticleFilter(
                    num_particles=num_particles,
                    prediction_method=prediction_method,
                    drone_height=1.0,
                    initial_time=0.0,
                    initial_detection=initial_state[1 + i, :2],
                )
                self.particle_filters.append(pf)

        self._render_particle_tracks = []
        self._render_detections      = []

        # Phase 2: history buffer (populated during training, read at inference)
        self.history_manager = ObservationHistoryManager(
            num_targets=self.num_targets,
            max_size=history_max_size,
            save_to_file=history_save_to_file,
            save_path=history_save_path,
        )

        # ── Observation space ─────────────────────────────────────────────────
        # Attention mode: {agent(4), targets(N,5), mask(N)}
        # No search_prior — GMM search lives in info_mml_main.py only.
        if use_attention:
            self.observation_space = spaces.Dict({
                'agent': spaces.Box(
                    low=-np.inf, high=np.inf, shape=(4,), dtype=np.float32),
                'targets': spaces.Box(
                    low=-np.inf, high=np.inf,
                    shape=(max_tracked_targets, 5), dtype=np.float32),
                'mask': spaces.Box(
                    low=0, high=1,
                    shape=(max_tracked_targets,), dtype=np.float32),
            })
        elif track_nearest_only:
            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf, shape=(9,), dtype=np.float32)
        else:
            self.observation_space = spaces.Box(
                low=-np.inf, high=np.inf,
                shape=(4 + self.num_targets * 5,), dtype=np.float32)

        self.action_space = spaces.Box(
            low=np.array([-0.6, -0.6, -5.0]),
            high=np.array([0.6, 0.6, 5.0]),
            dtype=np.float32
        )

        self.current_time       = 0.0
        self.nearest_target_idx = 0

    # ═══════════════════════════════════════════════════════════════════════════
    # Phase 1: visibility helpers
    # ═══════════════════════════════════════════════════════════════════════════

    def _construct_fov(self, agent_pos) -> np.ndarray:
        """[x_min, x_max, y_min, y_max] box FOV — mirrors guidance.py construct_FOV()."""
        half = self.env.fov_size_meters / 2.0
        return np.array([agent_pos[0] - half, agent_pos[0] + half,
                         agent_pos[1] - half, agent_pos[1] + half], dtype=np.float64)

    def _is_in_fov(self, target_pos, fov) -> bool:
        """Box check — mirrors guidance.py is_in_FOV() single-point branch."""
        return bool(np.all([target_pos[0] > fov[0], target_pos[0] < fov[1],
                            target_pos[1] > fov[2], target_pos[1] < fov[3]]))

    def _is_occluded(self, target_pos) -> bool:
        """Delegates to shared Occlusions.in_occlusion()."""
        return bool(self.occlusions.in_occlusion(
            np.asarray(target_pos, dtype=np.float64)))

    # ═══════════════════════════════════════════════════════════════════════════
    # Observation building
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_observation(self, agent_state, target_estimates, confidences=None):
        """
        Build the observation dict / vector.

        targets slot:  [rel_x, rel_y, rel_vx, rel_vy, conf]
        conf = 0  →   all five values zeroed; LSTM h_t carries the trajectory.
        conf > 0  →   real PF estimate in agent-relative coordinates.
        """
        agent_pos = agent_state[:2]
        agent_vel = agent_state[3:5]

        if confidences is None:
            confidences = [1.0] * len(target_estimates)

        # ── Attention (dict obs) ───────────────────────────────────────────────
        if self.use_attention:
            agent_obs   = np.array([agent_pos[0], agent_pos[1],
                                    agent_vel[0], agent_vel[1]], dtype=np.float32)
            targets_obs = np.zeros((self.max_tracked_targets, 5), dtype=np.float32)
            mask        = np.zeros(self.max_tracked_targets, dtype=np.float32)

            target_data = sorted(
                [(np.linalg.norm(est[:2] - agent_pos), j, est, conf)
                 for j, (est, conf) in enumerate(zip(target_estimates, confidences))],
                key=lambda x: x[0]
            )

            for i, (_, _j, estimate, conf) in enumerate(
                    target_data[:self.max_tracked_targets]):
                if conf > 0.0:
                    rel_pos = estimate[:2] - agent_pos
                    rel_vel = (estimate[2:4] if len(estimate) >= 4
                               else np.zeros(2)) - agent_vel
                    targets_obs[i] = [rel_pos[0], rel_pos[1],
                                      rel_vel[0], rel_vel[1], conf]
                else:
                    targets_obs[i] = [0., 0., 0., 0., 0.]
                mask[i] = 1.0

            return {'agent': agent_obs, 'targets': targets_obs, 'mask': mask}

        # ── Single nearest target (flat) ───────────────────────────────────────
        elif self.track_nearest_only:
            obs = [agent_pos[0], agent_pos[1], agent_vel[0], agent_vel[1]]
            min_dist, nearest_est, nearest_conf = float('inf'), None, 1.0
            for j, (est, conf) in enumerate(zip(target_estimates, confidences)):
                d = np.linalg.norm(est[:2] - agent_pos)
                if d < min_dist:
                    min_dist, nearest_est, nearest_conf = d, est, conf
                    self.nearest_target_idx = j
            if nearest_est is not None and nearest_conf > 0.0:
                rel_pos = nearest_est[:2] - agent_pos
                rel_vel = (nearest_est[2:4] if len(nearest_est) >= 4
                           else np.zeros(2)) - agent_vel
                obs.extend([rel_pos[0], rel_pos[1], rel_vel[0], rel_vel[1], nearest_conf])
            else:
                obs.extend([0., 0., 0., 0., 0.])
            return np.array(obs, dtype=np.float32)

        # ── All targets (flat) ─────────────────────────────────────────────────
        else:
            obs = [agent_pos[0], agent_pos[1], agent_vel[0], agent_vel[1]]
            for est, conf in zip(target_estimates, confidences):
                if conf > 0.0:
                    rel_pos = est[:2] - agent_pos
                    rel_vel = (est[2:4] if len(est) >= 4 else np.zeros(2)) - agent_vel
                    obs.extend([rel_pos[0], rel_pos[1], rel_vel[0], rel_vel[1], conf])
                else:
                    obs.extend([0., 0., 0., 0., 0.])
            return np.array(obs, dtype=np.float32)

    def _get_target_estimates(self, true_state):
        estimates = []
        for i in range(self.num_targets):
            if self.use_particle_filter:
                estimates.append(self.particle_filters[i].weighted_mean.copy())
            else:
                ts = true_state[1 + i]
                estimates.append(np.array([ts[0], ts[1], ts[3], ts[4]])
                                 if len(ts) >= 5 else ts[:2])
        return estimates

    # ═══════════════════════════════════════════════════════════════════════════
    # OSPA metric
    # ═══════════════════════════════════════════════════════════════════════════

    def compute_ospa_distance(self, tracker_positions, target_positions):
        from scipy.optimize import linear_sum_assignment
        n_trackers, n_targets = len(tracker_positions), len(target_positions)
        n = max(n_trackers, n_targets)
        if n == 0:
            return 0.0, 0.0, 0.0
        if n_trackers > 0 and n_targets > 0:
            distances = np.zeros((n_trackers, n_targets))
            for i, tp in enumerate(tracker_positions):
                for j, tgt in enumerate(target_positions):
                    distances[i, j] = min(np.linalg.norm(tp - tgt), self.ospa_cutoff)
            dp = distances ** self.ospa_order
            r, c = linear_sum_assignment(dp)
            loc_cost = float(np.sum(dp[r, c]))
        else:
            loc_cost = 0.0
        card_cost = (self.ospa_cutoff ** self.ospa_order) * abs(n_trackers - n_targets)
        total = loc_cost + card_cost
        ospa  = (total / n) ** (1.0 / self.ospa_order)
        loc_e = (loc_cost / n) ** (1.0 / self.ospa_order) if n > 0 else 0.0
        card_e = (self.ospa_cutoff * abs(n_trackers - n_targets) / n) if n > 0 else 0.0
        return ospa, loc_e, card_e

    # ═══════════════════════════════════════════════════════════════════════════
    # Reward computation
    # ═══════════════════════════════════════════════════════════════════════════

    def _compute_reward(self, state):
        agent_pos        = state[0, :2]
        target_positions = [state[1 + i, :2] for i in range(self.num_targets)]
        if self.reward_mode == 'distance':
            if self.track_nearest_only:
                return 1.0 / (np.linalg.norm(
                    agent_pos - state[1 + self.nearest_target_idx, :2]) + 0.1)
            return sum(1.0 / (np.linalg.norm(agent_pos - state[1 + i, :2]) + 0.1)
                       for i in range(self.num_targets)) / self.num_targets
        elif self.reward_mode == 'ospa':
            _, loc, card = self.compute_ospa_distance([agent_pos], target_positions)
            eps = 0.1
            return self.w_localization / (loc + eps) + self.w_cardinality / (card + eps)
        elif self.reward_mode == 'ospa_info':
            _, loc, card = self.compute_ospa_distance([agent_pos], target_positions)
            nloc, ncard = loc / self.ospa_cutoff, card / self.ospa_cutoff
            eps = 0.1
            return (self.w_localization / (nloc + eps) + self.w_cardinality / (ncard + eps)
                    + self.w_info * self._compute_information_gain(agent_pos))
        else:
            raise ValueError(f"Unknown reward_mode: {self.reward_mode}")

    def _compute_information_gain(self, sensor_position):
        if not self.use_particle_filter or not self.particle_filters:
            return 0.0
        R, H, total = np.array([[0.1, 0.], [0., 0.1]]), np.eye(2), 0.0
        for pf in self.particle_filters:
            particles = pf.particles[-1, :, :2]
            weights   = pf.weights
            mean      = np.average(particles, weights=weights, axis=0)
            cov       = sum(w * np.outer(d, d)
                            for w, d in zip(weights, particles - mean)) + 1e-6 * np.eye(2)
            if np.linalg.norm(sensor_position - mean) > 10.0:
                continue
            try:
                S = H @ cov @ H.T + R
                K = cov @ H.T @ np.linalg.inv(S)
                post = (np.eye(2) - K @ H) @ cov
                dp, dpo = np.linalg.det(cov), np.linalg.det(post)
                if dp > 1e-12 and dpo > 1e-12:
                    total += (0.5 * np.log(dp / dpo) *
                              np.exp(-np.linalg.norm(sensor_position - mean) / 5.0))
            except np.linalg.LinAlgError:
                continue
        return total

    def _add_measurement_noise(self, true_position, noise_std=0.05):
        return true_position + np.random.normal(0, noise_std, size=2)

    # ═══════════════════════════════════════════════════════════════════════════
    # reset()
    # ═══════════════════════════════════════════════════════════════════════════

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.history_manager.save()

        self.current_step, self.current_time, self.nearest_target_idx = 0, 0.0, 0
        self.episode_count += 1

        progress = (min(1.0, self.episode_count / self.curriculum_episodes)
                    if self.use_curriculum else 1.0)

        if self.episode_count > 1000:
            ramp = min(1.0, (self.episode_count - 1000) / 4000.0)
            self.w_track_continuity = 0.5 * ramp
            self.w_reacquisition    = 1.0 * ramp

        if self.episode_count % self.randomize_every_n_episodes == 0:
            self.env.randomize_transition_matrix(
                randomness=progress if self.use_curriculum else 1.0)

        self.env.randomize_fov(fov_min=self.fov_min, fov_max=self.fov_max,
                               curriculum_progress=progress)

        if self.randomize_occlusions:
            occ_centers, occ_widths = self.env.randomize_occlusions(
                num_occlusions=2, width_min=0.8, width_max=1.5)
        else:
            occ_centers, occ_widths = self.env.set_fixed_occlusions(
                occ_centers_meters=[-1.0, 0.0, 1.0, 0.0],
                occ_widths_meters=[1.0, 1.0])

        if occ_centers is not None and len(occ_centers) > 0:
            self.occlusions = Occlusions(
                [occ_centers[i * 2:(i + 1) * 2] for i in range(len(occ_widths))],
                occ_widths)
        else:
            self.occlusions = Occlusions([], [])

        self.env.reset()
        state = self.env.getState()

        if self.use_particle_filter:
            for i in range(self.num_targets):
                noisy = self._add_measurement_noise(state[1 + i, :2])
                self.particle_filters[i].gaussian_reset(noisy)
                self.particle_filters[i].last_time    = 0.0
                self.particle_filters[i].current_time = 0.0

        for s in self.track_status:
            s.update({'status': 'ACTIVE', 'last_seen_time': 0.0,
                      'last_seen_pos': None, 'lost_time': 0.0})
        self.prev_track_status  = [s.copy() for s in self.track_status]
        self._render_particle_tracks = []
        self._render_detections      = []

        if self.render_mode == 'human':
            self.env.render_init(
                occ_centers=occ_centers if occ_centers else None,
                occ_widths=occ_widths   if occ_widths  else None,
                fov_size=self.env.fov_size_meters,
            )

        estimates = self._get_target_estimates(state)
        obs = self._get_observation(state[0], estimates)
        return obs, {
            'agent_pos':          state[0, :2],
            'target_positions':   [state[1 + i, :2] for i in range(self.num_targets)],
            'target_estimates':   estimates,
            'nearest_target_idx': self.nearest_target_idx if self.track_nearest_only else None,
        }

    # ═══════════════════════════════════════════════════════════════════════════
    # step()
    # ═══════════════════════════════════════════════════════════════════════════

    def step(self, action):
        """
        1. Visibility gate  : box FOV + Occlusions.in_occlusion()
        2. PF update        : predict + (conditional) correct
        3. Confidence       : neff/(0.7N) if visible else 0
        4. Track status     : ACTIVE ↔ LOST
        5. History append   : visible obs only (Phase 2)
        6. Observation      : zeroed for lost targets
        7. Reward           : OSPA + track-loss penalty + reacq bonus
        """
        self.current_step += 1
        self.current_time += self.env.dt

        next_state, done = self.env.step(
            action,
            particle_tracks=self._render_particle_tracks,
            detections=self._render_detections,
        )

        agent_pos = next_state[0, :2]
        fov       = self._construct_fov(agent_pos)
        self.prev_track_status = [s.copy() for s in self.track_status]

        target_estimates, confidences, visibility_flags = [], [], []

        for i in range(self.num_targets):
            true_pos = next_state[1 + i, :2]
            in_occ   = self._is_occluded(true_pos)
            in_fov   = self._is_in_fov(true_pos, fov)
            visible  = in_fov and not in_occ
            visibility_flags.append(visible)

            if self.use_particle_filter:
                pf = self.particle_filters[i]
                pf.is_update = visible
                meas = (self._add_measurement_noise(true_pos)
                        if visible else pf.weighted_mean[:2].copy())
                pf.pf_loop(noisy_measurement=meas, t=self.current_time)
                est  = pf.weighted_mean.copy()
                conf = min(1.0, pf.neff / (0.7 * pf.N)) if visible else 0.0
            else:
                ts   = next_state[1 + i]
                est  = np.array([ts[0], ts[1], ts[3], ts[4]])
                conf = 1.0 if visible else 0.0

            target_estimates.append(est)
            confidences.append(conf)

            s = self.track_status[i]
            if visible:
                s.update({'status': 'ACTIVE', 'last_seen_time': self.current_time,
                          'last_seen_pos': true_pos.copy()})
            elif s['status'] == 'ACTIVE':
                s.update({'status': 'LOST', 'lost_time': self.current_time})

            # Phase 2: record visible observations
            if visible and self.use_particle_filter:
                self.history_manager.add(
                    target_id=i, position=true_pos,
                    velocity=next_state[1 + i, 3:5],
                    timestamp=self.current_time, episode=self.episode_count)

        if self.render_mode == 'human':
            self._render_particle_tracks = (
                [pf.particles for pf in self.particle_filters]
                if self.use_particle_filter else [])
            self._render_detections = [
                next_state[1 + i, :2] for i, v in enumerate(visibility_flags) if v]

        obs          = self._get_observation(next_state[0], target_estimates, confidences)
        base_reward  = self._compute_reward(next_state)
        track_pen    = 0.0
        reacq_bonus  = 0.0

        for i in range(self.num_targets):
            cur, prev = self.track_status[i], self.prev_track_status[i]
            if cur['status'] == 'LOST' and prev['status'] == 'ACTIVE':
                track_pen -= 2.0
            if cur['status'] == 'LOST':
                track_pen -= 0.05 * min(self.current_time - cur['lost_time'], 20.0)
            if cur['status'] == 'ACTIVE' and prev['status'] == 'LOST':
                reacq_bonus += 5.0

        reward    = (base_reward + self.w_track_continuity * track_pen
                     + self.w_reacquisition * reacq_bonus)
        terminated = bool(done)
        truncated  = self.current_step >= self.max_steps

        info = {
            'agent_pos':          next_state[0, :2],
            'target_positions':   [next_state[1 + i, :2] for i in range(self.num_targets)],
            'target_estimates':   target_estimates,
            'nearest_target_idx': self.nearest_target_idx if self.track_nearest_only else None,
            'estimation_errors':  [float(np.linalg.norm(next_state[1 + i, :2] - e[:2]))
                                   for i, e in enumerate(target_estimates)],
            'target_visible':     visibility_flags,
            'target_confidences': confidences,
            'n_lost':             sum(1 for s in self.track_status if s['status'] == 'LOST'),
            'track_penalty':      track_pen,
            'reacq_bonus':        reacq_bonus,
        }

        if self.render_mode == 'human':
            self.env.render()

        return obs, reward, terminated, truncated, info

    # ═══════════════════════════════════════════════════════════════════════════
    # Render / close
    # ═══════════════════════════════════════════════════════════════════════════

    def render(self):
        if self.render_mode != 'human':
            return
        if self.use_attention:
            self._draw_history_overlay()
        self.env.render()

    def _m_to_px(self, pos_m):
        ppm, c = self.env.pixels_per_meter, self.env.env_center_pixels
        return (int(pos_m[0] * ppm + c), int(-pos_m[1] * ppm + c))

    def _draw_history_overlay(self):
        try:
            import pygame
        except ImportError:
            return
        surface = self.env.main_surface
        palette = [(220, 50, 50), (50, 180, 50), (50, 100, 220), (220, 160, 0),
                   (180, 50, 180), (0, 180, 180), (220, 100, 50), (100, 220, 100)]
        for i in range(self.num_targets):
            color = palette[i % len(palette)]
            for pos in self.history_manager.get_positions(i, last_n=30):
                pygame.draw.circle(surface, color, self._m_to_px(pos), 2)

    def close(self):
        self.env.close()
