"""
Cross-episode observation history buffer for multi-target tracking.

Each target gets its own circular buffer (deque) of recorded positions.
The buffer is used by GymPursuitEnv.construct_search_prior() to fit a GMM
over where targets have been seen, giving the agent a learned "where to look"
signal when a track is lost.

Storage policy
--------------
Default  (save_to_file=False): in-memory only.
  - Buffer accumulates across episodes within one training run.
  - Cleared when the Python process restarts (no stale-data risk).
  - Sufficient for GMM fitting after ~10 episodes (~1000 observations).

Optional (save_to_file=True): persisted to a pickle file.
  - Saved after every episode; loaded on startup if the file exists.
  - Allows the GMM to benefit from observations across training runs.
  - Clear the file between experiments if the environment layout changes.
"""

import os
import pickle
import numpy as np
from collections import deque


class ObservationHistoryManager:
    """
    Circular buffer of valid (visible) target observations, one deque per target.

    Each entry:
        position  : np.float32[2]  — target x, y in meters
        velocity  : np.float32[2]  — target vx, vy in m/s
        timestamp : float          — within-episode time (seconds)
        episode   : int            — episode index

    Only visible observations are recorded (confidence > 0).  Occluded or
    out-of-FOV steps are skipped so the GMM learns the true reachable space,
    not PF drift.
    """

    def __init__(self, num_targets: int, max_size: int = 1000,
                 save_to_file: bool = False, save_path: str = 'obs_history.pkl'):
        self.num_targets  = num_targets
        self.max_size     = max_size
        self.save_to_file = save_to_file
        self.save_path    = save_path

        # One circular buffer per target
        self.history: list[deque] = [
            deque(maxlen=max_size) for _ in range(num_targets)
        ]

        if save_to_file:
            self._load()

    # ── write ─────────────────────────────────────────────────────────────────

    def add(self, target_id: int, position, velocity, timestamp: float,
            episode: int) -> None:
        """Append one valid observation for target_id."""
        self.history[target_id].append({
            'position':  np.asarray(position,  dtype=np.float32),
            'velocity':  np.asarray(velocity,  dtype=np.float32),
            'timestamp': float(timestamp),
            'episode':   int(episode),
        })

    # ── read ──────────────────────────────────────────────────────────────────

    def get_positions(self, target_id: int, last_n: int | None = None) -> np.ndarray:
        """
        Return (N, 2) float32 array of recorded positions for target_id.

        Args:
            target_id : which target
            last_n    : if given, return only the most recent last_n entries

        Returns empty array with shape (0, 2) if no observations exist.
        """
        buf = list(self.history[target_id])
        if last_n is not None:
            buf = buf[-last_n:]
        if len(buf) == 0:
            return np.empty((0, 2), dtype=np.float32)
        return np.array([e['position'] for e in buf], dtype=np.float32)

    def count(self, target_id: int) -> int:
        """Number of stored observations for target_id."""
        return len(self.history[target_id])

    def total_count(self) -> int:
        """Total observations across all targets."""
        return sum(len(h) for h in self.history)

    # ── persistence (only when save_to_file=True) ─────────────────────────────

    def save(self) -> None:
        """Write history to disk (no-op if save_to_file=False)."""
        if not self.save_to_file:
            return
        try:
            with open(self.save_path, 'wb') as f:
                pickle.dump(self.history, f)
        except OSError:
            pass  # non-fatal: skip if disk is full or path is read-only

    def _load(self) -> None:
        """Load history from disk if the file exists."""
        if not os.path.exists(self.save_path):
            return
        try:
            with open(self.save_path, 'rb') as f:
                loaded = pickle.load(f)
            if isinstance(loaded, list) and len(loaded) == self.num_targets:
                self.history = [
                    deque(list(d)[-self.max_size:], maxlen=self.max_size)
                    for d in loaded
                ]
        except Exception:
            pass  # corrupted or incompatible file → start fresh
