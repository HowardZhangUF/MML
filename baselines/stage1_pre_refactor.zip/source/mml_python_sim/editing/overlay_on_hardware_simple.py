"""
Simple Hardware Overlay - Image with Axis and Legend (No Trajectories)
=======================================================================

Displays hardware.png with clean axes and a legend,
maintaining aspect ratio and original image colors.
"""

import matplotlib.pyplot as plt
import cv2

# ============================================
# CONFIGURATION
# ============================================
HARDWARE_IMAGE = '/home/basestation/mml_python_sim/editing/frame_1389.png'
OUTPUT_IMAGE = '/home/basestation/mml_python_sim/editing/hardware_axes_only.png'

# Colors and names for the legend
COLORS = {
    'drone': 'magenta',
    'turtle1': 'lightgreen',
    'turtle2': 'yellow'
}

ROBOT_NAME_MAP = {
    'drone': 'Drone',
    'turtle1': 'Target 1',
    'turtle2': 'Target 2'
}

# ============================================
# LOAD DATA
# ============================================
print("Loading hardware image...")
hardware_img = cv2.cvtColor(cv2.imread(HARDWARE_IMAGE), cv2.COLOR_BGR2RGB)
img_height, img_width = hardware_img.shape[:2]

print(f"Hardware image loaded: {img_width}x{img_height} pixels")

# ============================================
# CALCULATE PROPER EXTENT & LIMITS
# ============================================
# Calculate aspect ratio to prevent image stretching
aspect_ratio = img_width / img_height

# Assuming Y spans from -3 to 3, calculate the proper X span to keep the aspect ratio
y_min, y_max = -3.0, 3.0
x_range = (y_max - y_min) * aspect_ratio
x_min, x_max = -x_range / 2, x_range / 2

WORLD_EXTENT = [x_min, x_max, y_min, y_max]

# ============================================
# CREATE PLOT
# ============================================
fig, ax = plt.subplots(figsize=(12, 12))

# Background image - alpha set to 1.0 to prevent whitening
ax.imshow(hardware_img, extent=WORLD_EXTENT, alpha=1.0, aspect='equal')

# Create legend entries directly from the dictionaries
for robot_id, color in COLORS.items():
    label = ROBOT_NAME_MAP.get(robot_id, robot_id.upper())
    # Added a 'solid_capstyle' and 'path_effects' or just simple plotting 
    # to ensure the light colors are visible. 
    ax.plot([], [], color=color, linewidth=4, alpha=1.0, label=label,
            solid_capstyle='round')

# Generic START/END markers for legend
ax.scatter([], [], c='gray', s=200, marker='o', edgecolors='black', 
           linewidths=2, label='Start')


# Styling 
ax.set_xlabel('X Position (meters)', fontsize=14)
ax.set_ylabel('Y Position (meters)', fontsize=14)

# Added a slight gray background to the legend so the light yellow pops
legend = ax.legend(fontsize=12, loc='best', facecolor='#f0f0f0', framealpha=0.9)

# Turn off the grid
ax.grid(False)

# Force equal aspect ratio so the image isn't distorted
ax.set_aspect('equal')

# Set axes limits to exactly match the newly calculated image extent
ax.set_xlim([x_min, x_max])
ax.set_ylim([y_min, y_max])

# Save
fig.savefig(OUTPUT_IMAGE, dpi=300, bbox_inches='tight')
print(f"✓ Saved: {OUTPUT_IMAGE}")

plt.show()