"""
Analyze Multi-Robot Trajectories from CSRT Tracker
===================================================

Visualizes and analyzes the trajectories extracted from csrt_robot_tracker.py
Creates plots showing individual robot paths, velocities, and movement statistics.

Features:
- Multi-panel visualization (6 plots)
- Interactive trajectory filtering (terminal prompts)
- Speed outlier removal
- Distance and velocity calculations
- Per-robot statistics export

Interactive Prompts:
1. Filter mode: None / All / Selective
2. Frames to cut from end (if filtering enabled)
3. Which robots to cut (if selective mode)

Usage:
    python analyze_csrt_trajectories.py
    
    # Example session:
    Filter mode? 
      1. None (use all data)
      2. All (cut all robots at same point)
      3. Selective (cut specific robots only)
    Enter choice (1/2/3): 3
    
    How many frames to cut from END? [default: 100]: 150
    
    Available robots: drone, turtle1, turtle2
    Which robots to cut? (comma-separated): drone
    
    ✓ Analysis begins with filtered data
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# ============================================
# CONFIGURATION
# ============================================
INPUT_CSV = '/home/basestation/mml_python_sim/editing/robot_trajectories_csrt.csv'
OUTPUT_PLOT = '/home/basestation/mml_python_sim/editing/robot_trajectories_analysis.png'

print("Loading trajectory data...")
df = pd.read_csv(INPUT_CSV)

# Show initial data stats
print(f"\nInitial data:")
print(f"  Total points: {len(df)}")
print(f"  Frame range: {df['frame'].min()} to {df['frame'].max()}")
print(f"  Robots: {', '.join(df['robot'].unique())}")

# --- INTERACTIVE TRAJECTORY FILTERING ---
print("\n" + "="*60)
print("TRAJECTORY FILTERING OPTIONS")
print("="*60)

filter_choice = input("\nFilter mode?\n  1. None (use all data) [default]\n  2. All (cut all robots at same point)\n  3. Selective (cut specific robots only)\nEnter choice (1/2/3) [default=1]: ").strip()

FILTER_MODE = 'none'
if filter_choice == '2':
    FILTER_MODE = 'all'
elif filter_choice == '3':
    FILTER_MODE = 'selective'
elif filter_choice not in ['', '1', '2', '3']:
    print(f"⚠️  Invalid choice '{filter_choice}', using default (none)")
    FILTER_MODE = 'none'

FRAMES_TO_CUT = 0
ROBOTS_TO_CUT = []

if FILTER_MODE != 'none':
    max_frame = df['frame'].max()
    
    # Ask how many frames to cut
    frames_input = input(f"\nHow many frames to cut from END? [default: 100]: ").strip()
    FRAMES_TO_CUT = int(frames_input) if frames_input else 100
    
    cutoff_frame = max_frame - FRAMES_TO_CUT
    
    if FILTER_MODE == 'all':
        # Cut ALL robots at the same point
        df_original_size = len(df)
        df = df[df['frame'] <= cutoff_frame]
        print(f"\n🔪 Truncated ALL robots:")
        print(f"   Removed {df_original_size - len(df)} points")
        print(f"   Cutoff frame: {cutoff_frame}/{max_frame}")
        
    elif FILTER_MODE == 'selective':
        # Ask which robots to cut
        available_robots = df['robot'].unique()
        print(f"\nAvailable robots: {', '.join(available_robots)}")
        robots_input = input("Which robots to cut? (comma-separated, e.g., drone,turtle1): ").strip()
        
        if robots_input:
            ROBOTS_TO_CUT = [r.strip() for r in robots_input.split(',')]
            
            df_original_size = len(df)
            
            # Build filter condition
            cut_condition = False
            for robot in ROBOTS_TO_CUT:
                if robot in available_robots:
                    cut_condition |= ((df['robot'] == robot) & (df['frame'] > cutoff_frame))
            
            df = df[~cut_condition]
            
            print(f"\n🔪 Selective truncation:")
            print(f"   Robots cut: {', '.join(ROBOTS_TO_CUT)}")
            print(f"   Removed {df_original_size - len(df)} points")
            print(f"   Cutoff frame: {cutoff_frame}/{max_frame}")
        else:
            print("\n⚠️  No robots specified, using all data")
else:
    print("\n✓ No filtering applied, using all data")

# Get robot names (after filtering)
robots = df['robot'].unique()
print(f"\nFiltered data:")
print(f"  Robots: {', '.join(robots)}")
print(f"  Total data points: {len(df)}")
print()

# Colors for each robot (matching CSRT tracker)
COLORS = {
    'drone': 'magenta',
    'turtle1': 'green',
    'turtle2': 'cyan'
}

# ============================================
# CREATE MULTI-PANEL PLOT
# ============================================
fig = plt.figure(figsize=(20, 12))

# 1. XY Trajectories (all robots)
ax1 = plt.subplot(2, 3, 1)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    
    ax1.plot(robot_df['world_x'], robot_df['world_y'], 
             color=color, linewidth=2, alpha=0.7, label=robot.upper())
    
    # Start point
    ax1.scatter(robot_df['world_x'].iloc[0], robot_df['world_y'].iloc[0],
               c=color, s=150, marker='o', edgecolors='black', zorder=5)
    
    # End point
    ax1.scatter(robot_df['world_x'].iloc[-1], robot_df['world_y'].iloc[-1],
               c=color, s=150, marker='X', edgecolors='black', zorder=5)

# Add corner markers
# corners = [(-1.5, 1.5), (1.5, 1.5), (-1.5, -1.5), (1.5, -1.5)]
# corner_labels = ['Node 0', 'Node 2', 'Node 3', 'Node 7']
# for (x, y), label in zip(corners, corner_labels):
#     ax1.scatter(x, y, c='orange', s=100, marker='s', 
#                edgecolors='black', alpha=0.6, zorder=3)
#     ax1.text(x, y+0.15, label, ha='center', fontsize=8)

ax1.set_xlabel('X Position (meters)')
ax1.set_ylabel('Y Position (meters)')
ax1.set_title('Robot Trajectories (World Coordinates)', fontweight='bold')
ax1.legend()
ax1.grid(True, alpha=0.3)
ax1.axis('equal')

# NEW: Save standalone XY trajectory plot
fig_single = plt.figure(figsize=(10, 10))
ax_single = fig_single.add_subplot(111)

for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    
    ax_single.plot(robot_df['world_x'], robot_df['world_y'], 
                   color=color, linewidth=3, alpha=0.8, label=robot.upper())
    
    # Start point
    ax_single.scatter(robot_df['world_x'].iloc[0], robot_df['world_y'].iloc[0],
                     c=color, s=200, marker='o', edgecolors='black', 
                     linewidths=2, zorder=5, label=f'{robot.upper()} START')
    
    # End point
    ax_single.scatter(robot_df['world_x'].iloc[-1], robot_df['world_y'].iloc[-1],
                     c=color, s=200, marker='X', edgecolors='black', 
                     linewidths=2, zorder=5, label=f'{robot.upper()} END')

ax_single.set_xlabel('X Position (meters)', fontsize=14)
ax_single.set_ylabel('Y Position (meters)', fontsize=14)
ax_single.set_title('Robot Trajectories (World Coordinates)', fontsize=16, fontweight='bold')
ax_single.legend(fontsize=10, loc='best')
ax_single.grid(True, alpha=0.3)
ax_single.axis('equal')

# Save standalone plot
# ...existing code...

# NEW: Save standalone XY trajectory plot
fig_single = plt.figure(figsize=(10, 10))
ax_single = fig_single.add_subplot(111)

# First pass: Draw trajectories and markers (without labels)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    
    # Trajectory line (no label yet)
    ax_single.plot(robot_df['world_x'], robot_df['world_y'], 
                   color=color, linewidth=3, alpha=0.8)
    
    # Start point (no label)
    ax_single.scatter(robot_df['world_x'].iloc[0], robot_df['world_y'].iloc[0],
                     c=color, s=200, marker='o', edgecolors='black', 
                     linewidths=2, zorder=5)
    
    # End point (no label)
    ax_single.scatter(robot_df['world_x'].iloc[-1], robot_df['world_y'].iloc[-1],
                     c=color, s=200, marker='X', edgecolors='black', 
                     linewidths=2, zorder=5)

# Second pass: Create legend entries (only once for each type)
# Add dummy plots just for legend
# ...existing code...

robot_name_map = {
    'drone': 'Drone',
    'turtle1': 'Target 1',
    'turtle2': 'Target 2'
}

for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    label = robot_name_map.get(robot, robot.upper())
    
    # Add invisible line just for legend
    ax_single.plot([], [], color=color, linewidth=3, alpha=0.8, label=label)

# Add generic START and END markers to legend
ax_single.scatter([], [], c='gray', s=200, marker='o', edgecolors='black', 
                 linewidths=2, label='Start')
ax_single.scatter([], [], c='gray', s=200, marker='X', edgecolors='black', 
                 linewidths=2, label='End')

# Styling to match hardware.png
ax_single.set_xlabel('X Position (meters)', fontsize=16, fontweight='bold')
ax_single.set_ylabel('Y Position (meters)', fontsize=16, fontweight='bold')
ax_single.tick_params(axis='both', which='major', labelsize=14)

# Legend styling - professional appearance
ax_single.legend(fontsize=12, loc='best', frameon=True, 
                fancybox=True, shadow=True, framealpha=0.95,
                edgecolor='black', facecolor='white')

# Grid styling
ax_single.grid(True, alpha=0.4, linestyle='--', linewidth=0.8, color='gray')

# Equal aspect ratio for proper coordinate display
ax_single.axis('equal')

# # Optional: Set axis limits with padding
# x_min, x_max = df['world_x'].min(), df['world_x'].max()
# y_min, y_max = df['world_y'].min(), df['world_y'].max()
# padding = 0.3  # 30cm padding around trajectories
# ax_single.set_xlim(x_min - padding, x_max + padding)
# ax_single.set_ylim(y_min - padding, y_max + padding)

# Add border around plot
for spine in ax_single.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.5)

# Save standalone plot
standalone_output = OUTPUT_PLOT.replace('.png', '_xy_only.png')
fig_single.savefig(standalone_output, dpi=300, bbox_inches='tight', 
                   facecolor='white', edgecolor='black')
print(f"Standalone XY plot saved: {standalone_output}")

# ...existing code...

# 2. X Position vs Time
ax2 = plt.subplot(2, 3, 2)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    ax2.plot(robot_df['time'], robot_df['world_x'], 
             color=color, linewidth=1.5, label=robot.upper())

ax2.set_xlabel('Time (seconds)')
ax2.set_ylabel('X Position (meters)')
ax2.set_title('X Position over Time', fontweight='bold')
ax2.legend()
ax2.grid(True, alpha=0.3)

# 3. Y Position vs Time
ax3 = plt.subplot(2, 3, 3)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    ax3.plot(robot_df['time'], robot_df['world_y'], 
             color=color, linewidth=1.5, label=robot.upper())

ax3.set_xlabel('Time (seconds)')
ax3.set_ylabel('Y Position (meters)')
ax3.set_title('Y Position over Time', fontweight='bold')
ax3.legend()
ax3.grid(True, alpha=0.3)

# 4. Speed vs Time
ax4 = plt.subplot(2, 3, 4)
for robot in robots:
    robot_df = df[df['robot'] == robot].copy()
    if 'speed' in robot_df.columns:
        color = COLORS.get(robot, 'blue')
        # Remove outliers (speed > 2 m/s is likely tracking error)
        robot_df = robot_df[robot_df['speed'] < 2.0]
        ax4.plot(robot_df['time'], robot_df['speed'], 
                color=color, linewidth=1.5, alpha=0.7, label=robot.upper())

ax4.set_xlabel('Time (seconds)')
ax4.set_ylabel('Speed (m/s)')
ax4.set_title('Robot Speed over Time', fontweight='bold')
ax4.legend()
ax4.grid(True, alpha=0.3)

# 5. Distance from Origin
ax5 = plt.subplot(2, 3, 5)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    
    distance = np.sqrt(robot_df['world_x']**2 + robot_df['world_y']**2)
    ax5.plot(robot_df['time'], distance, 
             color=color, linewidth=1.5, label=robot.upper())

ax5.set_xlabel('Time (seconds)')
ax5.set_ylabel('Distance from Origin (meters)')
ax5.set_title('Distance from Center over Time', fontweight='bold')
ax5.legend()
ax5.grid(True, alpha=0.3)

# 6. Statistics Table
ax6 = plt.subplot(2, 3, 6)
ax6.axis('off')

stats_text = "TRAJECTORY STATISTICS\n" + "="*40 + "\n\n"

for robot in robots:
    robot_df = df[df['robot'] == robot].copy()
    
    # Filter outliers for statistics
    if 'speed' in robot_df.columns:
        robot_df_clean = robot_df[robot_df['speed'] < 2.0]
    else:
        robot_df_clean = robot_df
    
    duration = robot_df['time'].iloc[-1] - robot_df['time'].iloc[0]
    
    # Calculate total distance (sum of distances between consecutive points)
    dx = robot_df['world_x'].diff()
    dy = robot_df['world_y'].diff()
    distances = np.sqrt(dx**2 + dy**2)
    total_distance = distances.sum()
    
    stats_text += f"{robot.upper()}:\n"
    stats_text += f"  Duration: {duration:.2f} seconds\n"
    stats_text += f"  Data points: {len(robot_df)}\n"
    stats_text += f"  Distance traveled: {total_distance:.2f} m\n"
    
    if 'speed' in robot_df_clean.columns and len(robot_df_clean) > 0:
        stats_text += f"  Avg speed: {robot_df_clean['speed'].mean():.3f} m/s\n"
        stats_text += f"  Max speed: {robot_df_clean['speed'].max():.3f} m/s\n"
    
    # Position range
    x_range = robot_df['world_x'].max() - robot_df['world_x'].min()
    y_range = robot_df['world_y'].max() - robot_df['world_y'].min()
    stats_text += f"  X range: {x_range:.2f} m\n"
    stats_text += f"  Y range: {y_range:.2f} m\n"
    stats_text += "\n"

ax6.text(0.1, 0.9, stats_text, transform=ax6.transAxes,
         fontsize=10, verticalalignment='top', fontfamily='monospace')

plt.tight_layout()
plt.savefig(OUTPUT_PLOT, dpi=150, bbox_inches='tight')
print(f"\nPlot saved: {OUTPUT_PLOT}")

# ============================================
# CONSOLE STATISTICS
# ============================================
print(f"\n{'='*50}")
print("TRAJECTORY STATISTICS")
print(f"{'='*50}")

for robot in robots:
    robot_df = df[df['robot'] == robot].copy()
    
    # Filter outliers
    if 'speed' in robot_df.columns:
        robot_df_clean = robot_df[robot_df['speed'] < 2.0]
    else:
        robot_df_clean = robot_df
    
    duration = robot_df['time'].iloc[-1] - robot_df['time'].iloc[0]
    
    # Calculate total distance
    dx = robot_df['world_x'].diff()
    dy = robot_df['world_y'].diff()
    distances = np.sqrt(dx**2 + dy**2)
    total_distance = distances.sum()
    
    print(f"\n{robot.upper()}:")
    print(f"  ⏱️  Duration: {duration:.2f} seconds")
    print(f"  📍 Data points: {len(robot_df)}")
    print(f"  📏 Distance traveled: {total_distance:.2f} meters")
    
    if 'speed' in robot_df_clean.columns and len(robot_df_clean) > 0:
        print(f"  🚀 Average speed: {robot_df_clean['speed'].mean():.3f} m/s")
        print(f"  ⚡ Max speed: {robot_df_clean['speed'].max():.3f} m/s")
    
    # Position statistics
    print(f"  📊 Position range:")
    print(f"     X: [{robot_df['world_x'].min():.2f}, {robot_df['world_x'].max():.2f}] meters")
    print(f"     Y: [{robot_df['world_y'].min():.2f}, {robot_df['world_y'].max():.2f}] meters")

print(f"\n{'='*50}")
print("✓ Analysis complete!")
print(f"{'='*50}")

# ============================================
# OPTIONAL: SAVE INDIVIDUAL ROBOT CSVS
# ============================================
save_individual = input("\nSave individual robot CSVs? (y/n): ").lower() == 'y'

if save_individual:
    for robot in robots:
        robot_df = df[df['robot'] == robot]
        filename = f'trajectory_{robot}.csv'
        robot_df.to_csv(filename, index=False)
        print(f"  ✓ Saved {filename}")