import cv2
import numpy as np

# Load the road network PNG
road_img = cv2.imread('/home/basestation/mml_python_sim/scripts/road_network.png')

if road_img is None:
    print("Could not load road_network.png")
    exit()

# Resize for easier viewing if needed
display_img = road_img.copy()
scale = 1.0
if road_img.shape[0] > 800:
    scale = 800.0 / road_img.shape[0]
    new_width = int(road_img.shape[1] * scale)
    new_height = int(road_img.shape[0] * scale)
    display_img = cv2.resize(road_img, (new_width, new_height))

node_labels = ["Node 0 (-1.5, 1)", "Node 2 (2.1, 1)", "Node 3 (-1.5, -1)", "Node 7 (2.1, -1)"]
points = []
current = 0

def mouse_callback(event, x, y, flags, param):
    global current, points
    
    if event == cv2.EVENT_LBUTTONDOWN and current < 4:
        # Scale back to original coordinates
        orig_x = int(x / scale)
        orig_y = int(y / scale)
        
        points.append([orig_x, orig_y])
        print(f"{node_labels[current]}: [{orig_x}, {orig_y}]")
        current += 1
        
        if current >= 4:
            print("\nCopy this into your code:")
            print(f"pts_matplotlib = np.float32({points})")

cv2.namedWindow("Click on Node 0, 2, 3, 7 (in order)")
cv2.setMouseCallback("Click on Node 0, 2, 3, 7 (in order)", mouse_callback)

print("Click on nodes in this order:")
for label in node_labels:
    print(f"  {label}")

while True:
    img_display = display_img.copy()
    
    # Draw collected points
    for i, pt in enumerate(points):
        pt_scaled = (int(pt[0] * scale), int(pt[1] * scale))
        cv2.circle(img_display, pt_scaled, 5, (0, 255, 0), -1)
        cv2.putText(img_display, str(i), (pt_scaled[0]+10, pt_scaled[1]), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    if current < 4:
        cv2.putText(img_display, f"Click: {node_labels[current]}", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    else:
        cv2.putText(img_display, "Done! Press 'q' to quit", 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    cv2.imshow("Click on Node 0, 2, 3, 7 (in order)", img_display)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()