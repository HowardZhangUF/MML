"""
Robot Trajectory Extraction using HSV Color Detection
======================================================

Description:
    Extracts robot positions from video by detecting robots based on their HSV color.
    Converts pixel coordinates to real-world coordinates (meters) using perspective
    transform. Outputs trajectory data including position, velocity, and speed.

Usage:
    python color_range.py

Input:
    - VIDEO_PATH: Path to input video file
    - HSV color range (LOWER_COLOR, UPPER_COLOR) from hsv.py
    - Perspective transform points (pts_video -> pts_world)

Output:
    - robot_trajectory.csv: CSV file with trajectory data
    - Debug visualization window (if debug_mode=True)
    - Console progress updates

CSV Output Columns:
    frame, time, pixel_x, pixel_y, world_x, world_y, vx, vy, speed, vx_smooth, vy_smooth

Example Console Output:
    Video: 1920x1080 @ 30.0 fps
    Processing video...
    Processed 100 frames, found 100 positions
    ...
    ==================================================
    Extraction complete!
    Total frames: 955
    Positions found: 951
    Detection rate: 99.6%
    Output saved to: robot_trajectory.csv
    ==================================================

Example CSV Output (robot_trajectory.csv):
    frame,time,pixel_x,pixel_y,world_x,world_y,vx,vy,speed
    0,0.0,1024,512,0.15,-0.23,,,
    1,0.033,1026,514,0.16,-0.22,0.30,0.30,0.42
    2,0.067,1028,516,0.17,-0.21,0.30,0.30,0.42
    ...

Controls (debug_mode=True):
    - 'q': Quit processing
    - 's': Save current frame as debug image
    - 'space': Pause/resume
"""

import cv2
import numpy as np
import pandas as pd
from datetime import datetime

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 2.mp4'
OUTPUT_CSV = 'robot_trajectory.csv'

# HSV color range for robot (from hsv.py tuning)
LOWER_COLOR = np.array([7, 0, 0])
UPPER_COLOR = np.array([68, 139, 175])

# Minimum contour area to filter noise
MIN_CONTOUR_AREA = 500

# Perspective transform points (from your video_editing.py)
# Video coordinates for the 4 corners
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

# Real-world coordinates (in meters) for those same corners
# Adjust these to match your actual lab setup
pts_world = np.float32([
    [-1.5, 1.5],   # Node 0 (x, y in meters)
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# ============================================
# SETUP
# ============================================
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))

print(f"Video: {width}x{height} @ {fps} fps")

# Calculate perspective transform (pixel -> world coordinates)
matrix = cv2.getPerspectiveTransform(pts_video, pts_world)

# Storage for trajectory
trajectory_data = []

# ============================================
# HELPER FUNCTIONS
# ============================================
def pixel_to_world(pixel_x, pixel_y):
    """Convert pixel coordinates to world coordinates (meters)"""
    point = np.array([[[pixel_x, pixel_y]]], dtype=np.float32)
    world_point = cv2.perspectiveTransform(point, matrix)
    return world_point[0][0][0], world_point[0][0][1]

def find_robot_centroid(frame, lower_color, upper_color):
    """Find robot position using color detection"""
    # Convert to HSV
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    # Create mask for the color
    mask = cv2.inRange(hsv, lower_color, upper_color)
    
    # Apply morphological operations to clean up
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    
    # Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        # Find largest contour (assumed to be the robot)
        largest_contour = max(contours, key=cv2.contourArea)
        
        if cv2.contourArea(largest_contour) > MIN_CONTOUR_AREA:
            # Get centroid using moments
            M = cv2.moments(largest_contour)
            if M["m00"] > 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                return cx, cy, mask
    
    return None, None, mask

# ============================================
# MAIN PROCESSING LOOP
# ============================================
frame_count = 0
debug_mode = True  # Set to True to visualize tracking

print("Processing video...")
print("Press 'q' to quit, 's' to save a frame, 'space' to pause")

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    timestamp = frame_count / fps
    
    # Find robot position
    pixel_x, pixel_y, mask = find_robot_centroid(frame, LOWER_COLOR, UPPER_COLOR)
    
    if pixel_x is not None:
        # Convert to world coordinates
        world_x, world_y = pixel_to_world(pixel_x, pixel_y)
        
        # Store data
        trajectory_data.append({
            'frame': frame_count,
            'time': timestamp,
            'pixel_x': pixel_x,
            'pixel_y': pixel_y,
            'world_x': world_x,
            'world_y': world_y
        })
        
        # Visualization
        if debug_mode:
            # Draw detection on frame
            cv2.circle(frame, (pixel_x, pixel_y), 10, (0, 255, 0), -1)
            cv2.putText(frame, f"({world_x:.2f}, {world_y:.2f})m", 
                       (pixel_x + 15, pixel_y), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    if debug_mode and frame_count % 3 == 0:  # Show every 3rd frame
        # Show frame
        display = cv2.resize(frame, (1280, 720))
        cv2.imshow('Tracking', display)
        
        # Show mask
        mask_display = cv2.resize(mask, (640, 360))
        cv2.imshow('Color Mask', mask_display)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('s'):
            cv2.imwrite(f'debug_frame_{frame_count}.png', frame)
            print(f"Saved debug frame {frame_count}")
        elif key == ord(' '):
            cv2.waitKey(0)  # Pause until any key
    
    frame_count += 1
    if frame_count % 100 == 0:
        print(f"Processed {frame_count} frames, found {len(trajectory_data)} positions")

video.release()
cv2.destroyAllWindows()

# ============================================
# SAVE RESULTS
# ============================================
df = pd.DataFrame(trajectory_data)

# Add velocity calculations
if len(df) > 1:
    df['vx'] = df['world_x'].diff() / df['time'].diff()
    df['vy'] = df['world_y'].diff() / df['time'].diff()
    df['speed'] = np.sqrt(df['vx']**2 + df['vy']**2)
    
    # Smooth velocity (rolling average)
    df['vx_smooth'] = df['vx'].rolling(window=5, center=True).mean()
    df['vy_smooth'] = df['vy'].rolling(window=5, center=True).mean()

df.to_csv(OUTPUT_CSV, index=False)

print(f"\n{'='*50}")
print(f"Extraction complete!")
print(f"Total frames: {frame_count}")
print(f"Positions found: {len(trajectory_data)}")
print(f"Detection rate: {100*len(trajectory_data)/frame_count:.1f}%")
print(f"Output saved to: {OUTPUT_CSV}")
print(f"{'='*50}")