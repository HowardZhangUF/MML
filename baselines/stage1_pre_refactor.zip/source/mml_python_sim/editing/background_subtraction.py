"""
Robot Trajectory Extraction using Background Subtraction
=========================================================

Description:
    Extracts robot positions from video by detecting moving objects using
    background subtraction (MOG2 algorithm). Best for scenarios where robots
    are the primary moving objects in the scene. Converts pixel coordinates
    to real-world coordinates using perspective transform.

Usage:
    python background_subtraction.py

Input:
    - VIDEO_PATH: Path to input video file
    - Perspective transform points (pts_video -> pts_world)

Output:
    - robot_trajectory_motion.csv: CSV file with trajectory data

CSV Output Columns:
    frame, time, world_x, world_y

Example Console Output:
    Frame 100
    Frame 200
    ...
    Frame 900
    Saved 927 positions to robot_trajectory_motion.csv

Example CSV Output (robot_trajectory_motion.csv):
    frame,time,world_x,world_y
    0,0.0,0.15,-0.23
    1,0.033,0.16,-0.22
    2,0.067,0.17,-0.21
    ...

Notes:
    - Works best when robots are the only moving objects
    - May detect shadows as false positives (shadow detection enabled)
    - Less accurate than color-based detection if background changes
    - Good alternative when robot color is similar to background
"""

import cv2
import numpy as np
import pandas as pd

VIDEO_PATH = '/home/basestation/Downloads/Video Project 25.mp4'
OUTPUT_CSV = 'robot_trajectory_motion.csv'

# Perspective transform (same as before)
pts_video = np.float32([
    [599, 292], [1543, 306], [598, 837], [1532, 855]
])
pts_world = np.float32([
    [-1.5, 1.5], [1.5, 1.5], [-1.5, -1.5], [1.5, -1.5]
])
matrix = cv2.getPerspectiveTransform(pts_video, pts_world)

video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)

# Background subtractor
bg_subtractor = cv2.createBackgroundSubtractorMOG2(
    history=500, 
    varThreshold=50, 
    detectShadows=True
)

trajectory_data = []
frame_count = 0

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    # Apply background subtraction
    fg_mask = bg_subtractor.apply(frame)
    
    # Remove shadows (gray pixels)
    _, fg_mask = cv2.threshold(fg_mask, 250, 255, cv2.THRESH_BINARY)
    
    # Clean up
    kernel = np.ones((5, 5), np.uint8)
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
    fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
    
    # Find contours
    contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        largest = max(contours, key=cv2.contourArea)
        if cv2.contourArea(largest) > 500:
            M = cv2.moments(largest)
            if M["m00"] > 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                
                # Convert to world
                point = np.array([[[cx, cy]]], dtype=np.float32)
                world = cv2.perspectiveTransform(point, matrix)
                
                trajectory_data.append({
                    'frame': frame_count,
                    'time': frame_count / fps,
                    'world_x': world[0][0][0],
                    'world_y': world[0][0][1]
                })
    
    frame_count += 1
    if frame_count % 100 == 0:
        print(f"Frame {frame_count}")

video.release()

df = pd.DataFrame(trajectory_data)
df.to_csv(OUTPUT_CSV, index=False)
print(f"Saved {len(df)} positions to {OUTPUT_CSV}")