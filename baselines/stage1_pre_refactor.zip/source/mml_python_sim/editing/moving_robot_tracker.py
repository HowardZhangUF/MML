"""
Moving Robot Tracker with Background Subtraction
=================================================

Description:
    Tracks moving robots by combining HSV color detection with MOG2 background
    subtraction. The background subtractor learns the static scene (floor, tape,
    stationary AprilTags) and only detects moving objects. Combined with HSV
    filtering, this gives highly accurate robot tracking.

Usage:
    python moving_robot_tracker.py

Input:
    - VIDEO_PATH: Path to input video file
    - HSV color range for black objects (robots)
    - Background subtraction learns static objects automatically

Output:
    - robot_trajectory.csv: Trajectory data (only moving robot)
    - moving_robot_video.mp4: Video with tracked robot highlighted
    - Debug visualization showing color, motion, and combined masks

Algorithm:
    1. Background subtractor learns static scene (first ~60 frames)
    2. Create motion mask: shows only moving pixels
    3. Create color mask: shows only black pixels (HSV filter)
    4. Combine masks: black AND moving = robot!
    5. Track largest moving black object as robot

Example Console Output:
    Video: 1920x1080 @ 30.0 fps
    Learning background... (frames 0-60)
    Tracking robot...
    Frame 100: Robot detected at (0.45, -0.23)m
    ==================================================
    Robot tracking complete!
    Total frames: 955
    Positions tracked: 952
    Detection rate: 99.7%
    ==================================================
"""

import cv2
import numpy as np
import pandas as pd

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 29.mp4'
OUTPUT_CSV = 'robot_trajectory.csv'
OUTPUT_VIDEO = 'moving_robot_video.mp4'

# HSV color range for BLACK objects (robots)
LOWER_COLOR = np.array([7, 0, 0])
UPPER_COLOR = np.array([68, 139, 175])

# Detection parameters
MIN_CONTOUR_AREA = 500  # Minimum size to be considered a robot
LEARNING_FRAMES = 60    # Frames for background subtractor to learn

# Background subtraction parameters
BG_HISTORY = 500        # How many frames to remember
BG_VAR_THRESHOLD = 50   # Sensitivity (lower = more sensitive)
DETECT_SHADOWS = True   # Detect and remove shadows

# Perspective transform points
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

pts_world = np.float32([
    [-1.5, 1.5],   # Node 0 (x, y in meters)
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# ============================================
# SETUP
# ============================================
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video: {width}x{height} @ {fps} fps")

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(OUTPUT_VIDEO, fourcc, fps, (width, height))

# Calculate perspective transform
matrix = cv2.getPerspectiveTransform(pts_video, pts_world)

# Create background subtractor (THIS IS THE KEY!)
bg_subtractor = cv2.createBackgroundSubtractorMOG2(
    history=BG_HISTORY,
    varThreshold=BG_VAR_THRESHOLD,
    detectShadows=DETECT_SHADOWS
)

# Storage for trajectory
trajectory_data = []

# ============================================
# HELPER FUNCTIONS
# ============================================
def pixel_to_world(pixel_x, pixel_y):
    """Convert pixel coordinates to world coordinates (meters)"""
    point = np.array([[[pixel_x, pixel_y]]], dtype=np.float32)
    world_point = cv2.perspectiveTransform(point, matrix)
    return world_point[0][0][0], world_point[0][0][1]

def find_moving_robot(frame, lower_color, upper_color, bg_subtractor):
    """
    Find moving robot using combined color + motion detection
    Returns: (x, y, color_mask, motion_mask, combined_mask) or (None, None, masks)
    """
    # 1. Create HSV color mask (finds BLACK objects)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    color_mask = cv2.inRange(hsv, lower_color, upper_color)
    
    # 2. Create motion mask (finds MOVING objects)
    # This learns the background and ignores stationary objects!
    motion_mask = bg_subtractor.apply(frame)
    
    # If shadows are detected, remove them (they appear as gray: value 127)
    if DETECT_SHADOWS:
        _, motion_mask = cv2.threshold(motion_mask, 250, 255, cv2.THRESH_BINARY)
    
    # 3. Combine masks: Must be BLACK AND MOVING
    # This automatically filters out the stationary AprilTag!
    combined_mask = cv2.bitwise_and(color_mask, motion_mask)
    
    # Clean up the combined mask
    kernel = np.ones((5, 5), np.uint8)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
    combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
    
    # Find contours in the combined mask
    contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if not contours:
        return None, None, color_mask, motion_mask, combined_mask
    
    # Find the largest contour (assumed to be the robot)
    largest_contour = max(contours, key=cv2.contourArea)
    
    if cv2.contourArea(largest_contour) < MIN_CONTOUR_AREA:
        return None, None, color_mask, motion_mask, combined_mask
    
    # Calculate centroid
    M = cv2.moments(largest_contour)
    if M["m00"] > 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
        return cx, cy, color_mask, motion_mask, combined_mask
    
    return None, None, color_mask, motion_mask, combined_mask

# ============================================
# MAIN PROCESSING LOOP
# ============================================
frame_count = 0
debug_mode = True

print("Learning background... (first few seconds)")
print("The AprilTag will be removed from detection automatically!")
print("Press 'q' to quit, 'space' to pause")

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    timestamp = frame_count / fps
    
    # Find moving robot
    pixel_x, pixel_y, color_mask, motion_mask, combined_mask = find_moving_robot(
        frame, LOWER_COLOR, UPPER_COLOR, bg_subtractor
    )
    
    # Store trajectory data
    if pixel_x is not None:
        world_x, world_y = pixel_to_world(pixel_x, pixel_y)
        
        trajectory_data.append({
            'frame': frame_count,
            'time': timestamp,
            'pixel_x': pixel_x,
            'pixel_y': pixel_y,
            'world_x': world_x,
            'world_y': world_y
        })
        
        # Draw robot on frame
        cv2.circle(frame, (pixel_x, pixel_y), 15, (0, 255, 0), -1)
        cv2.circle(frame, (pixel_x, pixel_y), 20, (255, 255, 255), 2)
        
        # Add position text
        cv2.putText(frame, f"ROBOT", 
                   (pixel_x - 40, pixel_y - 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, f"({world_x:.2f}, {world_y:.2f})m", 
                   (pixel_x - 60, pixel_y + 40), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    
    # Add status text
    if frame_count < LEARNING_FRAMES:
        status = f"Learning background... {frame_count}/{LEARNING_FRAMES}"
        color = (0, 165, 255)  # Orange
    else:
        status = f"Tracking: {len(trajectory_data)} positions"
        color = (0, 255, 0)  # Green
    
    cv2.putText(frame, status, (10, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    cv2.putText(frame, f"Frame: {frame_count}/{total_frames}", (10, 60), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    
    # Write to output video
    out.write(frame)
    
    # Show debug windows
    if debug_mode and frame_count % 2 == 0:
        # Main video
        display = cv2.resize(frame, (1280, 720))
        cv2.imshow('Robot Tracker', display)
        
        # Create debug view with all 3 masks
        debug_height = 240
        debug_width = 320
        
        color_display = cv2.resize(color_mask, (debug_width, debug_height))
        motion_display = cv2.resize(motion_mask, (debug_width, debug_height))
        combined_display = cv2.resize(combined_mask, (debug_width, debug_height))
        
        # Add labels
        cv2.putText(color_display, "Color (Black)", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2)
        cv2.putText(motion_display, "Motion", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2)
        cv2.putText(combined_display, "Combined (Robot)", (10, 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2)
        
        # Stack them horizontally
        debug_view = np.hstack([color_display, motion_display, combined_display])
        cv2.imshow('Debug: Masks (Color | Motion | Combined)', debug_view)
        
        # Handle keyboard input
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            print("\nStopping early...")
            break
        elif key == ord(' '):
            print("Paused - press any key to continue")
            cv2.waitKey(0)
    
    frame_count += 1
    
    # Progress updates
    if frame_count % 100 == 0:
        if frame_count < LEARNING_FRAMES:
            print(f"Frame {frame_count}: Learning background...")
        else:
            detection_rate = 100 * len(trajectory_data) / max(1, frame_count - LEARNING_FRAMES)
            print(f"Frame {frame_count}: Tracked {len(trajectory_data)} positions "
                  f"({detection_rate:.1f}% detection rate)")

video.release()
out.release()
cv2.destroyAllWindows()

# ============================================
# SAVE RESULTS
# ============================================
if trajectory_data:
    df = pd.DataFrame(trajectory_data)
    
    # Add velocity calculations
    if len(df) > 1:
        df['vx'] = df['world_x'].diff() / df['time'].diff()
        df['vy'] = df['world_y'].diff() / df['time'].diff()
        df['speed'] = np.sqrt(df['vx']**2 + df['vy']**2)
        
        # Smooth velocity (rolling average over 5 frames)
        df['vx_smooth'] = df['vx'].rolling(window=5, center=True).mean()
        df['vy_smooth'] = df['vy'].rolling(window=5, center=True).mean()
        df['speed_smooth'] = np.sqrt(df['vx_smooth']**2 + df['vy_smooth']**2)
    
    df.to_csv(OUTPUT_CSV, index=False)
    
    print(f"\n{'='*50}")
    print(f"✓ Robot tracking complete!")
    print(f"{'='*50}")
    print(f"Total frames processed: {frame_count}")
    print(f"Background learning frames: {LEARNING_FRAMES}")
    print(f"Tracking frames: {frame_count - LEARNING_FRAMES}")
    print(f"Positions tracked: {len(trajectory_data)}")
    
    if frame_count > LEARNING_FRAMES:
        detection_rate = 100 * len(trajectory_data) / (frame_count - LEARNING_FRAMES)
        print(f"Detection rate: {detection_rate:.1f}%")
    
    if len(df) > 1 and 'speed' in df.columns:
        print(f"\nTrajectory Statistics:")
        print(f"  Duration: {df['time'].iloc[-1]:.2f} seconds")
        print(f"  Distance traveled: {df['speed'].sum() * (df['time'].iloc[1] - df['time'].iloc[0]):.2f} meters")
        print(f"  Average speed: {df['speed'].mean():.3f} m/s")
        print(f"  Max speed: {df['speed'].max():.3f} m/s")
    
    print(f"\nOutput files:")
    print(f"  Video: {OUTPUT_VIDEO}")
    print(f"  CSV: {OUTPUT_CSV}")
    print(f"{'='*50}")
    
else:
    print("\n⚠ ERROR: No moving robot detected in video!")
    print("\nTroubleshooting:")
    print("1. Check if robot is actually moving in the video")
    print("2. Verify HSV color range captures the robot")
    print("3. Try lowering MIN_CONTOUR_AREA or BG_VAR_THRESHOLD")
    print("4. Check the debug masks window to see what's being detected")