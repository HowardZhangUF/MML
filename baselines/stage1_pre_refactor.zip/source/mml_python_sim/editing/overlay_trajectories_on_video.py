"""
Overlay World Coordinate Trajectories on Video
==============================================

Reads the trajectory CSV and draws the paths directly on the video.
Uses the perspective transform to convert world coordinates back to pixel coordinates.

Usage:
    python overlay_trajectories_on_video.py
"""

import cv2
import numpy as np
import pandas as pd
from collections import defaultdict

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 52.mp4'
TRAJECTORY_CSV = 'robot_trajectories_csrt.csv'
OUTPUT_VIDEO = 'video_with_trajectory_overlay.mp4'

# Same perspective transform as tracker
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

pts_world = np.float32([
    [-1.5, 1.5],   # Node 0
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# Robot colors
COLORS = {
    'drone': (255, 0, 255),      # Magenta
    'turtle1': (0, 255, 0),      # Green
    'turtle2': (0, 255, 255),    # Cyan
}

# Trajectory display settings
TRAJECTORY_THICKNESS = 2
TRAJECTORY_ALPHA = 0.7  # Transparency (0=invisible, 1=opaque)
SHOW_CURRENT_POSITION = True
CURRENT_POSITION_RADIUS = 10
TRAIL_LENGTH = 50  # Number of past positions to show (0 = full trail)

# ============================================
# SETUP
# ============================================
print("Loading trajectory data...")
df = pd.read_csv(TRAJECTORY_CSV)

# Get inverse perspective transform (world -> pixel)
matrix_world_to_pixel = cv2.getPerspectiveTransform(pts_world, pts_video)

def world_to_pixel(world_x, world_y):
    """Convert world coordinates back to pixel coordinates"""
    point = np.array([[[world_x, world_y]]], dtype=np.float32)
    pixel_point = cv2.perspectiveTransform(point, matrix_world_to_pixel)
    return int(pixel_point[0][0][0]), int(pixel_point[0][0][1])

# Open video
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video: {width}x{height} @ {fps} fps, {total_frames} frames")

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(OUTPUT_VIDEO, fourcc, fps, (width, height))

# Organize trajectories by robot and frame
trajectories = defaultdict(lambda: defaultdict(dict))

for _, row in df.iterrows():
    frame = int(row['frame'])
    robot = row['robot']
    world_x = row['world_x']
    world_y = row['world_y']
    
    # Convert to pixel coordinates
    pixel_x, pixel_y = world_to_pixel(world_x, world_y)
    
    trajectories[robot][frame] = {
        'pixel': (pixel_x, pixel_y),
        'world': (world_x, world_y)
    }

print(f"Loaded trajectories for {len(trajectories)} robots")

# Build full path for each robot (for drawing complete trails)
robot_paths = {}
for robot in trajectories.keys():
    frames = sorted(trajectories[robot].keys())
    path = [trajectories[robot][f]['pixel'] for f in frames]
    robot_paths[robot] = path

# ============================================
# OVERLAY TRAJECTORIES ON VIDEO
# ============================================
print("\nOverlaying trajectories on video...")
print("This may take a few minutes...\n")

frame_count = 0
start_frame = min(df['frame'].min(), 0)

# Reset video to start
video.set(cv2.CAP_PROP_POS_FRAMES, 0)

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    # Create overlay layer
    overlay = frame.copy()
    
    # Draw trajectories for each robot
    for robot, color in COLORS.items():
        if robot not in trajectories:
            continue
        
        # Get all points up to current frame
        frames_with_data = sorted([f for f in trajectories[robot].keys() if f <= frame_count])
        
        if len(frames_with_data) > 0:
            # Draw trail
            if TRAIL_LENGTH > 0:
                # Limited trail (recent N positions)
                trail_frames = frames_with_data[-TRAIL_LENGTH:]
            else:
                # Full trail (all past positions)
                trail_frames = frames_with_data
            
            points = [trajectories[robot][f]['pixel'] for f in trail_frames]
            
            # Draw trajectory line
            if len(points) > 1:
                points_array = np.array(points, dtype=np.int32)
                cv2.polylines(overlay, [points_array], False, color, 
                            TRAJECTORY_THICKNESS, lineType=cv2.LINE_AA)
            
            # Draw current position
            if SHOW_CURRENT_POSITION and frame_count in trajectories[robot]:
                current_pos = trajectories[robot][frame_count]['pixel']
                
                # Outer circle (white border)
                cv2.circle(overlay, current_pos, CURRENT_POSITION_RADIUS + 2, 
                          (255, 255, 255), -1)
                # Inner circle (robot color)
                cv2.circle(overlay, current_pos, CURRENT_POSITION_RADIUS, 
                          color, -1)
                
                # Robot label
                label = robot.upper()
                cv2.putText(overlay, label, 
                          (current_pos[0] + 15, current_pos[1] - 10),
                          cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    
    # Blend overlay with original frame
    frame_with_overlay = cv2.addWeighted(frame, 1 - TRAJECTORY_ALPHA, 
                                         overlay, TRAJECTORY_ALPHA, 0)
    
    # Add frame counter
    cv2.putText(frame_with_overlay, f"Frame: {frame_count}", (10, 30),
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    # Write frame
    out.write(frame_with_overlay)
    
    # Progress update
    if frame_count % 100 == 0:
        progress = 100 * frame_count / total_frames
        print(f"Progress: {frame_count}/{total_frames} ({progress:.1f}%)")
    
    frame_count += 1

video.release()
out.release()

print("\n" + "="*60)
print("✓ VIDEO OVERLAY COMPLETE!")
print("="*60)
print(f"Output: {OUTPUT_VIDEO}")
print(f"Frames processed: {frame_count}")
print("="*60)