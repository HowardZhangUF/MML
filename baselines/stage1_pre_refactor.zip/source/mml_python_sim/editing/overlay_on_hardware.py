"""
Overlay Robot Trajectories on Hardware Image
=============================================

Overlays the extracted robot trajectories onto the hardware.png image
with legend and axis labels matching the coordinate system.

Features:
- Uses hardware.png as background
- Overlays trajectories with proper coordinate mapping
- Adds legend with robot names (Drone, Target 1, Target 2)
- Displays X/Y axis in meters
- Publication-quality output

Usage:
    python overlay_on_hardware.py
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
import cv2

# ============================================
# CONFIGURATION
# ============================================
INPUT_CSV = '/home/basestation/mml_python_sim/editing/robot_trajectories_csrt.csv'
HARDWARE_IMAGE = '/home/basestation/mml_python_sim/editing/hardware.png'
OUTPUT_IMAGE = '/home/basestation/mml_python_sim/editing/hardware_with_trajectories.png'

# Perspective calibration (same as tracker)
# Video corner points (pixels) -> World coordinates (meters)
VIDEO_POINTS = np.array([
    [599, 292],   # Top-left -> (-1.5, 1.5)
    [1543, 306],  # Top-right -> (1.5, 1.5)
    [598, 837],   # Bottom-left -> (-1.5, -1.5)
    [1532, 855]   # Bottom-right -> (1.5, -1.5)
], dtype=np.float32)

WORLD_POINTS = np.array([
    [-3, 3], [3, 3], [-3, -3], [3, -3]
], dtype=np.float32)

# Colors for each robot
COLORS = {
    'drone': 'magenta',
    'turtle1': 'green',
    'turtle2': 'cyan'
}

# Robot name mapping
ROBOT_NAME_MAP = {
    'drone': 'Drone',
    'turtle1': 'Target 1',
    'turtle2': 'Target 2'
}

# ============================================
# LOAD DATA
# ============================================
print("Loading trajectory data...")
df = pd.read_csv(INPUT_CSV)

print("Loading hardware image...")
hardware_img = cv2.imread(HARDWARE_IMAGE)
if hardware_img is None:
    print(f"ERROR: Cannot load {HARDWARE_IMAGE}")
    exit(1)

# Convert BGR to RGB for matplotlib
hardware_img = cv2.cvtColor(hardware_img, cv2.COLOR_BGR2RGB)
img_height, img_width = hardware_img.shape[:2]

print(f"Hardware image size: {img_width}x{img_height}")
print(f"Loaded trajectory data: {len(df)} points")

# ============================================
# COORDINATE TRANSFORMATION
# ============================================
# Get perspective transform matrix (world -> video pixels)
M_world_to_pixel = cv2.getPerspectiveTransform(WORLD_POINTS, VIDEO_POINTS)

def world_to_pixel(world_coords):
    """
    Convert world coordinates (meters) to pixel coordinates
    
    Args:
        world_coords: Nx2 array of (x, y) in meters
    
    Returns:
        Nx2 array of (px, py) in pixels
    """
    if len(world_coords.shape) == 1:
        world_coords = world_coords.reshape(1, -1)
    
    # Add homogeneous coordinate
    ones = np.ones((world_coords.shape[0], 1))
    world_h = np.hstack([world_coords, ones])
    
    # Apply transformation
    pixel_h = (M_world_to_pixel @ world_h.T).T
    
    # Normalize by homogeneous coordinate
    pixels = pixel_h[:, :2] / pixel_h[:, 2:3]
    
    return pixels

# ============================================
# CREATE OVERLAY PLOT
# ============================================
print("Creating overlay plot...")

fig, ax = plt.subplots(figsize=(16, 12))

# Display hardware image as background
ax.imshow(hardware_img, extent=[0, img_width, img_height, 0], aspect='auto', alpha=0.8)

# Get robot names
robots = df['robot'].unique()

# First pass: Draw trajectories and markers (without labels)
for robot in robots:
    robot_df = df[df['robot'] == robot]
    color = COLORS.get(robot, 'blue')
    
    # Convert world coordinates to pixels
    world_coords = robot_df[['world_x', 'world_y']].values
    pixel_coords = world_to_pixel(world_coords)
    
    # Plot trajectory
    ax.plot(pixel_coords[:, 0], pixel_coords[:, 1], 
            color=color, linewidth=4, alpha=0.9, zorder=10)
    
    # Start point
    start_pixel = world_to_pixel(world_coords[0:1])
    ax.scatter(start_pixel[0, 0], start_pixel[0, 1],
               c=color, s=300, marker='o', edgecolors='white', 
               linewidths=3, zorder=15)
    
    # End point
    end_pixel = world_to_pixel(world_coords[-1:])
    ax.scatter(end_pixel[0, 0], end_pixel[0, 1],
               c=color, s=300, marker='X', edgecolors='white', 
               linewidths=3, zorder=15)

# Second pass: Create legend entries (invisible plots)
legend_elements = []
for robot in robots:
    color = COLORS.get(robot, 'blue')
    label = ROBOT_NAME_MAP.get(robot, robot.upper())
    
    # Create invisible line for legend
    line, = ax.plot([], [], color=color, linewidth=4, alpha=0.9, label=label)
    legend_elements.append(line)

# Add START and END markers to legend
start_marker = ax.scatter([], [], c='gray', s=300, marker='o', 
                         edgecolors='white', linewidths=3, label='Start')
end_marker = ax.scatter([], [], c='gray', s=300, marker='X', 
                       edgecolors='white', linewidths=3, label='End')
legend_elements.extend([start_marker, end_marker])

# ============================================
# STYLING AND LABELS
# ============================================

# Add coordinate axes overlay
# Create a secondary axis showing world coordinates
ax2 = ax.twinx()
ax3 = ax.twiny()

# Map world coordinate range to pixel range
world_x_min, world_x_max = -1.5, 1.5
world_y_min, world_y_max = -1.5, 1.5

# Get pixel boundaries from corner points
pixel_x_min = VIDEO_POINTS[:, 0].min()
pixel_x_max = VIDEO_POINTS[:, 0].max()
pixel_y_min = VIDEO_POINTS[:, 1].min()
pixel_y_max = VIDEO_POINTS[:, 1].max()

# Set secondary axes limits
ax3.set_xlim(world_x_min, world_x_max)
ax2.set_ylim(world_y_max, world_y_min)  # Inverted because pixels go top-to-bottom

# Labels
ax.set_xlabel('Pixel X', fontsize=14, fontweight='bold')
ax.set_ylabel('Pixel Y', fontsize=14, fontweight='bold')
ax3.set_xlabel('X Position (meters)', fontsize=16, fontweight='bold')
ax2.set_ylabel('Y Position (meters)', fontsize=16, fontweight='bold')

# Adjust primary axes to match video region
ax.set_xlim(0, img_width)
ax.set_ylim(img_height, 0)

# Legend styling
legend = ax.legend(handles=legend_elements, fontsize=14, loc='upper right', 
                  frameon=True, fancybox=True, shadow=True, framealpha=0.95,
                  edgecolor='black', facecolor='white')

# Grid (optional - comment out if you don't want grid)
# ax.grid(True, alpha=0.2, linestyle='--', linewidth=1, color='white', zorder=5)

# Title (optional)
# ax.set_title('Robot Trajectories on Hardware', fontsize=18, fontweight='bold', pad=20)

plt.tight_layout()

# Save output
fig.savefig(OUTPUT_IMAGE, dpi=300, bbox_inches='tight', 
            facecolor='white', edgecolor='black')
print(f"\n✓ Output saved: {OUTPUT_IMAGE}")

plt.show()

print("\n" + "="*60)
print("OVERLAY COMPLETE")
print("="*60)
print(f"Input image: {HARDWARE_IMAGE}")
print(f"Output image: {OUTPUT_IMAGE}")
print(f"Robots plotted: {', '.join([ROBOT_NAME_MAP.get(r, r) for r in robots])}")
print("="*60)
