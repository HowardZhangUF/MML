"""
Simple Trajectory Plotter from CSV Data
========================================

Description:
    Creates visualization plots from previously extracted trajectory CSV data.
    Useful for quick analysis without reprocessing video.

Usage:
    python plot_trajectory.py

Input:
    - robot_trajectory.csv: CSV file with trajectory data

Output:
    - trajectory_analysis.png: Multi-panel plot showing:
        * XY trajectory
        * X position vs time
        * Y position vs time
        * Speed vs time

Example Console Output:
    Loading trajectory data...
    Loaded 951 positions
    Creating plots...
    Saved: trajectory_analysis.png
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Configuration
INPUT_CSV = 'robot_trajectory.csv'
OUTPUT_PLOT = 'trajectory_analysis.png'

print("Loading trajectory data...")
df = pd.read_csv(INPUT_CSV)
print(f"Loaded {len(df)} positions")

# Create figure with subplots
fig = plt.figure(figsize=(15, 10))

# 1. XY Trajectory (top left)
ax1 = plt.subplot(2, 2, 1)
ax1.plot(df['world_x'], df['world_y'], 'b-', linewidth=1.5, alpha=0.7)
ax1.scatter(df['world_x'].iloc[0], df['world_y'].iloc[0], 
            c='green', s=150, marker='o', label='Start', zorder=5)
ax1.scatter(df['world_x'].iloc[-1], df['world_y'].iloc[-1], 
            c='red', s=150, marker='X', label='End', zorder=5)

# Add corner markers
corners = [(-1.5, 1.5), (1.5, 1.5), (-1.5, -1.5), (1.5, -1.5)]
corner_labels = ['Node 0', 'Node 2', 'Node 3', 'Node 7']
for (x, y), label in zip(corners, corner_labels):
    ax1.scatter(x, y, c='orange', s=120, marker='s', edgecolors='black', alpha=0.6)
    ax1.text(x, y+0.1, label, ha='center', fontsize=8)

ax1.axhline(y=0, color='k', linestyle='--', alpha=0.3)
ax1.axvline(x=0, color='k', linestyle='--', alpha=0.3)
ax1.set_xlabel('X Position (m)', fontsize=11)
ax1.set_ylabel('Y Position (m)', fontsize=11)
ax1.set_title('Robot Trajectory', fontsize=12, fontweight='bold')
ax1.legend()
ax1.grid(True, alpha=0.3)
ax1.axis('equal')

# 2. X position vs time (top right)
ax2 = plt.subplot(2, 2, 2)
ax2.plot(df['time'], df['world_x'], 'g-', linewidth=1.5)
ax2.set_xlabel('Time (s)', fontsize=11)
ax2.set_ylabel('X Position (m)', fontsize=11)
ax2.set_title('X Position over Time', fontsize=12, fontweight='bold')
ax2.grid(True, alpha=0.3)

# 3. Y position vs time (bottom left)
ax3 = plt.subplot(2, 2, 3)
ax3.plot(df['time'], df['world_y'], 'b-', linewidth=1.5)
ax3.set_xlabel('Time (s)', fontsize=11)
ax3.set_ylabel('Y Position (m)', fontsize=11)
ax3.set_title('Y Position over Time', fontsize=12, fontweight='bold')
ax3.grid(True, alpha=0.3)

# 4. Speed vs time (bottom right)
ax4 = plt.subplot(2, 2, 4)
if 'speed' in df.columns:
    ax4.plot(df['time'], df['speed'], 'r-', linewidth=1, alpha=0.5, label='Instantaneous')
    if 'vx_smooth' in df.columns:
        speed_smooth = np.sqrt(df['vx_smooth']**2 + df['vy_smooth']**2)
        ax4.plot(df['time'], speed_smooth, 'darkred', linewidth=2, label='Smoothed')
    ax4.set_xlabel('Time (s)', fontsize=11)
    ax4.set_ylabel('Speed (m/s)', fontsize=11)
    ax4.set_title('Speed over Time', fontsize=12, fontweight='bold')
    ax4.legend()
    ax4.grid(True, alpha=0.3)
else:
    ax4.text(0.5, 0.5, 'Speed data not available', 
             ha='center', va='center', transform=ax4.transAxes)

plt.tight_layout()
plt.savefig(OUTPUT_PLOT, dpi=150, bbox_inches='tight')
print(f"Saved: {OUTPUT_PLOT}")

# Print statistics
print(f"\n{'='*50}")
print(f"Trajectory Statistics:")
print(f"  Duration: {df['time'].iloc[-1]:.2f} seconds")
print(f"  X range: [{df['world_x'].min():.2f}, {df['world_x'].max():.2f}] m")
print(f"  Y range: [{df['world_y'].min():.2f}, {df['world_y'].max():.2f}] m")
if 'speed' in df.columns:
    print(f"  Avg speed: {df['speed'].mean():.3f} m/s")
    print(f"  Max speed: {df['speed'].max():.3f} m/s")
print(f"{'='*50}")