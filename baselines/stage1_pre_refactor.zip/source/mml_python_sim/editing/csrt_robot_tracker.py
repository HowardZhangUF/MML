"""
Multi-Robot CSRT Tracker with Manual Initialization
====================================================

Description:
    Tracks 3 robots (drone + 2 turtlebots) using OpenCV's CSRT tracker algorithm.
    User manually selects a starting frame and draws bounding boxes around each 
    robot, then the tracker follows each robot's unique visual pattern throughout 
    the video.
    
    CSRT (Channel and Spatial Reliability Tracker) is excellent for:
    - Maintaining robot identity (no ID switching)
    - Handling partial occlusions
    - Tracking complex objects with gaps (like drone motors)
    - Smooth, jitter-free center points

Usage:
    1. Run: python csrt_robot_tracker.py
    2. STEP 1: Frame Selection
       - Press 'n' to advance frame-by-frame
       - Press 'b' to go back
       - Press 's' when all robots are fully visible
    3. STEP 2: Bounding Box Selection
       - Draw box around DRONE (press ENTER when done)
       - Draw box around TURTLE 1 (press ENTER)
       - Draw box around TURTLE 2 (press ENTER)
    4. Press SPACE to start automatic tracking

Controls (Frame Selection):
    - 'n' or →: Next frame
    - 'b' or ←: Previous frame
    - 's' or SPACE: Select this frame
    - 'q' or ESC: Quit

Controls (Initialization):
    - Mouse: Draw bounding box around robot
    - ENTER: Confirm current box, move to next robot
    - 'c': Clear current box and redraw
    - ESC: Skip current robot (will not be tracked)

Controls (Tracking):
    - 'q': Quit
    - 'space': Pause/resume
    - 'r': Reset trackers (reinitialize boxes)

Output:
    - robot_trajectories_csrt.csv: All 3 robot trajectories
    - csrt_tracking_video.mp4: Video with tracked robots

Example Console Output:
    Video: 1920x1080 @ 30.0 fps
    
    === STEP 1: FIND STARTING FRAME ===
    Selected frame 45
    
    === STEP 2: DRAW BOUNDING BOXES ===
    Box selected: (850, 450, 180, 120)
    
    Press SPACE to start tracking...
    
    === TRACKING ===
    Starting from frame: 45
    Frame 100: Drone ✓ | Turtle1 ✓ | Turtle2 ✓
    Frame 200: Drone ✓ | Turtle1 ✓ | Turtle2 ✓
    ...
    ==================================================
    Tracking complete!
    Started from frame: 45
    Drone: 903/910 (99.2%)
    Turtle1: 908/910 (99.8%)
    Turtle2: 900/910 (98.9%)
    ==================================================
"""

import cv2
import numpy as np
import pandas as pd
from collections import defaultdict

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 52.mp4'
OUTPUT_CSV = 'robot_trajectories_csrt.csv'
OUTPUT_VIDEO = 'csrt_tracking_video.mp4'

# Robot names and colors
ROBOT_NAMES = ['drone', 'turtle1', 'turtle2']
ROBOT_COLORS = {
    'drone': (255, 0, 255),      # Magenta
    'turtle1': (0, 255, 0),      # Green
    'turtle2': (0, 255, 255),    # Cyan
}

# Tracking settings
TRACKER_TYPE = 'CSRT'  # Options: CSRT, KCF, MOSSE
                       # CSRT = Most accurate, slower
                       # KCF = Good balance
                       # MOSSE = Fastest, less accurate

# Perspective transform points
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

pts_world = np.float32([
    [-1.5, 1.5],   # Node 0 (x, y in meters)
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# ============================================
# TRACKER FACTORY
# ============================================
def create_tracker(tracker_type='CSRT'):
    """Create OpenCV tracker object"""
    if tracker_type == 'CSRT':
        return cv2.TrackerCSRT_create()
    elif tracker_type == 'KCF':
        return cv2.TrackerKCF_create()
    elif tracker_type == 'MOSSE':
        return cv2.legacy.TrackerMOSSE_create()
    else:
        raise ValueError(f"Unknown tracker type: {tracker_type}")

# ============================================
# BOUNDING BOX SELECTOR
# ============================================
class BoundingBoxSelector:
    def __init__(self, window_name):
        self.window_name = window_name
        self.bbox = None
        self.drawing = False
        self.start_point = None
        self.current_point = None
        self.frame_copy = None
        
    def mouse_callback(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            self.drawing = True
            self.start_point = (x, y)
            self.current_point = (x, y)
            
        elif event == cv2.EVENT_MOUSEMOVE:
            if self.drawing:
                self.current_point = (x, y)
                
        elif event == cv2.EVENT_LBUTTONUP:
            self.drawing = False
            self.current_point = (x, y)
            
            # Calculate bounding box (x, y, w, h)
            x1 = min(self.start_point[0], self.current_point[0])
            y1 = min(self.start_point[1], self.current_point[1])
            x2 = max(self.start_point[0], self.current_point[0])
            y2 = max(self.start_point[1], self.current_point[1])
            
            self.bbox = (x1, y1, x2 - x1, y2 - y1)
    
    def select_bbox(self, frame, robot_name):
        """Let user draw bounding box on frame"""
        self.bbox = None
        self.frame_copy = frame.copy()
        
        cv2.setMouseCallback(self.window_name, self.mouse_callback)
        
        print(f"\n>>> Draw box around: {robot_name.upper()}")
        print("    - Click and drag to draw rectangle")
        print("    - Press ENTER when satisfied")
        print("    - Press 'c' to clear and redraw")
        print("    - Press ESC to skip this robot")
        
        while True:
            display = self.frame_copy.copy()
            
            # Draw current box being drawn
            if self.drawing and self.start_point and self.current_point:
                cv2.rectangle(display, self.start_point, self.current_point, (0, 255, 0), 2)
            
            # Draw finalized box
            if self.bbox is not None:
                x, y, w, h = self.bbox
                cv2.rectangle(display, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(display, robot_name.upper(), (x, y - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            
            # Instructions
            cv2.putText(display, f"Select: {robot_name.upper()}", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
            cv2.putText(display, "ENTER=Confirm | c=Clear | ESC=Skip", (10, 70),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            cv2.imshow(self.window_name, display)
            
            key = cv2.waitKey(1) & 0xFF
            
            if key == 13:  # ENTER
                if self.bbox is not None and self.bbox[2] > 0 and self.bbox[3] > 0:
                    print(f"    ✓ Box selected: {self.bbox}")
                    return self.bbox
                else:
                    print("    ⚠ Please draw a valid box first!")
                    
            elif key == ord('c'):  # Clear
                self.bbox = None
                self.frame_copy = frame.copy()
                print("    Cleared. Draw again.")
                
            elif key == 27:  # ESC
                print(f"    Skipped {robot_name}")
                return None

# ============================================
# SETUP
# ============================================
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video: {width}x{height} @ {fps} fps")
print(f"Total frames: {total_frames}")

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(OUTPUT_VIDEO, fourcc, fps, (width, height))

# Perspective transform matrix
matrix = cv2.getPerspectiveTransform(pts_video, pts_world)

# ============================================
# INITIALIZE TRACKERS
# ============================================
def initialize_trackers(video, robot_names):
    """Initialize CSRT trackers for each robot"""
    trackers = {}
    bboxes = {}
    
    # ====== STEP 1: FIND GOOD STARTING FRAME ======
    print("\n" + "="*50)
    print("STEP 1: FIND A GOOD STARTING FRAME".center(50))
    print("="*50)
    print("Controls:")
    print("  'n' or '→': Skip to next frame")
    print("  'b' or '←': Go back to previous frame")
    print("  's' or SPACE: Select this frame for tracking")
    print("  'q' or ESC: Quit")
    print("="*50)
    
    # Start from beginning
    video.set(cv2.CAP_PROP_POS_FRAMES, 0)
    frame_num = 0
    selected_frame = None
    selected_frame_num = 0
    
    # Frame selection window
    window_name = "Find Starting Frame"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 1280, 720)
    
    while True:
        ret, frame = video.read()
        if not ret:
            print("\n⚠ Reached end of video. Rewinding...")
            video.set(cv2.CAP_PROP_POS_FRAMES, 0)
            frame_num = 0
            continue
        
        # Create display with instructions
        display = frame.copy()
        cv2.putText(display, f"Frame {frame_num}/{total_frames}", (20, 40),
                   cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 255), 2)
        cv2.putText(display, "n=Next | b=Back | s=Select | q=Quit", (20, 80),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(display, "Make sure all robots are FULLY visible!", (20, 120),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        
        # Show frame
        display_resized = cv2.resize(display, (1280, 720))
        cv2.imshow(window_name, display_resized)
        
        key = cv2.waitKey(0) & 0xFF
        
        if key == ord('s') or key == ord(' '):  # Select this frame
            selected_frame = frame
            selected_frame_num = frame_num
            print(f"\n✓ Selected frame {frame_num}")
            break
            
        elif key == ord('n') or key == 83:  # Next frame (n or right arrow)
            frame_num += 1
            
        elif key == ord('b') or key == 81:  # Previous frame (b or left arrow)
            if frame_num > 0:
                frame_num -= 1
                video.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
            
        elif key == ord('q') or key == 27:  # Quit (q or ESC)
            cv2.destroyWindow(window_name)
            print("\n⏹ Cancelled by user")
            return None, None, 0
    
    cv2.destroyWindow(window_name)
    
    if selected_frame is None:
        print("ERROR: No frame selected")
        return None, None, 0
    
    # ====== STEP 2: DRAW BOUNDING BOXES ======
    frame = selected_frame
    
    # Resize for easier viewing
    display_scale = 0.8
    display_width = int(width * display_scale)
    display_height = int(height * display_scale)
    frame_display = cv2.resize(frame, (display_width, display_height))
    
    # Create window
    window_name = "Initialize Trackers"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, display_width, display_height)
    
    selector = BoundingBoxSelector(window_name)
    
    print("\n" + "="*50)
    print("STEP 2: DRAW BOUNDING BOXES".center(50))
    print("="*50)
    
    # Select bounding box for each robot
    for robot_name in robot_names:
        bbox = selector.select_bbox(frame_display, robot_name)
        
        if bbox is not None:
            # Scale bbox back to original frame size
            x, y, w, h = bbox
            bbox_scaled = (
                int(x / display_scale),
                int(y / display_scale),
                int(w / display_scale),
                int(h / display_scale)
            )
            
            # Create tracker
            tracker = create_tracker(TRACKER_TYPE)
            tracker.init(frame, bbox_scaled)
            
            trackers[robot_name] = tracker
            bboxes[robot_name] = bbox_scaled
            
            print(f"    ✓ {robot_name.upper()} tracker initialized")
    
    cv2.destroyWindow(window_name)
    
    if not trackers:
        print("\n⚠ No robots selected! Exiting.")
        return None, None, 0
    
    print(f"\n✓ {len(trackers)} trackers initialized")
    print("Press SPACE to start tracking...")
    
    # Wait for user to press space
    temp_window = "Ready to Track"
    cv2.namedWindow(temp_window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(temp_window, display_width, display_height)
    
    info_frame = frame_display.copy()
    cv2.putText(info_frame, "Trackers Initialized!", (50, 100),
               cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
    cv2.putText(info_frame, "Press SPACE to start", (50, 150),
               cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    
    cv2.imshow(temp_window, info_frame)
    while cv2.waitKey(1) & 0xFF != ord(' '):
        pass
    cv2.destroyWindow(temp_window)
    
    # Reset video to the selected starting frame
    video.set(cv2.CAP_PROP_POS_FRAMES, selected_frame_num)
    
    return trackers, bboxes, selected_frame_num

# ============================================
# HELPER FUNCTIONS
# ============================================
def pixel_to_world(pixel_x, pixel_y):
    """Convert pixel coordinates to world coordinates"""
    point = np.array([[[pixel_x, pixel_y]]], dtype=np.float32)
    world_point = cv2.perspectiveTransform(point, matrix)
    return world_point[0][0][0], world_point[0][0][1]

def get_bbox_center(bbox):
    """Get center point of bounding box"""
    x, y, w, h = bbox
    return (int(x + w/2), int(y + h/2))

# Initialize trackers
trackers, initial_bboxes, start_frame_num = initialize_trackers(video, ROBOT_NAMES)

if trackers is None:
    video.release()
    exit()

# Storage
trajectory_data = defaultdict(list)

# ============================================
# MAIN TRACKING LOOP
# ============================================
frame_count = start_frame_num  # Start from the selected frame
debug_mode = True
paused = False

print("\n" + "="*50)
print("TRACKING STARTED".center(50))
print("="*50)
print(f"Starting from frame: {start_frame_num}")
print(f"Tracking {len(trackers)} robots: {', '.join(trackers.keys())}")
print("Controls: 'q'=Quit | 'space'=Pause | 'r'=Reinitialize\n")

while True:
    if not paused:
        ret, frame = video.read()
        if not ret:
            break
        
        timestamp = frame_count / fps
        frame_annotated = frame.copy()
        
        # Update each tracker
        tracking_status = {}
        
        for robot_name, tracker in trackers.items():
            success, bbox = tracker.update(frame)
            
            if success:
                # Get center point
                center = get_bbox_center(bbox)
                world_x, world_y = pixel_to_world(center[0], center[1])
                
                # Store trajectory
                trajectory_data[robot_name].append({
                    'frame': frame_count,
                    'time': timestamp,
                    'robot': robot_name,
                    'pixel_x': center[0],
                    'pixel_y': center[1],
                    'world_x': world_x,
                    'world_y': world_y,
                    'bbox_x': int(bbox[0]),
                    'bbox_y': int(bbox[1]),
                    'bbox_w': int(bbox[2]),
                    'bbox_h': int(bbox[3])
                })
                
                # Draw bounding box and center
                color = ROBOT_COLORS[robot_name]
                x, y, w, h = [int(v) for v in bbox]
                
                cv2.rectangle(frame_annotated, (x, y), (x + w, y + h), color, 2)
                cv2.circle(frame_annotated, center, 8, color, -1)
                cv2.circle(frame_annotated, center, 12, (255, 255, 255), 2)
                
                # Label
                label = f"{robot_name.upper()}"
                cv2.putText(frame_annotated, label, (x, y - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                cv2.putText(frame_annotated, f"({world_x:.2f}, {world_y:.2f})m",
                           (x, y + h + 25),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                tracking_status[robot_name] = "✓"
            else:
                tracking_status[robot_name] = "✗"
        
        # Status text
        status_text = f"Frame: {frame_count}/{total_frames} | "
        status_text += " | ".join([f"{name}: {tracking_status.get(name, '?')}" 
                                   for name in ROBOT_NAMES])
        
        cv2.putText(frame_annotated, status_text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Write frame
        out.write(frame_annotated)
        
        frame_count += 1
        
        # Console updates
        if frame_count % 100 == 0:
            status_str = " | ".join([f"{name.capitalize()}: {tracking_status.get(name, '?')}" 
                                     for name in ROBOT_NAMES])
            print(f"Frame {frame_count}: {status_str}")
    
    # Display
    if debug_mode:
        display = cv2.resize(frame_annotated, (1280, 720))
        cv2.imshow('CSRT Multi-Robot Tracker', display)
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q'):
            print("\n⏹ Stopped by user")
            break
        elif key == ord(' '):
            paused = not paused
            print(f"\n{'⏸ Paused' if paused else '▶ Resumed'}")
        elif key == ord('r'):
            print("\n🔄 Reinitializing trackers...")
            video.set(cv2.CAP_PROP_POS_FRAMES, frame_count)
            trackers, initial_bboxes, new_start_frame = initialize_trackers(video, list(trackers.keys()))
            if trackers is None:
                break
            # Continue from where we left off
            video.set(cv2.CAP_PROP_POS_FRAMES, frame_count)

video.release()
out.release()
cv2.destroyAllWindows()

# ============================================
# SAVE RESULTS
# ============================================
all_trajectories = []
for robot_name, data_list in trajectory_data.items():
    all_trajectories.extend(data_list)

if all_trajectories:
    df = pd.DataFrame(all_trajectories)
    df = df.sort_values(['robot', 'frame'])
    
    # Calculate velocities per robot
    for robot_name in trajectory_data.keys():
        robot_df = df[df['robot'] == robot_name].copy()
        if len(robot_df) > 1:
            robot_df['vx'] = robot_df['world_x'].diff() / robot_df['time'].diff()
            robot_df['vy'] = robot_df['world_y'].diff() / robot_df['time'].diff()
            robot_df['speed'] = np.sqrt(robot_df['vx']**2 + robot_df['vy']**2)
            df.loc[df['robot'] == robot_name, ['vx', 'vy', 'speed']] = robot_df[['vx', 'vy', 'speed']]
    
    df.to_csv(OUTPUT_CSV, index=False)
    
    print(f"\n{'='*50}")
    print(f"✓ TRACKING COMPLETE!")
    print(f"{'='*50}")
    print(f"Started from frame: {start_frame_num}")
    print(f"Ended at frame: {frame_count}")
    print(f"Frames tracked: {frame_count - start_frame_num}")
    print()
    
    for robot_name in trajectory_data.keys():
        count = len(trajectory_data[robot_name])
        frames_processed = frame_count - start_frame_num
        rate = 100 * count / max(1, frames_processed)
        print(f"{robot_name.capitalize()}: {count}/{frames_processed} frames ({rate:.1f}%)")
    
    print(f"\nOutput files:")
    print(f"  📹 Video: {OUTPUT_VIDEO}")
    print(f"  📊 CSV: {OUTPUT_CSV}")
    print(f"{'='*50}")
else:
    print("\n⚠ ERROR: No trajectories recorded!")