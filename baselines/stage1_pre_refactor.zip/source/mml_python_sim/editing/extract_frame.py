"""
Extract Specific Frame from Video
==================================

Extracts a single frame from a video and saves it as PNG.

Usage:
    python extract_frame.py
"""

import cv2

# Configuration
VIDEO_PATH = '/home/basestation/mml_python_sim/editing/video_with_persistent_trajectories.mp4'
FRAME_NUMBER = 1389
OUTPUT_PATH = '/home/basestation/mml_python_sim/editing/frame_1389.png'

print(f"Opening video: {VIDEO_PATH}")
video = cv2.VideoCapture(VIDEO_PATH)

if not video.isOpened():
    print("❌ Error: Could not open video file")
    exit(1)

# Get video info
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
fps = video.get(cv2.CAP_PROP_FPS)

print(f"Video info:")
print(f"  Total frames: {total_frames}")
print(f"  FPS: {fps}")

if FRAME_NUMBER >= total_frames:
    print(f"❌ Error: Frame {FRAME_NUMBER} exceeds video length ({total_frames} frames)")
    video.release()
    exit(1)

# Jump to specific frame
print(f"\nExtracting frame {FRAME_NUMBER}...")
video.set(cv2.CAP_PROP_POS_FRAMES, FRAME_NUMBER)

# Read frame
ret, frame = video.read()

if ret:
    # Save as PNG
    cv2.imwrite(OUTPUT_PATH, frame)
    print(f"✓ Frame saved: {OUTPUT_PATH}")
    
    # Get timestamp
    timestamp = FRAME_NUMBER / fps
    print(f"  Timestamp: {timestamp:.2f} seconds")
    print(f"  Resolution: {frame.shape[1]}x{frame.shape[0]}")
else:
    print(f"❌ Error: Could not read frame {FRAME_NUMBER}")

video.release()
print("\n✓ Done!")