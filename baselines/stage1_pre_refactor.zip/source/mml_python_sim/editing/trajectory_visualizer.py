"""
Robot Trajectory Visualization with Path Overlay
=================================================

Description:
    Tracks robot positions from video using HSV color detection and overlays
    the complete trajectory path on the video. Shows robot movement history
    with color-coded path (recent = bright, old = faded).

Usage:
    python trajectory_visualizer.py

Input:
    - VIDEO_PATH: Path to input video file
    - HSV color range (LOWER_COLOR, UPPER_COLOR)
    - Perspective transform points (pts_video -> pts_world)

Output:
    - trajectory_with_path.mp4: Video with overlaid trajectory
    - robot_trajectory.csv: Position data
    - trajectory_plot.png: Static plot of full trajectory

Example Console Output:
    Video: 1920x1080 @ 30.0 fps
    Output video: 1920x1080 @ 30.0 fps
    Processing video...
    Frame 100/955: Found 98 positions
    Frame 200/955: Found 198 positions
    ...
    ==================================================
    Visualization complete!
    Total frames: 955
    Positions tracked: 951
    Output video: trajectory_with_path.mp4
    CSV data: robot_trajectory.csv
    Plot: trajectory_plot.png
    ==================================================

Controls (preview mode):
    - 'q': Quit processing
    - 'p': Toggle preview on/off
    - 'space': Pause/resume
"""

import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 25.mp4'
OUTPUT_VIDEO = 'trajectory_with_path.mp4'
OUTPUT_CSV = 'robot_trajectory.csv'
OUTPUT_PLOT = 'trajectory_plot.png'

# HSV color range for robot (from hsv.py tuning)
LOWER_COLOR = np.array([7, 0, 0])
UPPER_COLOR = np.array([68, 139, 175])

# Minimum contour area to filter noise
MIN_CONTOUR_AREA = 500

# Visualization settings
TRAIL_COLOR = (0, 255, 255)  # Cyan for trajectory path
ROBOT_COLOR = (0, 255, 0)    # Green for current position
TRAIL_THICKNESS = 2
TRAIL_LENGTH = 150           # Number of past positions to show (0 = all)
FADE_TRAIL = True            # Fade older positions

# Perspective transform points
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

pts_world = np.float32([
    [-1.5, 1.5],   # Node 0 (x, y in meters)
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# ============================================
# SETUP
# ============================================
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video: {width}x{height} @ {fps} fps")

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(OUTPUT_VIDEO, fourcc, fps, (width, height))
print(f"Output video: {width}x{height} @ {fps} fps")

# Calculate perspective transform
matrix = cv2.getPerspectiveTransform(pts_video, pts_world)

# Storage for trajectory
trajectory_data = []
trajectory_points = []  # List of (x, y) pixel positions

# ============================================
# HELPER FUNCTIONS
# ============================================
def pixel_to_world(pixel_x, pixel_y):
    """Convert pixel coordinates to world coordinates (meters)"""
    point = np.array([[[pixel_x, pixel_y]]], dtype=np.float32)
    world_point = cv2.perspectiveTransform(point, matrix)
    return world_point[0][0][0], world_point[0][0][1]

def find_robot_centroid(frame, lower_color, upper_color):
    """Find robot position using color detection"""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower_color, upper_color)
    
    # Clean up mask
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    
    # Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)
        
        if cv2.contourArea(largest_contour) > MIN_CONTOUR_AREA:
            M = cv2.moments(largest_contour)
            if M["m00"] > 0:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                return cx, cy
    
    return None, None

def draw_trajectory(frame, points, current_idx):
    """Draw trajectory path on frame with fading effect"""
    if len(points) < 2:
        return frame
    
    # Determine which points to draw
    if TRAIL_LENGTH > 0:
        start_idx = max(0, current_idx - TRAIL_LENGTH)
    else:
        start_idx = 0
    
    # Draw lines between consecutive points
    for i in range(start_idx, current_idx):
        if i + 1 < len(points):
            pt1 = points[i]
            pt2 = points[i + 1]
            
            if FADE_TRAIL:
                # Calculate fade factor (0.3 to 1.0, recent = brighter)
                progress = (i - start_idx) / max(1, (current_idx - start_idx))
                alpha = 0.3 + 0.7 * progress
                color = tuple(int(c * alpha) for c in TRAIL_COLOR)
            else:
                color = TRAIL_COLOR
            
            cv2.line(frame, pt1, pt2, color, TRAIL_THICKNESS)
    
    # Draw current position
    if current_idx < len(points):
        current_pos = points[current_idx]
        cv2.circle(frame, current_pos, 8, ROBOT_COLOR, -1)
        cv2.circle(frame, current_pos, 12, (255, 255, 255), 2)
    
    return frame

# ============================================
# MAIN PROCESSING LOOP
# ============================================
frame_count = 0
show_preview = True  # Set False to disable preview for faster processing

print("Processing video...")
print(f"Press 'q' to quit, 'p' to toggle preview, 'space' to pause")

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    timestamp = frame_count / fps
    
    # Find robot position
    pixel_x, pixel_y = find_robot_centroid(frame, LOWER_COLOR, UPPER_COLOR)
    
    if pixel_x is not None:
        # Store pixel position for trajectory drawing
        trajectory_points.append((pixel_x, pixel_y))
        
        # Convert to world coordinates
        world_x, world_y = pixel_to_world(pixel_x, pixel_y)
        
        # Store data
        trajectory_data.append({
            'frame': frame_count,
            'time': timestamp,
            'pixel_x': pixel_x,
            'pixel_y': pixel_y,
            'world_x': world_x,
            'world_y': world_y
        })
    
    # Draw trajectory on frame
    frame_with_trajectory = frame.copy()
    if trajectory_points:
        frame_with_trajectory = draw_trajectory(
            frame_with_trajectory, 
            trajectory_points, 
            len(trajectory_points) - 1
        )
        
        # Add info text
        info_text = f"Frame: {frame_count}/{total_frames} | Points: {len(trajectory_data)}"
        cv2.putText(frame_with_trajectory, info_text, 
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        if pixel_x is not None:
            pos_text = f"Pos: ({world_x:.2f}, {world_y:.2f})m"
            cv2.putText(frame_with_trajectory, pos_text, 
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    # Write frame to output video
    out.write(frame_with_trajectory)
    
    # Show preview
    if show_preview and frame_count % 2 == 0:  # Show every 2nd frame
        display = cv2.resize(frame_with_trajectory, (1280, 720))
        cv2.imshow('Trajectory Visualization', display)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            print("\nStopping early...")
            break
        elif key == ord('p'):
            show_preview = not show_preview
            if not show_preview:
                cv2.destroyAllWindows()
        elif key == ord(' '):
            cv2.waitKey(0)  # Pause
    
    frame_count += 1
    if frame_count % 100 == 0:
        print(f"Frame {frame_count}/{total_frames}: Found {len(trajectory_data)} positions")

video.release()
out.release()
cv2.destroyAllWindows()

# ============================================
# SAVE DATA
# ============================================
df = pd.DataFrame(trajectory_data)

# Add velocity calculations
if len(df) > 1:
    df['vx'] = df['world_x'].diff() / df['time'].diff()
    df['vy'] = df['world_y'].diff() / df['time'].diff()
    df['speed'] = np.sqrt(df['vx']**2 + df['vy']**2)
    df['vx_smooth'] = df['vx'].rolling(window=5, center=True).mean()
    df['vy_smooth'] = df['vy'].rolling(window=5, center=True).mean()

df.to_csv(OUTPUT_CSV, index=False)

# ============================================
# CREATE STATIC PLOT
# ============================================
if len(df) > 0:
    plt.figure(figsize=(10, 10))
    
    # Plot trajectory in world coordinates
    plt.plot(df['world_x'], df['world_y'], 'b-', linewidth=1, alpha=0.6, label='Path')
    plt.scatter(df['world_x'].iloc[0], df['world_y'].iloc[0], 
                c='green', s=100, marker='o', label='Start', zorder=5)
    plt.scatter(df['world_x'].iloc[-1], df['world_y'].iloc[-1], 
                c='red', s=100, marker='X', label='End', zorder=5)
    
    # Add grid and reference points (your nodes)
    plt.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    plt.axvline(x=0, color='k', linestyle='--', alpha=0.3)
    
    # Mark the 4 corner points
    corners = [(-1.5, 1.5), (1.5, 1.5), (-1.5, -1.5), (1.5, -1.5)]
    corner_labels = ['Node 0', 'Node 2', 'Node 3', 'Node 7']
    for (x, y), label in zip(corners, corner_labels):
        plt.scatter(x, y, c='orange', s=150, marker='s', edgecolors='black', zorder=4)
        plt.text(x, y+0.15, label, ha='center', fontsize=9)
    
    plt.xlabel('X Position (meters)', fontsize=12)
    plt.ylabel('Y Position (meters)', fontsize=12)
    plt.title('Robot Trajectory (World Coordinates)', fontsize=14, fontweight='bold')
    plt.legend(loc='upper right')
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(OUTPUT_PLOT, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"\nTrajectory plot saved: {OUTPUT_PLOT}")

# ============================================
# SUMMARY
# ============================================
print(f"\n{'='*50}")
print(f"Visualization complete!")
print(f"Total frames: {frame_count}")
print(f"Positions tracked: {len(trajectory_data)}")
print(f"Detection rate: {100*len(trajectory_data)/frame_count:.1f}%")
print(f"Output video: {OUTPUT_VIDEO}")
print(f"CSV data: {OUTPUT_CSV}")
print(f"Plot: {OUTPUT_PLOT}")
print(f"{'='*50}")