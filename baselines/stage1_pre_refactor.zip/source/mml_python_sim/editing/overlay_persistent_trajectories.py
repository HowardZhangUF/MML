"""
Overlay Persistent World Coordinate Trajectories on Video
=========================================================

Draws the COMPLETE trajectory history on each frame - paths accumulate
and remain visible throughout the video (like drawing with a permanent marker).

Features:
- Full trajectory history stays visible
- Trajectories build up over time
- Clean overlay without node markers
- Smooth anti-aliased lines

Usage:
    python overlay_persistent_trajectories.py
"""

import cv2
import numpy as np
import pandas as pd
from collections import defaultdict

# ============================================
# CONFIGURATION
# ============================================
VIDEO_PATH = '/home/basestation/Downloads/Video Project 52.mp4'
TRAJECTORY_CSV = 'robot_trajectories_csrt.csv'
OUTPUT_VIDEO = 'video_with_persistent_trajectories.mp4'

# Same perspective transform as tracker
pts_video = np.float32([
    [599, 292],   # Node 0
    [1543, 306],  # Node 2
    [598, 837],   # Node 3
    [1532, 855]   # Node 7
])

pts_world = np.float32([
    [-1.5, 1.5],   # Node 0
    [1.5, 1.5],    # Node 2
    [-1.5, -1.5],  # Node 3
    [1.5, -1.5]    # Node 7
])

# Robot colors (BGR format for OpenCV)
COLORS = {
    'drone': (255, 0, 255),      # Magenta
    'turtle1': (0, 255, 0),      # Green
    'turtle2': (0, 255, 255),    # Cyan
}

# Trajectory display settings
TRAJECTORY_THICKNESS = 3        # Line thickness
TRAJECTORY_ALPHA = 0.8          # Transparency (0=invisible, 1=opaque)
SHOW_CURRENT_POSITION = True    # Show moving dots?
CURRENT_POSITION_RADIUS = 8     # Size of moving dot
SHOW_START_MARKERS = True       # Show where each robot started?
SHOW_LABELS = True              # Show robot names?

# ============================================
# SETUP
# ============================================
print("Loading trajectory data...")
df = pd.read_csv(TRAJECTORY_CSV)

# Get inverse perspective transform (world -> pixel)
matrix_world_to_pixel = cv2.getPerspectiveTransform(pts_world, pts_video)

def world_to_pixel(world_x, world_y):
    """Convert world coordinates back to pixel coordinates"""
    point = np.array([[[world_x, world_y]]], dtype=np.float32)
    pixel_point = cv2.perspectiveTransform(point, matrix_world_to_pixel)
    return int(pixel_point[0][0][0]), int(pixel_point[0][0][1])

# Open video
video = cv2.VideoCapture(VIDEO_PATH)
fps = video.get(cv2.CAP_PROP_FPS)
width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))

print(f"Video: {width}x{height} @ {fps} fps, {total_frames} frames")

# Setup video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(OUTPUT_VIDEO, fourcc, fps, (width, height))

# Organize trajectories by robot and frame
trajectories = defaultdict(lambda: defaultdict(dict))

for _, row in df.iterrows():
    frame = int(row['frame'])
    robot = row['robot']
    world_x = row['world_x']
    world_y = row['world_y']
    
    # Convert to pixel coordinates
    pixel_x, pixel_y = world_to_pixel(world_x, world_y)
    
    trajectories[robot][frame] = {
        'pixel': (pixel_x, pixel_y),
        'world': (world_x, world_y)
    }

print(f"Loaded trajectories for {len(trajectories)} robots")

# Get start frames for each robot
robot_start_frames = {}
for robot in trajectories.keys():
    robot_start_frames[robot] = min(trajectories[robot].keys())
    print(f"  {robot}: starts at frame {robot_start_frames[robot]}")

# ============================================
# CREATE PERSISTENT TRAJECTORY OVERLAY
# ============================================
print("\nCreating persistent trajectory overlay...")
print("This may take a few minutes...\n")

# Create a persistent trajectory canvas (transparent background)
# This will accumulate all trajectories as they are drawn
trajectory_canvas = np.zeros((height, width, 3), dtype=np.uint8)

# Track previous positions for line drawing
prev_positions = {robot: None for robot in trajectories.keys()}

frame_count = 0
video.set(cv2.CAP_PROP_POS_FRAMES, 0)

while True:
    ret, frame = video.read()
    if not ret:
        break
    
    # Draw NEW trajectory segments on the persistent canvas
    for robot, color in COLORS.items():
        if robot not in trajectories:
            continue
        
        # Check if this robot has data for current frame
        if frame_count in trajectories[robot]:
            current_pos = trajectories[robot][frame_count]['pixel']
            
            # Draw line from previous position to current position
            if prev_positions[robot] is not None:
                cv2.line(trajectory_canvas, prev_positions[robot], current_pos,
                        color, TRAJECTORY_THICKNESS, lineType=cv2.LINE_AA)
            
            # Draw start marker (only on first appearance)
            if SHOW_START_MARKERS and frame_count == robot_start_frames[robot]:
                cv2.circle(trajectory_canvas, current_pos, 12, (255, 255, 255), -1)
                cv2.circle(trajectory_canvas, current_pos, 10, color, -1)
                cv2.putText(trajectory_canvas, "START", 
                          (current_pos[0] - 30, current_pos[1] - 15),
                          cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            
            prev_positions[robot] = current_pos
    
    # Blend persistent trajectory canvas with current video frame
    # This shows ALL trajectories accumulated so far
    frame_with_trajectories = cv2.addWeighted(frame, 1.0, 
                                              trajectory_canvas, TRAJECTORY_ALPHA, 0)
    
    # Draw current position markers (moving dots on top of trajectories)
    if SHOW_CURRENT_POSITION:
        for robot, color in COLORS.items():
            if robot not in trajectories:
                continue
            
            if frame_count in trajectories[robot]:
                current_pos = trajectories[robot][frame_count]['pixel']
                
                # Pulsing effect (optional - makes dots "breathe")
                pulse = int(5 * np.sin(frame_count * 0.2) + 5)
                radius = CURRENT_POSITION_RADIUS + pulse
                
                # Draw dot with white border
                cv2.circle(frame_with_trajectories, current_pos, radius + 2, 
                          (255, 255, 255), -1)
                cv2.circle(frame_with_trajectories, current_pos, radius, color, -1)
                
                # Draw robot label
                if SHOW_LABELS:
                    label = robot.upper()
                    label_pos = (current_pos[0] + 15, current_pos[1] - 10)
                    
                    # Text background for readability
                    (text_width, text_height), _ = cv2.getTextSize(
                        label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                    cv2.rectangle(frame_with_trajectories,
                                (label_pos[0] - 2, label_pos[1] - text_height - 2),
                                (label_pos[0] + text_width + 2, label_pos[1] + 2),
                                (0, 0, 0), -1)
                    
                    cv2.putText(frame_with_trajectories, label, label_pos,
                              cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
    
    # Add frame counter and info
    cv2.rectangle(frame_with_trajectories, (5, 5), (300, 70), (0, 0, 0), -1)
    cv2.putText(frame_with_trajectories, f"Frame: {frame_count}/{total_frames}", 
               (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    # Show which robots are active
    active_robots = [r for r in trajectories.keys() if frame_count in trajectories[r]]
    if active_robots:
        active_text = f"Active: {', '.join([r.upper() for r in active_robots])}"
        cv2.putText(frame_with_trajectories, active_text, (10, 55),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Write frame
    out.write(frame_with_trajectories)
    
    # Progress update
    if frame_count % 100 == 0:
        progress = 100 * frame_count / total_frames
        print(f"Progress: {frame_count}/{total_frames} ({progress:.1f}%)")
    
    frame_count += 1

video.release()
out.release()

print("\n" + "="*60)
print("✓ PERSISTENT TRAJECTORY VIDEO COMPLETE!")
print("="*60)
print(f"Output: {OUTPUT_VIDEO}")
print(f"Frames processed: {frame_count}")
print("\nFeatures:")
print("  ✓ Complete trajectory history visible")
print("  ✓ Paths accumulate as robots move")
print("  ✓ Current positions marked with pulsing dots")
print("  ✓ Start positions marked")
print("="*60)