# ScratchTransformer — Design & Integration Guide

## What it does

`ScratchTransformer` is a causal (decoder-only) Transformer trained to predict
the **next-step velocity** `(vx, vy)` of a target from a short window of its
recent position history.  It is the "Transformer" / "MultiPFTra" motion model
inside the particle filter.

---

## Architecture

```
Input: (N_particles, N_th * input_dim)   e.g. (500, 10)  for N_th=5, input_dim=2
  │
  reshape → (N_particles, N_th, input_dim)   e.g. (500, 5, 2)
  │
  ┌─────────────────────────────────────────────────────┐
  │  Linear embed:  input_dim → n_embed                 │  (500, 5, 20)
  │  + Learned positional embedding: N_th → n_embed     │
  └─────────────────────────────────────────────────────┘
  │
  ┌─────────────────────────────────────────────────────┐
  │  Block × n_layer                                    │
  │  ┌───────────────────────────────────────────────┐  │
  │  │  LayerNorm → MultiHeadAttention (causal mask) │  │
  │  │  + residual                                   │  │
  │  │  LayerNorm → FeedForward (n_embed → 10×)      │  │
  │  │  + residual                                   │  │
  │  └───────────────────────────────────────────────┘  │
  └─────────────────────────────────────────────────────┘
  │                               (500, 5, 20)
  LayerNorm (ln_f)
  │
  take last time step only:      (500, 20)
  │
  Linear → ReLU:   n_embed → hidden_dim              (500, 20)
  │
  Linear:          hidden_dim → 2                    (500, 2)
  │
Output: (N_particles, 2)   →  (vx, vy) predictions
```

### Module breakdown

| Module | File location | Role |
|--------|--------------|------|
| `Head` | [scratch_transformer.py:35](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L35) | Single causal self-attention head. Projects input to K, Q, V; applies lower-triangular mask; returns weighted sum of values. |
| `MultiHeadAttention` | [scratch_transformer.py:75](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L75) | Runs `n_head` Heads in parallel, concatenates, projects back to `input_dim`. |
| `FeedForward` | [scratch_transformer.py:95](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L95) | Two-layer MLP with hidden size `10 × input_dim` and ReLU. Applied per time step. |
| `Block` | [scratch_transformer.py:111](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L111) | One Transformer layer: LayerNorm → MultiHeadAttention → residual, then LayerNorm → FeedForward → residual. |
| `ScratchTransformer` | [scratch_transformer.py:136](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L136) | Full model: embed → positional encoding → Blocks → LayerNorm → MLP head → output last token. |

### Causal mask

Every `Head` registers a lower-triangular mask of shape `(N_th, N_th)`:

```python
self.register_buffer("tril", torch.tril(torch.ones(block_size, block_size)))
```

Attention scores for future positions are set to `-inf` before softmax, so
position `k` can only attend to positions `0 … k`.  This is what makes the
model **autoregressive** — it predicts the next step from the past only.

### Hyperparameters in production

Set in [ParticleFilter.py:70-77](src/mml_guidance/mml_guidance/ParticleFilter.py#L70-L77):

```python
ScratchTransformer(
    input_dim  = 2,   # [x, y] per time step
    block_size = 5,   # N_th = 5 history steps
    n_embed    = 20,  # embedding dimension
    n_head     = 8,   # attention heads (head_size = 20/8 ≈ 2)
    n_layer    = 2,   # Transformer blocks
    hidden_dim = 20,  # MLP head hidden size
)
```

Parameter count: ~6 000 — intentionally tiny for real-time inference.

---

## Data format

### Input `X`

Shape `(N, N_th * input_dim)` — a flat vector per particle:

```
[x_{t-4}, y_{t-4},  x_{t-3}, y_{t-3},  ...,  x_{t}, y_{t}]
 ──────── step 0 ──  ──────── step 1 ──        ──────── step 4 ──
```

The model reshapes this internally to `(N, N_th, input_dim)`.

### Output

Shape `(N, 2)` — predicted velocity `(vx, vy)` in m/s.

### Velocity label convention

Targets are `(next_pos - current_pos) / dt`, computed in
[ParticleFilter.py:724-728](src/mml_guidance/mml_guidance/ParticleFilter.py#L724-L728)
during online training:

```python
y_train = (y_train - X_train[:, -1, :2]) / X_train[:, -1, 2]
```

and in [train.py](src/mml_guidance/mml_guidance/mml_network/train.py) for
offline training from CSV.

---

## Integration with ParticleFilter

### Initialisation

[ParticleFilter.py:40-77](src/mml_guidance/mml_guidance/ParticleFilter.py#L40-L77)

```python
if prediction_method == "Transformer":
    self.N_th = 5              # history window
    self.nn_input_size = 10    # N_th * input_dim
    self.motion_model = ScratchTransformer(
        input_dim=2, block_size=5,
        n_embed=20, n_head=8, n_layer=2, hidden_dim=20,
    )
    # then loads checkpoint weights from model_path
```

### Predict step — `predict_mml()`

Called every filter step from `pf_loop()`:

```
particles: (N_th, N, 2)
  │
  transpose + reshape → (N, N_th * 2)   # flatten for the network
  │
  motion_model.predict(X)               # forward pass → (N, 2) velocities
  │
  next_pos = particles[-1, :, :2] + v_pred * dt_history[-1]
  │
  roll time window: drop oldest step, append next_pos
  │
  add process noise to latest step
  │
particles: (N_th, N, 2)   updated
```

Key lines: [ParticleFilter.py:428-463](src/mml_guidance/mml_guidance/ParticleFilter.py#L428-L463)

The `dt` used for position integration is `dt_history[-1]` — the **live sim dt**
(0.05 s from config.yaml).  This is correct for the Transformer because its
training labels were also computed at whatever dt the sim was running at.
(Contrast with CFM which uses its own stored training dt.)

### `predict()` method on the model

[scratch_transformer.py:198-205](src/mml_guidance/mml_guidance/mml_network/scratch_transformer.py#L198-L205)

```python
def predict(self, x):
    with torch.no_grad():
        return self.forward(
            torch.from_numpy(x.astype(np.float32)).to(device)
        ).cpu().detach().numpy()
```

Wraps `forward()` for numpy-in / numpy-out inference, matching the interface
expected by `predict_mml()` and `_model_predict_numpy()` in the sim script.

---

## Training

### Offline — `train.py`

[train.py:27-61](src/mml_guidance/mml_guidance/mml_network/train.py#L27-L61)

Standard supervised loop: MSE loss on `(vx, vy)`, Adam optimiser, no
mini-batching (full dataset per epoch for the sizes used here).

```python
for epoch in range(epochs):
    outputs = model(X_train)          # (N, 2) velocity predictions
    loss = criterion(outputs, y_train) # MSE
    loss.backward()
    optimizer.step()
```

Training data is a CSV where each row is:
`[x0,y0, x1,y1, ..., x4,y4,  vx_next, vy_next]`

### Hyperparameter search — `parameter_search()`

[train.py:72-118](src/mml_guidance/mml_guidance/mml_network/train.py#L72-L118)

Grid search over `n_embed`, `n_head`, `n_layer`, `hidden_dim`.  Saves the
checkpoint with the lowest test loss.  The default grid:

```python
param_grid = {
    "hidden_dim": [20, 30],
    "n_embed":    [20, 40],
    "n_head":     [6, 8],
    "n_layer":    [1, 2],
    "input_dim":  [2],
}
```

### Online fine-tuning — `optimize_learned_model()`

[ParticleFilter.py:730-758](src/mml_guidance/mml_guidance/ParticleFilter.py#L730-L758)

During simulation, if the state history buffer is sufficiently full:
- Samples up to `max_batch_size=64` recent windows from `state_history`
- Computes velocity labels from consecutive positions
- Runs 5 SGD epochs with Adam lr=0.001
- Updates the live model weights in-place

This lets the Transformer adapt to the specific target motion seen in a run,
but is only triggered for `NN` and `Transformer` methods (not CFM).

---

## Comparison with CFM

| Property | ScratchTransformer | CFM |
|---|---|---|
| Output | Single deterministic `(vx, vy)` | Stochastic sample from learned distribution |
| History window | N_th = 5 | N_th = 10 |
| Embedding dim | 20 | 64 |
| Predict cost (500p) | ~9 ms | ~16 ms |
| Multi-modal? | No (add noise manually for viz) | Yes (inherently stochastic) |
| Online fine-tuning | Yes (`optimize_learned_model`) | No |
| Training dt | Live sim dt (via `dt_history[-1]`) | Fixed training dt (0.033 s, stored in checkpoint) |

---

## Why CFM is slower: N_th and embedding dim are equally responsible

The encoder (Transformer backbone) is the bottleneck in both models. The
VelocityHead MLP that CFM adds on top costs only ~0.2 ms — negligible.

Measured on 500 particles, encoder only:

```
Config                         Cost      Δ from baseline
──────────────────────────────────────────────────────────
N_th= 5, emb=20  (Transformer)  3.1 ms   baseline
N_th= 5, emb=64  (bigger embed) 5.6 ms   +2.5 ms  ← emb alone
N_th=10, emb=20  (longer window) 5.6 ms  +2.5 ms  ← N_th alone
N_th=10, emb=64  (real CFM)     12.1 ms   +9.0 ms  ← both together

VelocityHead × 2 (N_FE=2)       0.4 ms   (irrelevant)
──────────────────────────────────────────────────────────
Full Transformer predict:        9.2 ms
Full CFM propose (N_FE=2):      15.8 ms   1.7× slower
```

**N_th and emb each add ~2.5 ms in isolation, but together they add 9 ms.**
That non-linear interaction happens because the self-attention cost scales as
`O(N_th² × emb)`: doubling N_th quadruples the attention matrix, and
tripling emb triples each matrix element — both factors multiply together.

### What is stored in the embedding?

Both models produce a `(B, n_embed)` vector from their encoder — one number
per embedding dimension per particle. It is **not** human-interpretable; it is
a learned compressed summary of the position history.

**Transformer — 20-dim embedding:**
```
Input: 5 positions × 2 coords = 10 numbers
Compressed to: 20 numbers
Each of the 20 numbers is a weighted mix of all 5 history positions,
where the mixing weights are learned by attention.
Ratio: 10 → 20  (2× expansion)
```

**CFM — 64-dim embedding:**
```
Input: 10 positions × 2 coords = 20 numbers
Compressed to: 64 numbers
Each of the 64 numbers is a weighted mix of all 10 history positions.
Ratio: 20 → 64  (3.2× expansion)
```

The CFM needs the larger embedding because it serves a harder task: the
embedding must carry enough information for the `VelocityHead` to condition
the ODE on — it needs to distinguish not just "where is the target going" but
"which mode of motion is it in right now" (e.g. straight vs turning). The
Transformer just maps context → single vector so a 20-dim summary is enough.

### Why CFM cannot output a single vector (and the Transformer can)

The Transformer is trained with MSE loss: for a given context, there is one
"correct" target velocity in the training data. MSE forces the network to
predict the **mean** of whatever distribution the data implies. If the target
could go left or right with equal probability, the Transformer predicts
straight — the average of the two modes. This is fine as a point estimate.

The CFM is trained to learn the **entire distribution**. At inference it draws
a different random starting point `x0` for each particle, so each particle
samples a different part of the velocity distribution. This is why stochasticity
is not optional for CFM — without it, every particle would get the same `x0`
and the stochastic advantage disappears completely. The 64-dim embedding is
what gives the `VelocityHead` enough signal to shape that distribution correctly
per particle.

---

## Can we shrink CFM to match Transformer speed?

Yes — but it **requires retraining**. The checkpoint bakes in the architecture,
so you cannot just change N_th or n_embed at runtime. Here is what the speed
gain actually looks like, measured on 500 particles:

```
Config                          Encoder cost   Params    vs current CFM
────────────────────────────────────────────────────────────────────────
CFM current  (N_th=10, emb=64)   13.2 ms      225 k     baseline
CFM N_th=5   (emb=64 kept)        6.1 ms      225 k     2.2× faster
CFM emb=20   (N_th=10 kept)       6.3 ms       40 k     2.1× faster
CFM small    (N_th=5, emb=20)     3.3 ms       26 k     4× faster  ← same as Transformer
CFM medium   (N_th=5, emb=32)     5.0 ms       57 k     2.6× faster
────────────────────────────────────────────────────────────────────────
Transformer  (N_th=5, emb=20)     9.2 ms total  6 k     reference
```

### The trade-off

Shrinking is not free:

| What you lose by reducing N_th 10→5 | What you lose by reducing emb 64→20 |
|---|---|
| The anchor velocity `v_anchor = (pos[-1] - pos[-2]) / dt` still works with 5 steps, but the **Transformer context** sees less motion history — sharp direction changes that happened 6-10 steps ago become invisible | The VelocityHead gets a weaker summary of the context. With emb=20 it has less capacity to separate multi-modal velocity distributions — the main reason CFM was chosen over the Transformer in the first place |

**Recommended approach: `N_th=5, emb=32`** — the medium config.
- 2.6× faster than current CFM
- Still faster than Transformer  
- emb=32 gives the VelocityHead more than the Transformer's 20 dims, so
  multi-modal separation should be noticeably better than pure Transformer
- N_th=5 matches the Transformer's window, so anchor velocity still works

### How to retrain with smaller config

```bash
cd src/mml_guidance/mml_guidance/mml_network

# train_cfm.py validates that the CSV has n_th*2 columns.
# If you currently have the N_th=10 CSV, it will refuse and tell you to
# re-run generate_synthetic_data.py with N_TH=5 first.
# Check whether generate_synthetic_data.py accepts a --n_th flag,
# or edit the N_TH constant at the top of that file.

python train_cfm.py \
    --n_th 5 \
    --n_embed 32 \
    --n_head 8 \
    --n_layer 2 \
    --vel_hidden 64 \
    --n_fe 10 \
    --epochs 1500 \
    --anchor_sigma 0.3
```

Note: `--n_fe 10` during training sets how many Euler steps are used in the
*training* rollout. You can still set `N_FE=2` at inference inside
`ParticleFilter.__init__()` without retraining — fewer steps at inference is
a runtime trade-off, not baked into the weights.

The checkpoint saves all hyperparameters, so `load_cfm_model()` in
`ParticleFilter` will reconstruct the smaller architecture automatically —
**no code changes needed** in `ParticleFilter.py` or `info_mml_main.py`.

### One thing to verify after retraining

`predict_cfm()` uses `self.motion_model._cfm.dt` for position integration and
`self.N_th` for context flattening. Both are read from the checkpoint at load
time, so a smaller retrained model will automatically set `N_th=5` when loaded.
Check that `ParticleFilter.__init__` line 41 still reads:

```python
self.N_th = 10 if self.prediction_method == "CFM" else 5
```

This will be overridden by whatever `block_size` is in the checkpoint, because
`load_cfm_model()` reads the config and sets `self.N_th` accordingly. But to
be safe, you could change it to:

```python
self.N_th = 5   # if retraining with N_th=5
```

before running.

---

## Run command

```bash
python scripts/info_mml_main.py --prediction_method MultiPFTra --guidance_mode MultiPFInfo
```

---

---

# Conditional Flow Matching (CFM) — Motion Model in the Particle Filter

## What it does differently from the Transformer

The Transformer outputs a **single deterministic** velocity at each step.
Every particle fed to it from the same context window gets the same prediction —
diversity comes only from the particle positions themselves (and optional manual
noise added for visualisation).

The CFM produces a **stochastic sample** each call: it integrates a learned
vector field from a random initial point, so two particles with identical
histories still get different velocity draws. This is the key property that
makes it genuinely multi-modal — it can model a target that might turn left *or*
right, not just their average.

---

## Files involved

| File | Role |
|------|------|
| [velocity_network.py](src/mml_guidance/mml_guidance/mml_network/velocity_network.py) | Neural net: `ContextEncoder` + `VelocityHead` → `CFMVelocityNetwork` |
| [cfm_motion_model.py](src/mml_guidance/mml_guidance/mml_network/cfm_motion_model.py) | `CFMMotionModel` (train + infer), `CFMShim` (PF-compatible wrapper), `load_cfm_model()` |
| [ParticleFilter.py](src/mml_guidance/mml_guidance/ParticleFilter.py) | `predict_cfm()` — the CFM equivalent of `predict_mml()` |
| [train_cfm.py](src/mml_guidance/mml_guidance/mml_network/train_cfm.py) | Offline training script |
| [generate_synthetic_data.py](src/mml_guidance/mml_guidance/mml_network/generate_synthetic_data.py) | Generates the training CSV |

---

## Architecture

The CFM network has two sub-networks that serve different roles:

```
┌──────────────────────────────────────────────────────────────────────┐
│  CFMVelocityNetwork   (velocity_network.py)                          │
│                                                                      │
│  ┌────────────────────────────────────────┐                          │
│  │  ContextEncoder  (called ONCE per step)│                          │
│  │                                        │                          │
│  │  Input: (B, N_th * 2)  flat history    │                          │
│  │    reshape → (B, N_th=10, 2)           │                          │
│  │    Linear embed: 2 → n_embed=64        │  (B, 10, 64)             │
│  │    + Learned positional embedding      │                          │
│  │    _Block × n_layer=2 (causal attn)    │                          │
│  │    LayerNorm                           │                          │
│  │    take last token → (B, 64)           │                          │
│  └─────────────────┬──────────────────────┘                          │
│                    │ emb  (B, 64)                                     │
│                    │                                                  │
│  ┌─────────────────▼──────────────────────┐                          │
│  │  VelocityHead  (called N_FE times)     │                          │
│  │                                        │                          │
│  │  Input: cat(emb[64], x_tau[2], tau[1]) │  (B, 67)                 │
│  │    Linear → ReLU: 67 → vel_hidden=128  │                          │
│  │    Linear → ReLU: 128 → 128            │                          │
│  │    Linear: 128 → 2                     │                          │
│  │  Output: velocity direction (B, 2)     │                          │
│  └────────────────────────────────────────┘                          │
└──────────────────────────────────────────────────────────────────────┘
```

### Why two sub-networks?

The Transformer `ContextEncoder` is the **expensive** part (~56 ms for 500
particles). The `VelocityHead` MLP is cheap (~1.6 ms per call). During Euler
integration, `encode_context` runs **once**, then `predict_velocity` runs
`N_FE` times reusing the same embedding. This is why the split exists.

```python
# Inside CFMMotionModel.propose()
emb = self.network.encode_context(c_t)      # transformer: runs once

for s in range(self.N_FE):                  # MLP: runs N_FE times
    v = self.network.predict_velocity(x, tau, emb)
    x = x + delta * v
```

---

## OT-CFM: the core idea

Standard flow matching trains a vector field `v_θ` to interpolate between a
**base distribution** `x0` and the **target** `y` (the true next velocity):

```
x_tau = (1 - tau) * x0  +  tau * y        # linear path from base to target
u_target = y - x0                          # the vector field to learn

Loss = MSE( v_θ(x_tau, tau, context) ,  u_target )
```

At inference, Euler integration follows that field from `x0` to produce a
velocity sample:

```
x_0 = v_anchor + anchor_sigma * N(0, I)    # start near finite-diff velocity
for s in 0 .. N_FE-1:
    tau = s / N_FE
    x   = x + (1/N_FE) * v_θ(x, tau, context)
return x    # ≈ velocity sample
```

### Anchored base distribution

A key design choice: instead of sampling `x0` from pure `N(0, I)`, it is
anchored near the **finite-difference velocity**:

```python
v_anchor = (pos[-1] - pos[-2]) / dt       # last observed velocity
x0 = v_anchor + anchor_sigma * N(0, I)    # small noise around it
```

This keeps the starting point inside the training distribution — a target
moving at 0.4 m/s north starts the ODE near (0, 0.4) instead of somewhere
random, so the network needs far fewer Euler steps to reach a good answer.

---

## Integration with ParticleFilter

### Initialisation — `__init__()`

[ParticleFilter.py:78-97](src/mml_guidance/mml_guidance/ParticleFilter.py#L78-L97)

```python
elif self.prediction_method == "CFM":
    self.N_th = 10               # longer history than Transformer (5)
    self.nn_input_size = 20      # N_th * input_dim
    from .mml_network.cfm_motion_model import load_cfm_model
    self.motion_model = load_cfm_model(
        model_path = model_path,
        input_dim  = 2,
        block_size = self.N_th,
        n_embed=64, n_head=8, n_layer=2, vel_hidden=128, N_FE=2,
    )
    # load_cfm_model() returns CFMShim wrapping CFMMotionModel.
    # Checkpoint config overrides the fallback defaults above automatically.
```

`load_cfm_model()` returns a `CFMShim` — a thin wrapper that exposes
`.predict(X)` (same signature as `ScratchTransformer.predict`) **and**
`.propose(X)` (direct stochastic call). The shim lets `predict_mml()` be called
if needed, but `predict_cfm()` uses `.propose()` directly.

### Predict step — `predict_cfm()`

[ParticleFilter.py:465-492](src/mml_guidance/mml_guidance/ParticleFilter.py#L465-L492)

This is the CFM equivalent of `predict_mml()`. Differences:

```
predict_mml()  (Transformer)              predict_cfm()  (CFM)
─────────────────────────────────         ─────────────────────────────────
motion_model.predict(X)                   motion_model.propose(X)
  → deterministic forward pass              → stochastic Euler ODE integration
  → same output for same X                  → different output every call

uses dt_history[-1]  (live sim dt)        uses motion_model._cfm.dt  (training dt)
  = 0.05 s                                  = 0.033 s
```

Full flow:

```
particles: (N_th=10, N, 2)
  │
  transpose + reshape → (N, 20)          # flatten position history
  │
  motion_model.propose(c_flat)           # CFM Euler ODE → stochastic (N, 2) velocity
  │  (clip to MAX_SPEED=1.5 m/s inside propose())
  │
  train_dt = motion_model._cfm.dt        # 0.033 — NOT the sim's 0.05
  │
  particles[:-1] = particles[1:]         # shift history window
  particles[-1, :, :2] = prev_pos + v_pred * train_dt
  │
  add process noise to latest step
  │
particles: (N_th=10, N, 2)   updated
```

### Dispatch in `pf_loop()`

[ParticleFilter.py:267-271](src/mml_guidance/mml_guidance/ParticleFilter.py#L267-L271)

```python
if self.prediction_method == "CFM":
    self.particles = self.predict_cfm(np.copy(self.particles), self.dt_history)
elif self.prediction_method in {"NN", "Transformer"}:
    self.particles = self.predict_mml(np.copy(self.particles), self.dt_history)
```

CFM has its own branch — it must not go through `predict_mml()` because the dt
and the call signature differ.

---

## Design choices and why they differ from the Transformer

| Decision | Transformer | CFM | Reason |
|---|---|---|---|
| History length N_th | 5 | 10 | CFM needs more context for its anchor velocity to be reliable; also tests whether longer history improves multi-modal coverage |
| Output type | Single vector | Distribution sample | CFM's stochastic ODE naturally produces different samples — no separate noise injection needed |
| dt for position update | Live sim dt (0.05 s) | Training dt (0.033 s) | CFM velocity scale is fixed at training time; using a different dt at inference pushes the anchor out of distribution and causes particles to blow up |
| Velocity clipping | Not needed (MSE-trained, bounded) | 1.5 m/s cap inside `propose()` | ODE integration can occasionally diverge on out-of-distribution contexts; clip prevents boundary explosion |
| Embedding dim | 20 | 64 | CFM encoder must capture enough context for the VelocityHead to condition on; larger embedding → better multi-modal separation |
| Predict cost (500p) | ~9 ms | ~16 ms | 1.7× slower: N_th and emb each contribute equally; VelocityHead adds <1 ms |

---

## Online fine-tuning: why CFM doesn't have it (yet)

The Transformer has `optimize_learned_model()` / `optimize_learned_model_callback()`
([ParticleFilter.py:379-388](src/mml_guidance/mml_guidance/ParticleFilter.py#L379-L388))
which fine-tunes the network on recent observations mid-run.

CFM currently has no equivalent. The reason is architectural:

- **Transformer** online training: standard supervised MSE on `(context → velocity)`.
  Cheap — one forward + one backward pass on 64 samples.

- **CFM** online training: must also sample `tau ~ U(0,1)` and `x0 ~ anchored N`,
  construct `x_tau`, compute the flow target `u_target = y - x0`, and then
  backprop through the full `CFMVelocityNetwork`.  The `CFMShim` already has
  an `online_train()` method ([cfm_motion_model.py:569-587](src/mml_guidance/mml_guidance/mml_network/cfm_motion_model.py#L569-L587))
  that wraps `CFMMotionModel.train()` for exactly this, but `ParticleFilter`
  never calls it.

To wire it up (parallel to the Transformer path), you would:

1. In `optimize_learned_model_callback()`, extend the condition:
```python
if filled_elements > self.N_th + self.max_batch_size * 0.6 and (
    self.prediction_method in {"NN", "Transformer", "CFM"}   # add CFM here
):
    self.optimize_learned_model(filled_elements)
```

2. In `optimize_learned_model()`, add a CFM branch:
```python
if self.prediction_method == "CFM":
    X_flat = X_train.reshape(X_train.shape[0], -1).cpu().numpy()
    y_np   = y_train.cpu().numpy()
    self.motion_model.online_train(X_flat, y_np, epochs=5, lr=5e-4)
    return
```

The `online_train()` method on `CFMShim` already exists and handles the
OT-CFM loss internally — no new code is needed in the model itself.

---

## Training pipeline

```
generate_synthetic_data.py
  │  Simulates 8-node Markov road graph, dt=0.033 s, N_th=10
  │  → CSV: (N, 20) context + (N, 2) velocity labels
  ▼
train_cfm.py
  │  load_training_csv() → chronological_split(70/30)
  │  CFMMotionModel.train():
  │    for each batch:
  │      v_anchor = (pos[-1] - pos[-2]) / dt
  │      x0 = v_anchor + anchor_sigma * N(0,I)
  │      tau ~ U(0,1)
  │      x_tau = (1-tau)*x0 + tau*y
  │      u_target = y - x0
  │      loss = MSE(v_θ(x_tau, tau, context), u_target)
  │  cosine LR decay: lr → lr*0.01 over 1500 epochs
  ▼
cfm_motion_model.pth
  │  checkpoint contains: state_dict + full config (dt, N_th, n_embed, …)
  ▼
load_cfm_model() in ParticleFilter.__init__()
  │  rebuilds architecture from checkpoint config automatically
  ▼
CFMShim.predict() / CFMMotionModel.propose()
```

---

## Run command

```bash
# CFM prediction, no trajectory fan (fastest)
python scripts/info_mml_main.py --prediction_method CFM --no_fan

# CFM with fan visualisation
python scripts/info_mml_main.py --prediction_method CFM

# Transformer for comparison
python scripts/info_mml_main.py --prediction_method MultiPFTra
```
