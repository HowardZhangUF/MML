# CFM Architecture, Data Flow & Pipeline

---

## 1. End-to-end pipeline overview

```
generate_synthetic_data.py
        │
        │  simulates 8-node Markov road graph
        │  records only visible (non-occluded) positions
        │  builds (X, y) pairs: X = flattened history, y = velocity
        ▼
  training CSV
  (N, N_th*2 + 2)
        │
        ▼
   train_cfm.py
        │
        │  builds CFMMotionModel(N_th, n_embed, …)
        │  runs OT-CFM training loop
        │  saves checkpoint  →  cfm_motion_model.pth
        ▼
  cfm_motion_model.pth
  { state_dict, config: {N_th, n_embed, dt, …} }
        │
        ▼
  ParticleFilter.__init__()
        │
        │  load_cfm_model(path) reads config from checkpoint
        │  rebuilds same architecture automatically
        │  stores as self.motion_model = CFMShim(CFMMotionModel)
        ▼
  pf_loop()  ──►  predict_cfm()  ──►  CFMShim.propose()
                                              │
                                              ▼
                                    CFMMotionModel.propose()
                                    (Euler ODE integration)
```

---

## 2. Training data pipeline (`generate_synthetic_data.py`)

```
Markov graph simulation (8 nodes, DT=0.033 s)
        │
        │  at each step:
        │    pos += direction * speed
        │    if in_occlusion(pos):  SKIP  (not recorded)
        │    else:  noisy = pos + N(0, 0.02)   ← measurement noise
        ▼
vis_positions: (M,  2)   visible positions only
vis_times:     (M,)      wall-clock time of each visible step

        │
        │  build_dataset():
        │    sliding window of N_th steps
        │    velocity = (pos[i+N_th] - pos[i+N_th-1]) / actual_dt
        │    skip if total_gap > 4 s  (long occlusion)
        ▼
X:  (N_samples, N_th * 2)    ← flattened position histories
y:  (N_samples, 2)           ← velocity labels (vx, vy) in m/s

        │
        ▼
  CSV saved to sim_data/training_data/
  columns: [x0,y0, x1,y1, …, x_{N_th-1},y_{N_th-1},  vx, vy]
```

Key numbers (current config):
```
DT         = 0.033 s   (30 Hz, matches the pygame sim)
N_TH       = 5         (change here to match your model)
N_STEPS    = 2000 per node × 8 nodes = ~16 000 raw steps
NOISE_STD  = 0.02 m    (measurement noise)
```

---

## 3. Network architecture (`velocity_network.py`)

```
                        INPUT
               c_flat:  (B,  N_th * 2)
               e.g.     (500, 10)  for N_th=5

                           │
                           │  reshape
                           ▼
                    (B,  N_th,  2)
                    (500,  5,   2)

┌──────────────────────────────────────────────────────────────────┐
│  ContextEncoder                                                   │
│                                                                   │
│  Linear embed: 2 → n_embed                                        │
│    (B, N_th, 2) → (B, N_th, n_embed)                             │
│                                                                   │
│  + Learned positional embedding: Embedding(N_th, n_embed)         │
│    adds a different learned vector to each timestep slot          │
│                                                                   │
│  ┌─────────────────────────────────────────────┐  × n_layer=2    │
│  │  _Block                                     │                  │
│  │    LayerNorm(n_embed)                        │                  │
│  │    MultiHeadAttention(n_head, head_size)     │                  │
│  │      head_size = n_embed // n_head           │                  │
│  │      causal mask: position i can only        │                  │
│  │        attend to positions 0..i              │                  │
│  │    + residual                                │                  │
│  │    LayerNorm(n_embed)                        │                  │
│  │    FeedForward: n_embed → 10*n_embed → n_embed│                 │
│  │    + residual                                │                  │
│  └─────────────────────────────────────────────┘                  │
│                                                                   │
│  LayerNorm(n_embed)                                               │
│                                                                   │
│  take LAST token only: x[:, -1, :]                                │
│    (B, N_th, n_embed) → (B, n_embed)                             │
│                                                                   │
│  OUTPUT: emb  (B, n_embed)                                        │
└──────────────────────────────────────────────────────────────────┘
         │
         │  emb  (B, n_embed)   ← cached, reused N_FE times below
         │
         │  also computed once:
         │  v_anchor = (pos[-1] - pos[-2]) / dt    (B, 2)
         │  x = v_anchor + anchor_sigma * N(0,I)   (B, 2)  ← ODE start point
         │
         │  Euler integration: N_FE steps
         │  ┌────────────────────────────────────────────────────┐
         │  │  for s in 0 .. N_FE-1:                             │
         │  │    tau = s / N_FE              scalar in [0, 1)    │
         │  │                                                     │
         │  │    inp = cat(emb, x, tau)      (B, n_embed+3)      │
         │  │                                                     │
         │  │  ┌──────────────────────────────────────────────┐  │
         │  │  │  VelocityHead  (MLP)                         │  │
         │  │  │    Linear(n_embed+3 → vel_hidden)  + ReLU    │  │
         │  │  │    Linear(vel_hidden → vel_hidden) + ReLU    │  │
         │  │  │    Linear(vel_hidden → 2)                    │  │
         │  │  └──────────────────────────────────────────────┘  │
         │  │    direction v  (B, 2)                              │
         │  │                                                     │
         │  │    x = x + (1/N_FE) * v       ← Euler step         │
         │  └────────────────────────────────────────────────────┘
         │
         ▼
         x  (B, 2)   ← final ODE state = velocity sample
         clip to MAX_SPEED = 1.5 m/s
         return  (B, 2)
```

### Parameter count comparison

```
Config                 Encoder params   Head params   Total
──────────────────────────────────────────────────────────
Transformer (emb=20)       ~5 900            0         ~5 900
CFM current (emb=64)     ~207 000       ~18 000      ~225 000
CFM medium  (emb=32)      ~50 000        ~6 000       ~57 000  ← recommended
CFM small   (emb=20)      ~22 000        ~4 000       ~26 000
```

---

## 4. OT-CFM training loop (`cfm_motion_model.py → CFMMotionModel.train()`)

```
For each batch (c_batch, y_batch):

  c_batch:  (B, N_th*2)    position history (flattened)
  y_batch:  (B, 2)         true next velocity

  Step 1 — compute anchor from finite-difference:
    v_anchor = (pos[-1] - pos[-2]) / dt      (B, 2)

  Step 2 — sample anchored base point:
    x0 = v_anchor + anchor_sigma * N(0, I)   (B, 2)

       WHY: instead of sampling x0 from pure N(0,I),
       we start near the last observed velocity.
       This means the ODE only needs to make SMALL
       corrections, not travel from scratch.

  Step 3 — OT-CFM interpolation:
    tau    ~ Uniform(0, 1)                   (B, 1)
    x_tau  = (1 - tau) * x0 + tau * y_batch  (B, 2)

       This is a point on the straight-line path
       from base distribution to target.

  Step 4 — flow target:
    u_target = y_batch - x0                  (B, 2)

       The vector field should point FROM x0 TOWARD y.
       (constant field for straight-line OT paths)

  Step 5 — network prediction:
    u_pred = network(x_tau, tau, c_batch)    (B, 2)

  Step 6 — MSE loss:
    loss = || u_pred - u_target ||²

  Step 7 — Adam optimizer step
  Step 8 — cosine LR decay: lr → lr * 0.01 over all epochs
```

---

## 5. Inference data flow in the particle filter (`ParticleFilter.py`)

```
self.particles: (N_th, N_particles, 2)
  e.g.          (5,    500,         2)

        │
        │  in predict_cfm():
        │
        │  transpose:  (N_particles, N_th, 2)
        │  reshape:    (N_particles, N_th*2)   ← c_flat
        │
        ▼
CFMShim.propose(c_flat)
  └─► CFMMotionModel.propose(c_flat)
          │
          │  1. encode_context(c_flat)  → emb  (N_particles, n_embed)
          │     [TRANSFORMER — the slow part]
          │
          │  2. finite_difference_velocity → v_anchor  (N_particles, 2)
          │     v_anchor = (pos[-1] - pos[-2]) / self.dt
          │
          │  3. x = v_anchor + anchor_sigma * randn   (N_particles, 2)
          │     [STOCHASTIC — each particle gets a different x]
          │
          │  4. Euler loop (N_FE=2 steps):
          │       tau = 0/N_FE, 1/N_FE, …
          │       x = x + (1/N_FE) * VelocityHead(x, tau, emb)
          │     [MLP — fast, reuses cached emb]
          │
          │  5. clip speed to 1.5 m/s
          ▼
  v_pred:  (N_particles, 2)   ← stochastic velocity sample

        │
        │  back in predict_cfm():
        │
        │  train_dt = self.motion_model._cfm.dt   ← 0.033 s, NOT sim's 0.05 s
        │
        │  shift history window:
        │    particles[0..N_th-2] = particles[1..N_th-1]
        │
        │  integrate new position:
        │    particles[-1, :, :2] = particles[-2, :, :2] + v_pred * train_dt
        │
        │  add process noise:
        │    particles[-1, :, :2] += N(0, process_covariance[:2,:2])
        ▼
self.particles updated:  (N_th, N_particles, 2)
```

---

## 6. Why the context encoder runs only once per timestep

The encoder costs ~12 ms for 500 particles. The VelocityHead costs ~0.2 ms per call.

```
Naive (wrong) approach:            encode_context inside Euler loop
    for s in range(N_FE):
        emb = encode_context(c)    ← runs N_FE times = 12 ms × N_FE
        x = x + VelocityHead(x, tau, emb)

Actual approach (propose()):       encode once, reuse emb
    emb = encode_context(c)        ← runs ONCE = 12 ms
    for s in range(N_FE):
        x = x + VelocityHead(x, tau, emb)   ← 0.2 ms × N_FE

With N_FE=2:
    Naive:   12 × 2 = 24 ms
    Actual:  12 + 0.2 × 2 = 12.4 ms   ← 2× faster
```

This is why `CFMVelocityNetwork` exposes two separate methods:
- `encode_context(c_flat)` — transformer, run once
- `predict_velocity(x, tau, emb)` — MLP, run N_FE times

The combined `forward(x_tau, tau, c_flat)` (used only during training) calls
both internally on each forward pass.

---

## 7. Context Encoder: deep math and data flow

This is the most important part of the CFM — everything else is cheap.

### 7a. What it receives and what shape the data is in

```
Input from predict_cfm():
    particles: (N_th=5, N=500, 2)   ← full particle array

    transpose → (500, 5, 2)
    reshape   → (500, 10)            ← c_flat: one row per particle

    c_flat[i] = [x0,y0, x1,y1, x2,y2, x3,y3, x4,y4]
                 ↑                              ↑
               oldest                        newest
               position                     position
```

Each row is the **position history of one particle** over the last N_th=5 timesteps. 500 particles → 500 rows processed in parallel as a batch.

---

### 7b. Step 1 — Linear token embedding

```python
self.embed = nn.Linear(input_dim=2, n_embed=32)
```

The encoder first reshapes the flat input back into a sequence:

```
c_flat:  (B=500, 10)
   └─► view(B, N_th, input_dim)
       (500, 5, 2)
```

Then applies a **shared linear layer** to every timestep token independently:

```
x[b, t] = W_embed · [x_t, y_t]  +  b_embed

W_embed: (32, 2)   learned
b_embed: (32,)     learned

Input  per token: (2,)    = one (x,y) position
Output per token: (32,)   = one embedding vector

After embed:  (500, 5, 32)
```

This is NOT yet attention — it's just projecting each 2D point into a 32D space where the Transformer can work. Every timestep slot gets the same linear projection (weights are shared across time).

---

### 7c. Step 2 — Positional embedding

```python
self.pos_embed = nn.Embedding(block_size=5, n_embed=32)
```

After the linear embed, all 5 tokens look similar — the network has no idea which one is "oldest" vs "newest". Positional embedding fixes that:

```
pos_ids = [0, 1, 2, 3, 4]           ← one integer per timestep slot
pos_vecs = pos_embed(pos_ids)        → (5, 32)   looked up from a table

x = x + pos_vecs                    → (500, 5, 32)
```

`pos_embed` is a **learnable table** of 5 rows × 32 columns. Row 0 is added to the oldest position token, row 4 is added to the newest. The network learns these vectors during training — it discovers which "slot signature" is most useful for routing attention.

After this step each token carries two types of information:
- **What** happened (the (x,y) position, projected by `embed`)
- **When** it happened (which slot it is in, encoded by `pos_embed`)

---

### 7d. Step 3 — Transformer Block × n_layer=2

Each block does two sub-operations with residual connections. With n_layer=2, this runs twice sequentially.

#### Sub-operation 1: Multi-Head Causal Self-Attention

```python
head_size = n_embed // n_head = 32 // 8 = 4
```

There are **8 heads**, each with its own independent Q, K, V projection matrices of size `(32, 4)`.

**For one head `h`:**

```
Q_h = x · W_Q^h      shape: (500, 5, 4)    "What am I looking for?"
K_h = x · W_K^h      shape: (500, 5, 4)    "What do I contain?"
V_h = x · W_V^h      shape: (500, 5, 4)    "What do I send if selected?"

W_Q^h, W_K^h, W_V^h each have shape (32, 4)  — learned
```

**Attention score matrix:**

```
A_h = Q_h · K_h^T / sqrt(4)        shape: (500, 5, 5)

A_h[b, t, s] = dot(Q_h[b,t], K_h[b,s]) / 2.0

This is the raw "relevance" score: how much should
timestep t attend to timestep s?
```

**Causal mask** — applied before softmax:

```
tril = [[1, 0, 0, 0, 0],
        [1, 1, 0, 0, 0],
        [1, 1, 1, 0, 0],
        [1, 1, 1, 1, 0],
        [1, 1, 1, 1, 1]]

Where tril == 0:  A_h[b, t, s] = -inf

This means token t can ONLY attend to tokens at positions ≤ t.
The newest token (t=4) can see all 5 positions.
The oldest token (t=0) can only see itself.
```

Why causal? The model was trained to mimic a causal predictor — at time t, you can only use history up to t, not future steps. This is the same mask used in GPT.

**Softmax over the masked scores:**

```
W_h = softmax(A_h, dim=-1)          shape: (500, 5, 5)

W_h[b, t, :] sums to 1.0
Positions masked with -inf become 0.0 after softmax
```

**Weighted sum of values:**

```
out_h = W_h · V_h                   shape: (500, 5, 4)

out_h[b, t] = sum over s of  W_h[b,t,s] * V_h[b,s]

= a weighted average of all value vectors that token t
  is "allowed to see", weighted by learned relevance.
```

**Concatenate all 8 heads and project back:**

```
concat:  (500, 5, 8*4) = (500, 5, 32)

proj = Linear(32, 32)
out  = concat · W_proj              shape: (500, 5, 32)
```

**Residual connection:**

```
x = x + out                         shape: (500, 5, 32)

The original token is preserved — attention only ADDS information.
```

#### Sub-operation 2: Feed-Forward Network (per token, independent)

```python
_FeedForward: Linear(32 → 320) → ReLU → Linear(320 → 32)
```

```
For each token independently:
  h = ReLU( x[b,t] · W1 + b1 )       (320,)
  x[b,t] = h · W2 + b2                (32,)

Then residual:
  x = x + ffwd(x)                     (500, 5, 32)
```

The FFN expands to 10× width (`10 * n_embed = 320`) — this is where most of the per-token nonlinear transformation happens. Attention decides **which tokens to mix**; the FFN decides **what to do with the mixed result**.

After 2 Blocks: `(500, 5, 32)` — every token now encodes not just its own position but a learned mixture of the relevant historical positions.

---

### 7e. Step 4 — Final LayerNorm and last-token extraction

```python
self.ln_f = nn.LayerNorm(n_embed=32)
x = self.ln_f(x)                    # (500, 5, 32)

emb = x[:, -1, :]                   # (500, 32)  ← ONLY the last token
```

**Why only the last token?**

Because of the causal mask, only the last token (t=4, the newest position) was allowed to attend to **all 5 positions**. It is the only token that has had the chance to aggregate information from the entire history. Earlier tokens have partial views:

```
Token 0 (oldest):  attended to  [p0]               only itself
Token 1:           attended to  [p0, p1]
Token 2:           attended to  [p0, p1, p2]
Token 3:           attended to  [p0, p1, p2, p3]
Token 4 (newest):  attended to  [p0, p1, p2, p3, p4]  ← full history
```

So token 4's 32-dim vector is the only one that summarises the entire trajectory. It becomes `emb` — the context vector passed to the VelocityHead.

---

### 7f. What does `emb` actually encode?

`emb` is a 32-dimensional vector. You cannot read it directly — the numbers are not interpretable. But geometrically, the encoder has been trained so that:

- Two particles with **similar recent trajectories** (same direction, same speed) produce **similar `emb` vectors** → the VelocityHead will give them similar velocity proposals
- Two particles at the same position but with **different histories** (one approaching from the left, one from the right) produce **different `emb` vectors** → the VelocityHead gives them different velocity proposals

This is the core reason CFM can be multi-modal: different particles carry different histories, so even if they happen to be at the same (x,y) right now, their `emb` vectors differ, and the ODE can route them to different future velocities.

---

### 7g. Full data flow summary with shapes

```
c_flat          (500, 10)       = 500 particles × 5 steps × 2 coords

reshape         (500, 5, 2)     = sequence of 2D tokens

embed           (500, 5, 32)    W_embed: (2→32), shared across time

+ pos_embed     (500, 5, 32)    adds slot identity to each token

──── Block 1 ────
LayerNorm       (500, 5, 32)
  8-head attn   (500, 5, 32)    8 heads × head_size=4, causal mask
  + residual    (500, 5, 32)
LayerNorm       (500, 5, 32)
  FFN 32→320→32 (500, 5, 32)
  + residual    (500, 5, 32)

──── Block 2 ────  (same structure)
                (500, 5, 32)

LayerNorm       (500, 5, 32)
last token      (500, 32)       x[:, -1, :]  ← full-history summary

emb             (500, 32)       ← output of encode_context()

──── VelocityHead (called N_FE times, emb reused) ────
cat(emb, x_tau, tau)  (500, 35)   32 + 2 + 1
Linear 35→64    (500, 64)
ReLU
Linear 64→64    (500, 64)
ReLU
Linear 64→2     (500, 2)

velocity sample (500, 2)        = (vx, vy) per particle
```

---

## 8. Checkpoint: what gets saved and loaded

`cfm_motion_model.pth` contains:
```python
{
  "state_dict": { … all network weights … },
  "config": {
      "input_dim":    2,
      "block_size":   5,      # = N_th
      "n_embed":      32,
      "n_head":       8,
      "n_layer":      2,
      "vel_hidden":   64,
      "N_FE":         10,
      "dropout":      0.1,
      "anchor_sigma": 0.3,
      "dt":           0.033,  # training timestep — CRITICAL
  }
}
```

`load_cfm_model()` reads this config and rebuilds the architecture
automatically. No code changes are needed in `ParticleFilter.py` when you
retrain with different hyperparameters — the checkpoint is self-describing.

---

## 8. Speed: where time is actually spent (500 particles, GPU)

```
ContextEncoder (Transformer)     12.1 ms   ← almost everything
VelocityHead × N_FE=2             0.4 ms   ← negligible
─────────────────────────────────────────
Total propose()                  12.5 ms

vs Transformer (ScratchTransformer) full predict:   9.2 ms
```

The speed gap comes entirely from the encoder:
```
                    N_th    n_embed    encoder cost
Transformer          5        20         3.1 ms
CFM medium (retrain) 5        32         5.0 ms   ← recommended
CFM current         10        64        12.1 ms
```

To get the medium config, change one line and retrain:

**[generate_synthetic_data.py:25](src/mml_guidance/mml_guidance/mml_network/generate_synthetic_data.py#L25)**
```python
N_TH = 5   # was 10
```

Then:
```bash
python src/mml_guidance/mml_guidance/mml_network/generate_synthetic_data.py

python src/mml_guidance/mml_guidance/mml_network/train_cfm.py \
    --n_th 5 --n_embed 32 --n_head 8 --n_layer 2 \
    --vel_hidden 64 --n_fe 10 --epochs 1500 --anchor_sigma 0.3
```
